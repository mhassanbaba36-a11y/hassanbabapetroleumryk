# Pump Jarvis - Hassan Baba Petroleum Management System

A production-grade, offline-first mobile petrol pump management system built specifically for **Hassan Baba Petroleum** (Euro brand, Jaffarabad Road, Pan Minara, Rahim Yar Khan, Pakistan). The app digitizes the station's paper Duty Register (daily shift sheet), automates nozzle meter sales, cash reconciliation, customer khata credit ledgers, tanker delivery shortage claims, multi-account banking (Bank, JazzCash, Easypaisa), and features **Jarvis**, an on-device/Gemini-backed intelligent fuel management assistant with Urdu/Roman-Urdu/English support.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following operational preferences were confirmed for Hassan Baba Petroleum:

- **Confirmed Operational Mode**: Single continuous 24-hour daily duty shift cycle (with custom start/close times and audit locks).
- **Confirmed Daily Pricing Control**: Direct daily fuel rate editing enabled right on the duty register header and quick-action chips so the owner can adjust PKR/Litre rates at any time.
- **Confirmed Multi-Language Support**: Complete trilingual support with instant toggle for **Urdu (اردو with Nastaliq font styling)**, **Roman Urdu** ("Kal ka cash kitna tha?"), and **English**, with high-contrast, big-button touch-friendly typography.
- **Confirmed Jarvis AI Verification Gate**: Two-tier execution safeguards: Safe draft creation with visual confirmation cards, plus **Owner PIN protection** for locked shift closures, deletions, or ledger corrections.

---

## 1. Overview & Core Concept

### What It Does
- **Digital Duty Register (Paper Register Mirror)**: Replicates the paper daily sheet: Nozzles (Diesel 1, 2 and Petrol 3, 4, 5, 6), Sabiqa (previous) & Maujooda (current) meter readings, Wapsi Tank (testing), auto-computed Meezan Litres & Sale Amount.
- **Automated Cash Reconciliation**:
  $$\text{Expected Cash} = \text{Sabiqa Cash} + \text{Kul Sale} + \text{Jama/Recoveries} - \text{Less/Discounts} - \text{Akhrajat (Expenses)} - \text{Udhaar (Credit)} - \text{Bank/JazzCash/Easypaisa Deposits}$$
  Compares with physical counted "Cash in Hand" to immediately display **Shortage (Red)** or **Excess (Green)**.
- **Khata / Customer Credit Ledger**: Customer profiles, vehicle numbers, credit limits, photo slips, payment recording, ageing analysis (0-7, 8-30, 30+ days), and one-tap WhatsApp Urdu debt reminders.
- **Euro Company Ledger & Tanker Dip Shortage**: Logs tanker deliveries (challan vs. physical dip before/after), purchase rates, supplier payments, running balance, and automatically drafts short-delivery claims against the oil company.
- **Stock Register & Calibrated Dip Tanks**: Multi-tank dip chart conversion (Dip CM to Litres), comparing physical dip stock vs. book stock to calculate evaporation/meter variances.
- **Money Modules**: Multi-account ledger (Bank accounts, JazzCash, Easypaisa), Lubricant/Mobil oil inventory, Less Product (spillage/discounts/test fuel), and pending customer recovery management.
- **Jarvis Intelligent Assistant**: Text & voice query processor understanding Urdu, Roman Urdu, and English to answer questions, post entries, investigate cash discrepancies, and automate daily summaries.
- **Edit Mode & Schema Versioning**: Zero-code customizer allowing the owner to add nozzle rows, edit formulas, change labels, and export/import backups with semantic version tracking.

### Target Audience & Persona
Pump Owner (**Hassan Baba**) and station managers/attendants in Rahim Yar Khan. The UI is designed for extreme speed on the pump forecourt: large 48dp+ tap targets, specialized numeric keypads, high outdoor contrast, and zero dependency on constant cloud connectivity.

---

## 2. User Experience & Visual Design

### Design Direction & Color Palette
- **Brand Identity**: Inspired by Euro Petroleum green and gold/amber fuel accents with clean industrial reliability.
- **Dominant Palette**:
  - Primary: `Deep Petrol Teal` (`#0D3B3A` / `#14534F`)
  - Accent / Energy: `Euro Amber Gold` (`#E5A91E` / `#F59E0B`)
  - Fuel Specifics: Diesel (`#15803D` Forest Green), Petrol (`#B45309` Amber Bronze), Mobil Oil (`#4338CA` Indigo)
  - Variances: Excess/Profit (`#16A34A` Emerald Green), Shortage/Loss (`#DC2626` Crimson Red)
  - Backgrounds: Clean M3 Off-White (`#F8FAFC`) / OLED Dark Forecourt Mode (`#0F172A`)
- **Typography & Layout**:
  - High-visibility tabular numbers for nozzle counters and currency amounts (`PKR 1,450,200`).
  - Clear Urdu script presentation paired with bold Latin labels for immediate comprehension by attendants.
  - Floating Big-Button quick-entry drawers for Receipts (Jama) and Expenses (Kharcha).

### Key Screen Hierarchy & Navigation
1. **Duty Register (Roznamcha)**:
   - Header: Date, 24-hr Shift, Attendant, Editable Daily Rates (Petrol PKR/L, Diesel PKR/L).
   - Nozzle Grid: 6 nozzles with auto-filled previous readings, current meter input, test fuel return, and line totals.
   - Cash Reconciliation Card: Expected vs. Counted Physical Cash with prominent Short/Excess banner.
   - Quick Tabs: Jama Table (Receipts), Akhrajat Table (Expenses), Stock Register (Tanks).
   - "Close Duty" lock button with PIN modal and audit summary.
2. **Khata (Customer Ledger)**:
   - Searchable customer directory with total outstanding badge.
   - Customer Detail: Ledger statement, fuel slips, credit limit gauge, and WhatsApp Urdu reminder generator.
   - Quick Udhaar Entry with vehicle number and product selector.
3. **Company Ledger (Euro Petroleum)**:
   - Tanker delivery intake (Amda): Ordered vs. Dip-measured litres, invoice price, shortage calculation.
   - Payments to Euro (Bank/Pay Order/JazzCash) & running balance owed.
   - Auto-generated Shortage Claim Helper.
4. **Money & Accounts**:
   - Accounts breakdown: HBL/UBL, JazzCash, Easypaisa, Cash Drawer.
   - Lubricant / Mobil oil inventory and profit tracker.
   - Recovery tracker with promised payment dates.
5. **Reports & Shortage Analytics**:
   - 12-month sales drilldown, dip tank shrinkage vs. tanker delivery loss, nozzle profitability.
6. **Jarvis AI Assistant**:
   - Conversational chat + quick action chips ("Kal ki sale", "Ali ka khata", "Diesel shortage", "Duty band karo").
   - Action confirmation cards with rollback support and audit trail.
7. **App Settings & Edit Mode**:
   - Schema customization, formula editor, nozzle configuration, backup/restore (JSON/CSV/PDF).

---

## 3. Key Product Decisions & Trade-Offs

| Decision | Chosen Approach | Rationale | Alternatives Considered |
|---|---|---|---|
| **Data Storage** | Local Room SQLite Database with full offline persistence | Pump operations in Rahim Yar Khan cannot tolerate internet downtime or cloud latency. | Cloud-only Firestore (rejected due to offline risks during power cuts). |
| **Shift Model** | Continuous 24-hour daily duty with customizable rollover | User confirmed single continuous shift matching their actual station paper workflow. | Fixed 3-shift 8-hour model. |
| **Language Engine** | Tri-lingual dynamic locale toggle (Urdu RTL, Roman Urdu, English) | Enables bilingual pump owner and non-English forecourt attendants to operate seamlessly. | English-only or static hardcoded strings. |
| **Formula Engine** | Safe evaluated expression schema for cash reconciliation & stock | Allows the owner to modify accounting logic without needing app updates or code recompilation. | Hardcoded Kotlin math functions. |
| **Jarvis AI Engine** | Hybrid Local Rule-Based Tool Dispatcher + Gemini REST Client | Core commands execute instantly offline (100% reliable); complex reasoning/queries use Gemini when connected. | Pure cloud LLM (fails when offline). |

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Jetpack Compose UI Layer                        │
│   ┌───────────────┐ ┌───────────────┐ ┌───────────────┐ ┌───────────┐  │
│   │ Duty Register │ │ CustomerKhata │ │ CompanyLedger │ │ Jarvis AI │  │
│   │ (Paper Mirror)│ │ & Udhaar Slips│ │ (Euro Tanker) │ │ Assistant │  │
│   └───────┬───────┘ └───────┬───────┘ └───────┬───────┘ └─────┬─────┘  │
│           └─────────────────┼─────────────────┼───────────────┘        │
├─────────────────────────────┼─────────────────┼────────────────────────┤
│                    Domain & Calculation Engine                         │
│   • Formula Evaluator (Expected Cash, Short/Excess, Meezan Litres)     │
│   • Dip Tank Calibration Chart Converter (CM -> Litres)                │
│   • Audit Logging & Shift State Machine (Open -> Reconciled -> Locked) │
│   • Jarvis Function Tool Registry & Action Confirmation Guard          │
├─────────────────────────────┼─────────────────┼────────────────────────┤
│                    Room Persistence Data Layer                         │
│   • DutyShifts, NozzleReadings, Receipts (Jama), Expenses (Akhrajat)   │
│   • Customers, KhataEntries, CompanyDeliveries, CompanyPayments        │
│   • BankAccounts, MoneyTransactions, StockTanks, DipLogs               │
│   • AuditLogs, AppConfigVersions (Schema-driven JSON)                  │
└────────────────────────────────────────────────────────────────────────┘
```

### Core Calculations & Formula Specifications
1. **Nozzle Sales**:
   $$\text{Meezan Litres} = \text{Maujooda} - \text{Sabiqa} - \text{Wapsi Tank}$$
   $$\text{Meezan Amount} = \text{Meezan Litres} \times \text{Fuel Rate (PKR)}$$
2. **Cash Reconciliation**:
   $$\text{Expected Cash} = \text{Opening Cash} + \text{Total Fuel Sale} + \text{Mobil Oil Sale} + \text{Jama Recoveries} - \text{Discounts/Less} - \text{Akhrajat} - \text{Udhaar} - \text{Bank Deposits}$$
   $$\text{Variance} = \text{Physical Counted Cash} - \text{Expected Cash} \quad (\ge 0: \text{Green Excess}, < 0: \text{Red Short})$$
3. **Tank Stock & Evaporation Loss**:
   $$\text{Book Stock} = \text{Sabiqa Stock} + \text{Amda (Deliveries)} - \text{Metered Sales}$$
   $$\text{Shortage/Gain (Kam/Ziada)} = \text{Physical Dip Litres} - \text{Book Stock}$$

---

## Planned Implementation Steps

1. **Database & Persistence Layer**: Setup Room entities, DAOs, TypeConverters, Repository, and seed initial Hassan Baba Petroleum demo dataset (6 nozzles, 4 tanks, 25 realistic Rahim Yar Khan customers, 12 months historical summary).
2. **Duty Register UI (Paper Register Mirror)**: Header with editable daily fuel rates, Nozzle Meter table, Jama table, Akhrajat table, and Live Cash Reconciliation card.
3. **Customer Khata Module**: Customer master list, credit limits, detailed ledger, WhatsApp Urdu debt reminder generator, and quick udhaar slip drawer.
4. **Company & Stock Module**: Euro tanker delivery logging with shortage detection, dip chart calibration manager, and tank loss analytics.
5. **Money & Bank Accounts**: Multi-account ledger (Bank, JazzCash, Easypaisa) with IN/OUT filters and lubricant stock tracker.
6. **Jarvis AI Assistant**: Interactive voice/text chat, function tools (check khata, post recovery, analyze shortage, close duty), confirmation safety cards, and audit rollback.
7. **App Customizer & Verification**: JSON schema configuration, formula editor, language toggler, and compilation test.
