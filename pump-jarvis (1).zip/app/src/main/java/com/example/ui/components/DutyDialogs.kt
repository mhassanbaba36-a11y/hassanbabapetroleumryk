package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.AppLanguage
import com.example.domain.LanguageEngine
import com.example.ui.theme.EuroGoldPrimary
import com.example.ui.theme.PetrolTealPrimary

@Composable
fun EditRatesDialog(
    initialPetrol: Double,
    initialDiesel: Double,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (Double, Double) -> Unit
) {
    var petrolText by remember { mutableStateOf(initialPetrol.toInt().toString()) }
    var dieselText by remember { mutableStateOf(initialDiesel.toInt().toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("روزانہ فی لٹر ریٹ تبدیل کریں (Daily Rates)", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = petrolText,
                    onValueChange = { petrolText = it },
                    label = { Text("سپر پٹرول ریٹ (PKR / Litre)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("dialog_petrol_rate_input")
                )
                OutlinedTextField(
                    value = dieselText,
                    onValueChange = { dieselText = it },
                    label = { Text("ہائی اسپیڈ ڈیزل ریٹ (PKR / Litre)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("dialog_diesel_rate_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val p = petrolText.toDoubleOrNull() ?: initialPetrol
                    val d = dieselText.toDoubleOrNull() ?: initialDiesel
                    onSave(p, d)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                modifier = Modifier.testTag("dialog_save_rates_btn")
            ) {
                Text("محفوظ کریں Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("منسوخ Cancel") }
        }
    )
}

@Composable
fun EditCountedCashDialog(
    initialCash: Double,
    onDismiss: () -> Unit,
    onSave: (Double) -> Unit
) {
    var cashText by remember { mutableStateOf(initialCash.toLong().toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("موجودہ کیش ان ہینڈ درج کریں (Counted Cash)", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column {
                Text("دراز میں موجود نوٹ اور رقم گن کر درج کریں:", style = MaterialTheme.typography.bodySmall)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = cashText,
                    onValueChange = { cashText = it },
                    label = { Text("گن کر درج کریں (PKR)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("dialog_counted_cash_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = cashText.toDoubleOrNull() ?: initialCash
                    onSave(amount)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary)
            ) {
                Text("محفوظ کریں Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("منسوخ Cancel") }
        }
    )
}

@Composable
fun AddJamaDialog(
    onDismiss: () -> Unit,
    onSave: (Double, String, String, String) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var fromParty by remember { mutableStateOf("") }
    var khataNo by remember { mutableStateOf("") }
    var tafseel by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("+ رقم جمع درج کریں (Add Jama Receipt)", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("رقم Amount (PKR)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("jama_amount_input")
                )
                OutlinedTextField(
                    value = fromParty,
                    onValueChange = { fromParty = it },
                    label = { Text("بنام / کس سے وصول ہوئی (From Whom)") },
                    modifier = Modifier.fillMaxWidth().testTag("jama_party_input")
                )
                OutlinedTextField(
                    value = khataNo,
                    onValueChange = { khataNo = it },
                    label = { Text("کھاتہ نمبر (اختیاری e.g. K-101)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = tafseel,
                    onValueChange = { tafseel = it },
                    label = { Text("تفصیل و نوٹ (Detail)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        onSave(amt, fromParty, khataNo, tafseel)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                modifier = Modifier.testTag("jama_submit_btn")
            ) {
                Text("جمع کریں Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("منسوخ") }
        }
    )
}

@Composable
fun AddAkhrajatDialog(
    onDismiss: () -> Unit,
    onSave: (Double, String, String, String) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var tafseel by remember { mutableStateOf("") }
    var voucherNo by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Tea/Kharcha") }

    val categories = listOf("Tea/Kharcha", "Salary", "Generator", "Electricity", "Repair", "Misc")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("+ اخراجات درج کریں (Add Expense)", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("رقم Amount (PKR)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("akhrajat_amount_input")
                )
                OutlinedTextField(
                    value = tafseel,
                    onValueChange = { tafseel = it },
                    label = { Text("تفصیل خرچہ (Detail / Description)") },
                    modifier = Modifier.fillMaxWidth().testTag("akhrajat_desc_input")
                )
                OutlinedTextField(
                    value = voucherNo,
                    onValueChange = { voucherNo = it },
                    label = { Text("واؤچر نمبر (Voucher No)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("کیٹیگری منتخب کریں:", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    categories.take(3).forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    categories.drop(3).forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        onSave(amt, tafseel, selectedCategory, voucherNo)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                modifier = Modifier.testTag("akhrajat_submit_btn")
            ) {
                Text("خرچہ درج کریں Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("منسوخ") }
        }
    )
}

@Composable
fun OwnerPinDialog(
    title: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var pinText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column {
                Text("یہ ایکشن انجام دینے کے لیے پمپ مالک کا 4 ہندسوں والا پن درج کریں (ڈیفالٹ: 1234):", fontSize = 13.sp)
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = pinText,
                    onValueChange = { if (it.length <= 4) pinText = it },
                    label = { Text("مالک پن کوڈ (Owner PIN)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth().testTag("owner_pin_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(pinText) },
                colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                modifier = Modifier.testTag("pin_confirm_btn")
            ) {
                Text("تصدیق کریں Confirm")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("منسوخ") }
        }
    )
}
