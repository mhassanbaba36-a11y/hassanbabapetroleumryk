package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ShiftStatus
import com.example.domain.AppLanguage
import com.example.domain.LanguageEngine
import com.example.ui.theme.*
import com.example.ui.viewmodel.PumpUiState

@Composable
fun TopForecourtBar(
    state: PumpUiState,
    onLanguageChange: (AppLanguage) -> Unit,
    onEditRates: () -> Unit,
    onSwitchAccount: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val lang = state.currentLanguage
    val shift = state.activeShift

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("top_forecourt_bar"),
        color = PetrolTealPrimary,
        tonalElevation = 6.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // Row 1: Station Branding & Status & Language Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Station Title & Location
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(EuroGoldPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalGasStation,
                            contentDescription = "Euro Station",
                            tint = PetrolTealDark,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "حسن بابا پیٹرولیم",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontFamily = NotoNastaliqUrduFamily,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = EuroGoldPrimary
                            ) {
                                Text(
                                    text = "EURO",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 10.sp,
                                    color = PetrolTealDark,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "Jaffarabad Road, Pan Minara, RYK",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                }

                // Trilingual Switcher Chips
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(PetrolTealDark.copy(alpha = 0.6f))
                        .padding(2.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    AppLanguage.values().forEach { l ->
                        val isSelected = l == lang
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) EuroGoldPrimary else Color.Transparent)
                                .clickable { onLanguageChange(l) }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = l.title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) PetrolTealDark else Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 2: Live Daily Fuel Rates Chip & Shift Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Clickable Rates Banner
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = PetrolTealMedium,
                    modifier = Modifier
                        .clickable { onEditRates() }
                        .testTag("rate_edit_chip")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⛽ ریٹ: ",
                            color = EuroGoldLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "پٹرول Rs ${shift?.petrolRate?.toInt() ?: 280}",
                            color = PetrolAmberLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(text = " | ", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
                        Text(
                            text = "ڈیزل Rs ${shift?.dieselRate?.toInt() ?: 285}",
                            color = DieselGreenLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Rates",
                            tint = EuroGoldLight,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }

                // Shift Status Badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (shift?.status == ShiftStatus.LOCKED) ShortageRed else DieselGreen
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (shift?.status == ShiftStatus.LOCKED) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = "Status",
                            tint = Color.White,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (shift?.status == ShiftStatus.LOCKED) "Locked" else "24h Active",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // Row 3: Active User & Fast Switch Account / Logout
            state.currentUser?.let { user ->
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(PetrolTealDark.copy(alpha = 0.5f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(EuroGoldPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = user.fullName.take(1).uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = PetrolTealDark
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${user.fullName} (${user.role})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { onSwitchAccount() }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                            .testTag("switch_account_header_btn"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = "Switch Account",
                            tint = EuroGoldLight,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "اکاؤنٹ سوئچ / لاگ آؤٹ",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = EuroGoldLight
                        )
                    }
                }
            }
        }
    }
}
