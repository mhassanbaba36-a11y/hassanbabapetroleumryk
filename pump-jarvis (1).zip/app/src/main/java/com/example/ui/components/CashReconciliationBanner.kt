package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.AppLanguage
import com.example.domain.LanguageEngine
import com.example.domain.ShiftReconciliationSummary
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.*

@Composable
fun CashReconciliationBanner(
    reconciliation: ShiftReconciliationSummary?,
    language: AppLanguage,
    onEditCountedCash: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (reconciliation == null) return

    val formatter = NumberFormat.getNumberInstance(Locale.US)
    val variance = reconciliation.variance
    val isShort = reconciliation.isShort
    val isExcess = reconciliation.isExcess

    val bannerBg = when {
        isShort -> ShortageRedBg
        isExcess -> ExcessGreenBg
        else -> SurfaceVariantLight
    }

    val bannerBorder = when {
        isShort -> ShortageRed
        isExcess -> ExcessGreen
        else -> BorderLight
    }

    val bannerTextColor = when {
        isShort -> ShortageRed
        isExcess -> ExcessGreen
        else -> TextPrimaryLight
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .testTag("cash_reconciliation_banner"),
        color = bannerBg,
        tonalElevation = 2.dp,
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(bannerBorder))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header: Expected vs Hand Cash & Short/Excess Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = LanguageEngine.t("expected_cash", language),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondaryLight
                    )
                    Text(
                        text = "PKR ${formatter.format(reconciliation.expectedCash.toLong())}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight
                    )
                }

                // Status Pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = bannerTextColor
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when {
                                isShort -> Icons.Default.ArrowDownward
                                isExcess -> Icons.Default.ArrowUpward
                                else -> Icons.Default.CheckCircle
                            },
                            contentDescription = "Variance",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        val statusText = when {
                            isShort -> "کمی Short: -PKR ${formatter.format((-variance).toLong())}"
                            isExcess -> "بیشی Excess: +PKR ${formatter.format(variance.toLong())}"
                            else -> "برابر Balanced"
                        }
                        Text(
                            text = statusText,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = bannerBorder.copy(alpha = 0.5f), thickness = 0.8.dp)
            Spacer(modifier = Modifier.height(10.dp))

            // Sub-metrics Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Counted Cash in Hand (Editable)
                Column(
                    modifier = Modifier
                        .clickable { onEditCountedCash() }
                        .testTag("counted_cash_field")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = LanguageEngine.t("counted_cash", language),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryLight
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Hand Cash",
                            tint = PetrolTealMedium,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                    Text(
                        text = "PKR ${formatter.format(reconciliation.countedCash.toLong())}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = PetrolTealPrimary
                    )
                }

                // Summary figures
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "سیل: PKR ${formatter.format(reconciliation.kulSaleAmdan.toLong())}",
                        fontSize = 11.sp,
                        color = TextPrimaryLight
                    )
                    Text(
                        text = "جمع: PKR ${formatter.format(reconciliation.totalJama.toLong())} | خرچہ: PKR ${formatter.format(reconciliation.totalAkhrajat.toLong())}",
                        fontSize = 11.sp,
                        color = TextSecondaryLight
                    )
                    Text(
                        text = "ادھار: PKR ${formatter.format(reconciliation.totalUdhaarGiven.toLong())}",
                        fontSize = 11.sp,
                        color = TextSecondaryLight
                    )
                }
            }
        }
    }
}
