package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.JarvisMessage
import com.example.ui.components.OwnerPinDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.PumpUiState
import com.example.ui.viewmodel.PumpViewModel
import kotlinx.coroutines.launch

@Composable
fun JarvisScreen(
    state: PumpUiState,
    viewModel: PumpViewModel,
    modifier: Modifier = Modifier
) {
    var inputText by remember { mutableStateOf("") }
    var showPinDialogForAction by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Suggested quick commands in Urdu & Roman Urdu for easy 1-tap forecourt operation
    val quickSuggestions = listOf(
        "آج کی ڈیوٹی بند کر دو",
        "کیش کا حساب اور شارٹیج دکھاؤ",
        "طارق گجر کا کھاتہ دکھاؤ",
        "ڈیزل کی شارٹیج کتنی تھی؟",
        "یورو کمپنی کو 5 لاکھ ادائیگی درج کرو"
    )

    LaunchedEffect(state.jarvisMessages.size) {
        if (state.jarvisMessages.isNotEmpty()) {
            listState.animateScrollToItem(state.jarvisMessages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .testTag("jarvis_screen")
    ) {
        // 1. Proactive Forecourt Alerts Card (If any)
        if (state.proactiveAlerts.isNotEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                shape = RoundedCornerShape(10.dp),
                color = EuroGoldLight.copy(alpha = 0.2f),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(EuroGoldPrimary))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = "Alert", tint = EuroGoldDark, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("جاروس پیشگی الرٹ (Jarvis Proactive Alerts):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PetrolTealDark)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    state.proactiveAlerts.take(2).forEach { alert ->
                        Text("• $alert", fontSize = 11.sp, color = TextPrimaryLight, modifier = Modifier.padding(vertical = 1.dp))
                    }
                }
            }
        }

        // 2. Chat Conversation History
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 10.dp)
        ) {
            items(items = state.jarvisMessages, key = { it.id }) { msg ->
                ChatBubble(
                    message = msg,
                    onConfirmProposal = {
                        if (msg.actionProposal?.requiresPin == true) {
                            showPinDialogForAction = true
                        } else if (msg.actionProposal != null) {
                            viewModel.executePendingJarvisAction(msg.actionProposal)
                        }
                    },
                    onCancelProposal = { viewModel.cancelPendingAction() }
                )
            }
        }

        // 3. Quick Command Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickSuggestions.take(2).forEach { chipText ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SurfaceLight,
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.clickable {
                        viewModel.sendJarvisMessage(chipText)
                    }
                ) {
                    Text(
                        text = chipText,
                        fontSize = 11.sp,
                        color = PetrolTealPrimary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // 4. Message Input Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = SurfaceLight,
            tonalElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("اردو یا انگریزی میں پوچھیں...", fontSize = 13.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("jarvis_input_field"),
                    shape = RoundedCornerShape(24.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Send Button
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(PetrolTealPrimary)
                        .clickable {
                            if (inputText.isNotBlank()) {
                                viewModel.sendJarvisMessage(inputText)
                                inputText = ""
                            }
                        }
                        .testTag("jarvis_send_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
    }

    if (showPinDialogForAction && state.pendingAction != null) {
        OwnerPinDialog(
            title = state.pendingAction.titleUrdu,
            onDismiss = { showPinDialogForAction = false },
            onConfirm = { pin ->
                viewModel.executePendingJarvisAction(state.pendingAction, pin)
                showPinDialogForAction = false
            }
        )
    }
}

@Composable
private fun ChatBubble(
    message: JarvisMessage,
    onConfirmProposal: () -> Unit,
    onCancelProposal: () -> Unit
) {
    val isUser = message.isUser

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(EuroGoldPrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = Icons.Default.SmartToy, contentDescription = "Jarvis", tint = PetrolTealDark, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            modifier = Modifier.widthIn(max = 280.dp),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isUser) PetrolTealPrimary else SurfaceLight,
                tonalElevation = if (isUser) 0.dp else 2.dp,
                border = if (isUser) null else CardDefaults.outlinedCardBorder()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = message.text,
                        color = if (isUser) Color.White else TextPrimaryLight,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )

                    // If message contains an action proposal (Confirmation Card)
                    if (message.actionProposal != null) {
                        val prop = message.actionProposal
                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = BorderLight, thickness = 0.5.dp)
                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "ایکشن تصدیق کارڈ:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = EuroGoldDark
                        )
                        Text(
                            text = prop.titleUrdu,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onConfirmProposal,
                                colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("confirm_jarvis_action_btn")
                            ) {
                                Text("ہاں، منظور ہے", fontSize = 11.sp)
                            }
                            OutlinedButton(
                                onClick = onCancelProposal,
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("منسوخ", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
