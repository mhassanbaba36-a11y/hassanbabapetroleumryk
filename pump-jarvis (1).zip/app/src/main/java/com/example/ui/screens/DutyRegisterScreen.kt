package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.domain.DipChartConverter
import com.example.domain.LanguageEngine
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PumpUiState
import com.example.ui.viewmodel.PumpViewModel
import java.text.NumberFormat
import java.util.*

@Composable
fun DutyRegisterScreen(
    state: PumpUiState,
    viewModel: PumpViewModel,
    modifier: Modifier = Modifier
) {
    val lang = state.currentLanguage
    val shift = state.activeShift
    val formatter = remember { NumberFormat.getNumberInstance(Locale.US) }

    var selectedTab by remember { mutableStateOf(0) } // 0: Nozzles, 1: Jama, 2: Akhrajat, 3: Stock Dip
    val tabs = listOf(
        LanguageEngine.t("tab_nozzles", lang),
        LanguageEngine.t("tab_jama", lang),
        LanguageEngine.t("tab_akhrajat", lang),
        LanguageEngine.t("tab_stock", lang)
    )

    // Dialog states
    var showRatesDialog by remember { mutableStateOf(false) }
    var showCashDialog by remember { mutableStateOf(false) }
    var showJamaDialog by remember { mutableStateOf(false) }
    var showAkhrajatDialog by remember { mutableStateOf(false) }
    var showCloseDutyDialog by remember { mutableStateOf(false) }
    var editingNozzle by remember { mutableStateOf<NozzleReadingEntity?>(null) }
    var editingDip by remember { mutableStateOf<StockDipEntryEntity?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .testTag("duty_register_screen"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // 1. Top Forecourt Branding Bar
        item {
            TopForecourtBar(
                state = state,
                onLanguageChange = { viewModel.setLanguage(it) },
                onEditRates = { showRatesDialog = true },
                onSwitchAccount = { viewModel.logout() }
            )
        }

        // 2. Paper Register Shift Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "روزنامچہ ڈیوٹی شیٹ (Paper Duty Register)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = PetrolTealPrimary
                            )
                            Text(
                                text = "تاریخ: ${shift?.shiftDate ?: "2026-10-10"} | روز: ${shift?.dayOfWeek ?: "Saturday"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryLight
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = EuroGoldLight.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = shift?.shiftType ?: "24h Continuous",
                                color = PetrolTealDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "آئل مین (انچارج): ${shift?.oilManName ?: "Muhammad Asif"}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = TextPrimaryLight
                    )
                }
            }
        }

        // 3. Live Cash Reconciliation Card (Formula Expected vs Physical Cash in Hand)
        item {
            Box(modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                CashReconciliationBanner(
                    reconciliation = state.reconciliation,
                    language = lang,
                    onEditCountedCash = { showCashDialog = true }
                )
            }
        }

        // 4. Section Navigation Tabs (Nozzles, Jama, Akhrajat, Stock) - Apple iOS style
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                CupertinoSegmentedControl(
                    items = tabs,
                    selectedIndex = selectedTab,
                    onItemSelected = { selectedTab = it }
                )
            }
        }

        // 5. Tab Content
        when (selectedTab) {
            // TAB 0: NOZZLE METER SECTION
            0 -> {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "نوزل میٹر ریڈنگ (6 Nozzles Forecourt)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = PetrolTealDark
                        )
                        Text(
                            text = "کل ڈیزل: ${state.reconciliation?.dieselLitres?.toInt() ?: 0} L | پٹرول: ${state.reconciliation?.petrolLitres?.toInt() ?: 0} L",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = PetrolTealLight
                        )
                    }
                }

                items(items = state.nozzles, key = { it.id }) { nozzle ->
                    NozzleRowCard(
                        nozzle = nozzle,
                        formatter = formatter,
                        onEdit = { editingNozzle = nozzle }
                    )
                }
            }

            // TAB 1: JAMA TABLE (RECEIPTS)
            1 -> {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "بقایاجات جمع جدول (Total Jama: PKR ${formatter.format(state.reconciliation?.totalJama?.toLong() ?: 0)})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = PetrolTealDark
                        )
                        Button(
                            onClick = { showJamaDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("add_jama_btn")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("رقم جمع", fontSize = 12.sp)
                        }
                    }
                }

                if (state.jamaList.isEmpty()) {
                    item {
                        EmptyForecourtState(text = "کوئی رقم جمع درج نہیں ہوئی۔ اوپر دیے گئے بٹن سے نیا اندراج کریں۔")
                    }
                } else {
                    items(items = state.jamaList, key = { it.id }) { jama ->
                        JamaRowCard(jama = jama, formatter = formatter, onDelete = { viewModel.deleteJamaEntry(jama) })
                    }
                }
            }

            // TAB 2: AKHRAJAT TABLE (EXPENSES)
            2 -> {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "اخراجات و دیگر تفصیل (Total: PKR ${formatter.format(state.reconciliation?.totalAkhrajat?.toLong() ?: 0)})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = PetrolTealDark
                        )
                        Button(
                            onClick = { showAkhrajatDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("add_akhrajat_btn")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("خرچہ درج", fontSize = 12.sp)
                        }
                    }
                }

                if (state.akhrajatList.isEmpty()) {
                    item {
                        EmptyForecourtState(text = "آج کا کوئی خرچہ درج نہیں ہوا ہے۔")
                    }
                } else {
                    items(items = state.akhrajatList, key = { it.id }) { akhrajat ->
                        AkhrajatRowCard(akhrajat = akhrajat, formatter = formatter, onDelete = { viewModel.deleteAkhrajatEntry(akhrajat) })
                    }
                }
            }

            // TAB 3: STOCK REGISTER & TANK DIP
            3 -> {
                item {
                    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                        Text(
                            text = "اسٹاک رجسٹر و کیلیبریٹڈ ٹینک ڈپ (Tanks Stock & Dip)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = PetrolTealDark
                        )
                        Text(
                            text = "بک اسٹاک = سابقہ + آمدہ - سیل | کم/زیادہ = فزیکل ڈپ لٹر - بک اسٹاک",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryLight
                        )
                    }
                }

                items(items = state.stockDips, key = { it.id }) { dip ->
                    StockDipRowCard(
                        dip = dip,
                        formatter = formatter,
                        onEdit = { editingDip = dip }
                    )
                }
            }
        }

        // 6. Shift Final Action: Close Duty & Lock
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                shape = RoundedCornerShape(12.dp),
                color = SurfaceLight,
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "شفٹ فائنل لاک (Close & Lock Shift)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = PetrolTealDark
                    )
                    Text(
                        text = "ڈیوٹی بند کرنے سے تمام ریڈنگز مقفل ہو جائیں گی۔ صرف پمپ مالک اپنے پاسورڈ سے دوبارہ کھول سکے گا۔",
                        fontSize = 12.sp,
                        color = TextSecondaryLight,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                    Button(
                        onClick = { showCloseDutyDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = if (shift?.status == ShiftStatus.LOCKED) ShortageRed else PetrolTealPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("close_duty_lock_btn"),
                        enabled = shift?.status != ShiftStatus.LOCKED
                    ) {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = "Lock")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (shift?.status == ShiftStatus.LOCKED) "ڈیوٹی پہلے سے مقفل ہے (Locked)" else "ڈیوٹی بند اور لاک کریں (Lock Shift)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }

    // Modal Dialogs
    if (showRatesDialog && shift != null) {
        EditRatesDialog(
            initialPetrol = shift.petrolRate,
            initialDiesel = shift.dieselRate,
            language = lang,
            onDismiss = { showRatesDialog = false },
            onSave = { p, d ->
                viewModel.updateDailyRates(p, d)
                showRatesDialog = false
            }
        )
    }

    if (showCashDialog && shift != null) {
        EditCountedCashDialog(
            initialCash = state.reconciliation?.countedCash ?: shift.countedCash,
            onDismiss = { showCashDialog = false },
            onSave = { cash ->
                viewModel.updateCountedCash(cash)
                showCashDialog = false
            }
        )
    }

    if (showJamaDialog) {
        AddJamaDialog(
            onDismiss = { showJamaDialog = false },
            onSave = { amt, party, khata, note ->
                viewModel.addJamaEntry(amt, party, khata, note)
                showJamaDialog = false
            }
        )
    }

    if (showAkhrajatDialog) {
        AddAkhrajatDialog(
            onDismiss = { showAkhrajatDialog = false },
            onSave = { amt, note, cat, voucher ->
                viewModel.addAkhrajatEntry(amt, note, cat, voucher)
                showAkhrajatDialog = false
            }
        )
    }

    if (showCloseDutyDialog) {
        OwnerPinDialog(
            title = "ڈیوٹی مقفل کرنے کے لیے مالک پن کوڈ درج کریں",
            onDismiss = { showCloseDutyDialog = false },
            onConfirm = { pin ->
                viewModel.closeDutyShift(pin)
                showCloseDutyDialog = false
            }
        )
    }

    // Nozzle Reading Edit Modal
    if (editingNozzle != null) {
        val nozzle = editingNozzle!!
        var maujoodaText by remember { mutableStateOf(nozzle.maujoodaReading.toInt().toString()) }
        var wapsiText by remember { mutableStateOf(nozzle.wapsiTankLitres.toInt().toString()) }
        var isReset by remember { mutableStateOf(nozzle.isResetFlag) }
        var reason by remember { mutableStateOf(nozzle.resetReason) }

        AlertDialog(
            onDismissRequest = { editingNozzle = null },
            title = { Text("${nozzle.nozzleName} ریڈنگ درج کریں", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("سابقہ ریڈنگ (Sabiqa): ${formatter.format(nozzle.sabiqaReading.toLong())}", fontWeight = FontWeight.SemiBold, color = TextSecondaryLight)
                    OutlinedTextField(
                        value = maujoodaText,
                        onValueChange = { maujoodaText = it },
                        label = { Text("موجودہ ریڈنگ (Maujooda Reading)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("maujooda_reading_input")
                    )
                    OutlinedTextField(
                        value = wapsiText,
                        onValueChange = { wapsiText = it },
                        label = { Text("واپسی ٹینک لٹر (Wapsi Tank / Test)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isReset, onCheckedChange = { isReset = it })
                        Text("میٹر ری سیٹ یا تبدیل فلیگ (Meter Reset Flag)", fontSize = 12.sp)
                    }
                    if (isReset) {
                        OutlinedTextField(
                            value = reason,
                            onValueChange = { reason = it },
                            label = { Text("ری سیٹ کی وجہ (Reason)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val m = maujoodaText.toDoubleOrNull() ?: nozzle.maujoodaReading
                        val w = wapsiText.toDoubleOrNull() ?: nozzle.wapsiTankLitres
                        viewModel.updateNozzleReading(nozzle, m, w, isReset, reason)
                        editingNozzle = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                    modifier = Modifier.testTag("save_nozzle_reading_btn")
                ) {
                    Text("محفوظ کریں Save")
                }
            },
            dismissButton = { TextButton(onClick = { editingNozzle = null }) { Text("منسوخ") } }
        )
    }

    // Dip Edit Modal
    if (editingDip != null) {
        val dip = editingDip!!
        var dipCmText by remember { mutableStateOf(dip.dipCm.toString()) }

        AlertDialog(
            onDismissRequest = { editingDip = null },
            title = { Text("${dip.tankName} ڈپ سینٹی میٹر درج کریں", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("فزیکل ڈپ راڈ کے سینٹی میٹر (CM) درج کریں۔ کیلیبریشن چارٹ کے مطابق لٹر خودبخود نکل آئیں گے۔", fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = dipCmText,
                        onValueChange = { dipCmText = it },
                        label = { Text("ڈپ راڈ (Dip CM)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("dip_cm_input")
                    )
                    val cm = dipCmText.toDoubleOrNull() ?: dip.dipCm
                    val previewLitres = DipChartConverter.cmToLitres(cm)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("کیلیبریٹڈ حجم: ${formatter.format(previewLitres.toLong())} Litres", fontWeight = FontWeight.Bold, color = PetrolTealPrimary)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cm = dipCmText.toDoubleOrNull() ?: dip.dipCm
                        viewModel.updateTankDip(dip, cm)
                        editingDip = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary)
                ) {
                    Text("محفوظ کریں")
                }
            },
            dismissButton = { TextButton(onClick = { editingDip = null }) { Text("منسوخ") } }
        )
    }
}

@Composable
private fun NozzleRowCard(
    nozzle: NozzleReadingEntity,
    formatter: NumberFormat,
    onEdit: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 5.dp)
            .testTag("nozzle_card_${nozzle.nozzleNumber}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (nozzle.fuelType == FuelType.DIESEL) DieselGreen else PetrolAmber
                    ) {
                        Text(
                            text = "#${nozzle.nozzleNumber}",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = nozzle.nozzleName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextPrimaryLight
                    )
                }

                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Reading", tint = PetrolTealPrimary, modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            HorizontalDivider(color = BorderLight, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(6.dp))

            // Reading metrics grid
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("سابقہ (Sabiqa)", fontSize = 11.sp, color = TextSecondaryLight)
                    Text(formatter.format(nozzle.sabiqaReading.toLong()), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
                Column {
                    Text("موجودہ (Maujooda)", fontSize = 11.sp, color = TextSecondaryLight)
                    Text(formatter.format(nozzle.maujoodaReading.toLong()), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PetrolTealDark)
                }
                Column {
                    Text("واپسی (Wapsi)", fontSize = 11.sp, color = TextSecondaryLight)
                    Text("${nozzle.wapsiTankLitres.toInt()} L", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("میزان لٹر (Sale L)", fontSize = 11.sp, color = TextSecondaryLight)
                    Text("${formatter.format(nozzle.meezanLitres.toLong())} L", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = DieselGreen)
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("ریٹ: Rs ${nozzle.rate.toInt()}/L", fontSize = 11.sp, color = TextSecondaryLight)
                Text("سیل رقم: PKR ${formatter.format(nozzle.meezanAmount.toLong())}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EuroGoldDark)
            }
        }
    }
}

@Composable
private fun JamaRowCard(
    jama: JamaEntryEntity,
    formatter: NumberFormat,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = jama.fromParty, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    text = "${jama.tafseel} ${if (jama.khataNumber.isNotEmpty()) "(${jama.khataNumber})" else ""}",
                    fontSize = 12.sp,
                    color = TextSecondaryLight
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "PKR ${formatter.format(jama.amount.toLong())}",
                    fontWeight = FontWeight.Bold,
                    color = ExcessGreen,
                    fontSize = 14.sp
                )
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = ShortageRed, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
private fun AkhrajatRowCard(
    akhrajat: AkhrajatEntryEntity,
    formatter: NumberFormat,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(4.dp), color = SurfaceVariantLight) {
                        Text(akhrajat.category, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp))
                    }
                    if (akhrajat.voucherNo.isNotEmpty()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(akhrajat.voucherNo, fontSize = 11.sp, color = TextSecondaryLight)
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = akhrajat.tafseel, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "PKR ${formatter.format(akhrajat.amount.toLong())}",
                    fontWeight = FontWeight.Bold,
                    color = ShortageRed,
                    fontSize = 14.sp
                )
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = ShortageRed, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
private fun StockDipRowCard(
    dip: StockDipEntryEntity,
    formatter: NumberFormat,
    onEdit: () -> Unit
) {
    val kamZiada = dip.kamZiadaLitres
    val isLoss = kamZiada < -10.0
    val isGain = kamZiada > 10.0

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 5.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(dip.tankName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Dip", tint = PetrolTealPrimary, modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("ڈپ راڈ (CM)", fontSize = 11.sp, color = TextSecondaryLight)
                    Text("${dip.dipCm} cm", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Column {
                    Text("فزیکل ڈپ لٹر", fontSize = 11.sp, color = TextSecondaryLight)
                    Text("${formatter.format(dip.physicalDipLitres.toLong())} L", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Column {
                    Text("بک اسٹاک", fontSize = 11.sp, color = TextSecondaryLight)
                    Text("${formatter.format(dip.bookStock.toLong())} L", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("کم / زیادہ", fontSize = 11.sp, color = TextSecondaryLight)
                    val sign = if (kamZiada > 0) "+" else ""
                    Text(
                        text = "$sign${kamZiada.toInt()} L",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = if (isLoss) ShortageRed else if (isGain) ExcessGreen else TextPrimaryLight
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyForecourtState(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
    }
}
