package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserAccountEntity
import com.example.domain.AppLanguage
import com.example.ui.components.CupertinoSegmentedControl
import com.example.ui.theme.*
import com.example.ui.viewmodel.PumpUiState
import com.example.ui.viewmodel.PumpViewModel

@Composable
fun AuthScreen(
    state: PumpUiState,
    viewModel: PumpViewModel,
    modifier: Modifier = Modifier
) {
    val lang = state.currentLanguage
    val hasRegisteredUsers = state.allUsers.isNotEmpty()

    // If no users exist yet, default strictly to Register tab (1)
    // If users already exist, default to Login tab (0)
    var selectedAuthTab by remember(hasRegisteredUsers) {
        mutableIntStateOf(if (hasRegisteredUsers) 0 else 1)
    }

    var selectedUserForLogin by remember(state.allUsers) {
        mutableStateOf(state.allUsers.firstOrNull())
    }

    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }

    // Registration Form State
    var regFullName by remember { mutableStateOf("") }
    var regUsername by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("") }
    var regRole by remember { mutableStateOf("Owner") }
    var regPin by remember { mutableStateOf("") }
    var regConfirmPin by remember { mutableStateOf("") }
    var regError by remember { mutableStateOf<String?>(null) }
    var regPinVisible by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current

    Surface(
        modifier = modifier
            .fillMaxSize()
            .testTag("auth_screen"),
        color = BackgroundLight
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // 1. Station Branding Header & Language Switcher
            Surface(
                color = PetrolTealPrimary,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Euro Logo & Name
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(EuroGoldPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocalGasStation,
                                    contentDescription = "Euro Station Logo",
                                    tint = PetrolTealDark,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = state.appConfig?.stationName ?: "حسن بابا پیٹرولیم",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp,
                                        color = Color.White,
                                        fontFamily = NotoNastaliqUrduFamily
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = EuroGoldPrimary
                                    ) {
                                        Text(
                                            text = state.appConfig?.brand ?: "EURO",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 9.sp,
                                            color = PetrolTealDark,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = state.appConfig?.location ?: "Jaffarabad Road, Pan Minara, RYK",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        }

                        // Trilingual Quick Language Switcher
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(PetrolTealDark.copy(alpha = 0.6f))
                                .padding(2.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            AppLanguage.values().forEach { l ->
                                val isSelected = l == lang
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(if (isSelected) EuroGoldPrimary else Color.Transparent)
                                        .clickable { viewModel.setLanguage(l) }
                                        .padding(horizontal = 7.dp, vertical = 3.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = when(l) {
                                            AppLanguage.URDU -> "اردو"
                                            AppLanguage.ROMAN_URDU -> "Roman"
                                            AppLanguage.ENGLISH -> "Eng"
                                        },
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) PetrolTealDark else Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 2. Navigation Tabs (Cupertino Segmented Control: Login vs Register)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                val tabLabels = when (lang) {
                    AppLanguage.URDU -> listOf("لاگ ان (Login)", "نیا رجسٹریشن (Register)")
                    AppLanguage.ROMAN_URDU -> listOf("Login", "Naya Register")
                    AppLanguage.ENGLISH -> listOf("Sign In", "Create Account")
                }

                CupertinoSegmentedControl(
                    items = tabLabels,
                    selectedIndex = selectedAuthTab,
                    onItemSelected = { index ->
                        selectedAuthTab = index
                        pinError = null
                        regError = null
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_tab_selector")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Content View (Login vs Register)
                AnimatedContent(
                    targetState = selectedAuthTab,
                    label = "AuthTabTransition"
                ) { currentTab ->
                    if (currentTab == 0) {
                        // ==========================================
                        // LOGIN SECTION
                        // ==========================================
                        if (!hasRegisteredUsers) {
                            // No users registered yet -> instruct user to register first
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 16.dp),
                                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                                shape = RoundedCornerShape(16.dp),
                                elevation = CardDefaults.cardElevation(2.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PersonAdd,
                                        contentDescription = "Register First",
                                        tint = EuroGoldPrimary,
                                        modifier = Modifier.size(54.dp)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "پہلے اکاؤنٹ رجسٹر کریں",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = PetrolTealDark,
                                        fontFamily = NotoNastaliqUrduFamily,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "ابھی تک اس ایپ پر کوئی اکاؤنٹ موجود نہیں ہے۔ برائے مہربانی پہلے اپنا اکاؤنٹ رجسٹر کریں، جس کے بعد آپ لاگ ان ہو سکیں گے اور مزید جتنے چاہیں اتنے اکاؤنٹس بنا سکیں گے۔",
                                        fontSize = 13.sp,
                                        color = TextSecondaryLight,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 20.sp
                                    )
                                    Spacer(modifier = Modifier.height(20.dp))
                                    Button(
                                        onClick = { selectedAuthTab = 1 },
                                        colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp)
                                            .testTag("go_to_register_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ArrowForward,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "پہلا اکاؤنٹ رجسٹر کریں (Create First Account)",
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        } else {
                            // Users exist -> Apple-Style Multi-Account Selector & Quick PIN Login
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                item {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "اکاؤنٹ منتخب کریں (Select Account)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = PetrolTealDark
                                        )
                                        // Quick register shortcut for creating multiple accounts
                                        TextButton(
                                            onClick = { selectedAuthTab = 1 },
                                            modifier = Modifier.testTag("create_more_account_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.AddCircleOutline,
                                                contentDescription = null,
                                                tint = EuroGoldDark,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "+ نیا اکاؤنٹ بنائیں",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = EuroGoldDark
                                            )
                                        }
                                    }
                                }

                                // Registered Account Cards
                                items(state.allUsers) { user ->
                                    val isSelected = selectedUserForLogin?.id == user.id
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                selectedUserForLogin = user
                                                enteredPin = ""
                                                pinError = null
                                            }
                                            .testTag("user_account_card_${user.id}"),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) PetrolTealPrimary.copy(alpha = 0.08f) else SurfaceLight
                                        ),
                                        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, PetrolTealPrimary) else null,
                                        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                // Avatar circle with role-based tint
                                                Box(
                                                    modifier = Modifier
                                                        .size(46.dp)
                                                        .clip(CircleShape)
                                                        .background(
                                                            when (user.role) {
                                                                "Owner" -> EuroGoldPrimary
                                                                "Manager" -> PetrolTealLight
                                                                "Cashier" -> Color(0xFF673AB7)
                                                                else -> Color(0xFF607D8B)
                                                            }
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = user.fullName.take(1).uppercase(),
                                                        fontWeight = FontWeight.Black,
                                                        fontSize = 18.sp,
                                                        color = Color.White
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Text(
                                                            text = user.fullName,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 15.sp,
                                                            color = TextPrimaryLight
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Surface(
                                                            shape = RoundedCornerShape(4.dp),
                                                            color = when (user.role) {
                                                                "Owner" -> EuroGoldPrimary.copy(alpha = 0.2f)
                                                                "Manager" -> PetrolTealPrimary.copy(alpha = 0.15f)
                                                                else -> Color.LightGray.copy(alpha = 0.3f)
                                                            }
                                                        ) {
                                                            Text(
                                                                text = when (user.role) {
                                                                    "Owner" -> "مالک / Owner"
                                                                    "Manager" -> "منیجر / Manager"
                                                                    "Cashier" -> "کیشئر / Cashier"
                                                                    "Oil Man" -> "آئل مین / Attendant"
                                                                    else -> user.role
                                                                },
                                                                fontSize = 10.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                color = PetrolTealDark,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                            )
                                                        }
                                                    }
                                                    Text(
                                                        text = "@${user.username}" + if (user.phoneNumber.isNotBlank()) " | ${user.phoneNumber}" else "",
                                                        fontSize = 12.sp,
                                                        color = TextSecondaryLight
                                                    )
                                                }
                                            }

                                            // Radio selection indicator
                                            RadioButton(
                                                selected = isSelected,
                                                onClick = {
                                                    selectedUserForLogin = user
                                                    enteredPin = ""
                                                    pinError = null
                                                },
                                                colors = RadioButtonDefaults.colors(selectedColor = PetrolTealPrimary)
                                            )
                                        }
                                    }
                                }

                                // PIN Verification Card for Selected User
                                selectedUserForLogin?.let { activeUser ->
                                    item {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(16.dp),
                                            colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(18.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                Text(
                                                    text = "${activeUser.fullName} کا 4 ہندسوں کا پن کوڈ درج کریں",
                                                    fontWeight = FontWeight.SemiBold,
                                                    fontSize = 13.sp,
                                                    color = TextPrimaryLight
                                                )

                                                Spacer(modifier = Modifier.height(12.dp))

                                                // PIN Dots indicator
                                                Row(
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    for (i in 0 until 4) {
                                                        val isFilled = i < enteredPin.length
                                                        Box(
                                                            modifier = Modifier
                                                                .size(16.dp)
                                                                .clip(CircleShape)
                                                                .background(
                                                                    if (isFilled) PetrolTealPrimary else Color.LightGray.copy(alpha = 0.5f)
                                                                )
                                                        )
                                                    }
                                                }

                                                if (pinError != null) {
                                                    Spacer(modifier = Modifier.height(8.dp))
                                                    Text(
                                                        text = pinError ?: "",
                                                        color = MaterialTheme.colorScheme.error,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                }

                                                Spacer(modifier = Modifier.height(16.dp))

                                                // Fast Apple-Style Touch Keypad (0-9, backspace, clear)
                                                ApplePinKeypad(
                                                    currentPin = enteredPin,
                                                    onPinChange = { newPin ->
                                                        enteredPin = newPin
                                                        pinError = null
                                                        // Auto submit if 4 digits entered
                                                        if (newPin.length == 4) {
                                                            viewModel.loginAccount(
                                                                user = activeUser,
                                                                enteredPin = newPin,
                                                                onError = { pinError = it }
                                                            )
                                                        }
                                                    }
                                                )

                                                Spacer(modifier = Modifier.height(14.dp))

                                                // Unlock button
                                                Button(
                                                    onClick = {
                                                        viewModel.loginAccount(
                                                            user = activeUser,
                                                            enteredPin = enteredPin,
                                                            onError = { pinError = it }
                                                        )
                                                    },
                                                    enabled = enteredPin.length >= 4,
                                                    colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                                                    shape = RoundedCornerShape(12.dp),
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(48.dp)
                                                        .testTag("login_submit_button")
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.LockOpen,
                                                        contentDescription = "Login",
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        text = "لاگ ان ہوں (Unlock Forecourt)",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 14.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // ==========================================
                        // REGISTRATION SECTION (MULTI-ACCOUNT)
                        // ==========================================
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                                    shape = RoundedCornerShape(16.dp),
                                    elevation = CardDefaults.cardElevation(2.dp)
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(36.dp)
                                                    .clip(CircleShape)
                                                    .background(EuroGoldPrimary.copy(alpha = 0.2f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.PersonAdd,
                                                    contentDescription = null,
                                                    tint = EuroGoldDark,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = if (!hasRegisteredUsers) "پہلا رجسٹریشن (Create First Account)" else "نیا اکاؤنٹ بنائیں (Create New Account)",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 16.sp,
                                                    color = PetrolTealDark
                                                )
                                                Text(
                                                    text = "اس ایپ پر آپ جتنے چاہیں اتنے اکاؤنٹس بنا سکتے ہیں",
                                                    fontSize = 11.sp,
                                                    color = TextSecondaryLight
                                                )
                                            }
                                        }

                                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                                        // Full Name
                                        OutlinedTextField(
                                            value = regFullName,
                                            onValueChange = {
                                                regFullName = it
                                                regError = null
                                            },
                                            label = { Text("مکمل نام (Full Name)*") },
                                            placeholder = { Text("مثلاً: ملک حسن بابا") },
                                            leadingIcon = {
                                                Icon(Icons.Default.Badge, contentDescription = null, tint = PetrolTealPrimary)
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("reg_fullname_input"),
                                            singleLine = true,
                                            shape = RoundedCornerShape(10.dp)
                                        )

                                        Spacer(modifier = Modifier.height(10.dp))

                                        // Username or Phone
                                        OutlinedTextField(
                                            value = regUsername,
                                            onValueChange = {
                                                regUsername = it
                                                regError = null
                                            },
                                            label = { Text("یوزر نیم یا موبائل نمبر (Username / Mobile)*") },
                                            placeholder = { Text("مثلاً: hassanbaba یا 03001234567") },
                                            leadingIcon = {
                                                Icon(Icons.Default.AccountCircle, contentDescription = null, tint = PetrolTealPrimary)
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("reg_username_input"),
                                            singleLine = true,
                                            shape = RoundedCornerShape(10.dp)
                                        )

                                        Spacer(modifier = Modifier.height(10.dp))

                                        // Role Selector (Owner, Manager, Cashier, Oil Man)
                                        Text(
                                            text = "عہدہ / کردار (Select Role)*",
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 12.sp,
                                            color = TextSecondaryLight
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            val roles = listOf(
                                                Pair("Owner", "مالک"),
                                                Pair("Manager", "منیجر"),
                                                Pair("Cashier", "کیشئر"),
                                                Pair("Oil Man", "آئل مین")
                                            )
                                            roles.forEach { (roleKey, roleLabel) ->
                                                val isSelected = regRole == roleKey
                                                Surface(
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = if (isSelected) PetrolTealPrimary else BackgroundLight,
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .clickable { regRole = roleKey }
                                                        .border(
                                                            width = 1.dp,
                                                            color = if (isSelected) PetrolTealPrimary else Color.LightGray.copy(alpha = 0.5f),
                                                            shape = RoundedCornerShape(8.dp)
                                                        )
                                                ) {
                                                    Text(
                                                        text = roleLabel,
                                                        fontSize = 11.sp,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                        color = if (isSelected) Color.White else TextPrimaryLight,
                                                        textAlign = TextAlign.Center,
                                                        modifier = Modifier.padding(vertical = 8.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        // 4-Digit Security PIN
                                        OutlinedTextField(
                                            value = regPin,
                                            onValueChange = {
                                                if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                                                    regPin = it
                                                    regError = null
                                                }
                                            },
                                            label = { Text("4 ہندسوں کا سیکیورٹی پن (4-Digit PIN)*") },
                                            placeholder = { Text("مثلاً: 1234") },
                                            leadingIcon = {
                                                Icon(Icons.Default.Lock, contentDescription = null, tint = PetrolTealPrimary)
                                            },
                                            trailingIcon = {
                                                IconButton(onClick = { regPinVisible = !regPinVisible }) {
                                                    Icon(
                                                        imageVector = if (regPinVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                                        contentDescription = "Toggle PIN visibility"
                                                    )
                                                }
                                            },
                                            visualTransformation = if (regPinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("reg_pin_input"),
                                            singleLine = true,
                                            shape = RoundedCornerShape(10.dp)
                                        )

                                        Spacer(modifier = Modifier.height(10.dp))

                                        // Confirm PIN
                                        OutlinedTextField(
                                            value = regConfirmPin,
                                            onValueChange = {
                                                if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                                                    regConfirmPin = it
                                                    regError = null
                                                }
                                            },
                                            label = { Text("پن کوڈ کی تصدیق (Confirm PIN)*") },
                                            placeholder = { Text("دوبارہ پن کوڈ درج کریں") },
                                            leadingIcon = {
                                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PetrolTealPrimary)
                                            },
                                            visualTransformation = if (regPinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("reg_confirm_pin_input"),
                                            singleLine = true,
                                            shape = RoundedCornerShape(10.dp)
                                        )

                                        Spacer(modifier = Modifier.height(10.dp))

                                        // Optional Phone Number
                                        OutlinedTextField(
                                            value = regPhone,
                                            onValueChange = { regPhone = it },
                                            label = { Text("موبائل فون نمبر (اختیاری / Optional Phone)") },
                                            placeholder = { Text("مثلاً: 0300-1234567") },
                                            leadingIcon = {
                                                Icon(Icons.Default.Phone, contentDescription = null, tint = PetrolTealPrimary)
                                            },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("reg_phone_input"),
                                            singleLine = true,
                                            shape = RoundedCornerShape(10.dp)
                                        )

                                        // Error text if validation fails
                                        if (regError != null) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = regError ?: "",
                                                color = MaterialTheme.colorScheme.error,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(18.dp))

                                        // Submit Registration Button
                                        Button(
                                            onClick = {
                                                focusManager.clearFocus()
                                                if (regFullName.trim().isEmpty()) {
                                                    regError = "برائے مہربانی اپنا مکمل نام درج کریں۔"
                                                    return@Button
                                                }
                                                if (regUsername.trim().isEmpty()) {
                                                    regError = "برائے مہربانی یوزر نیم درج کریں۔"
                                                    return@Button
                                                }
                                                if (regPin.trim().length < 4) {
                                                    regError = "پن کوڈ کم از کم 4 ہندسوں پر مشتمل ہونا چاہیے۔"
                                                    return@Button
                                                }
                                                if (regPin != regConfirmPin) {
                                                    regError = "پن کوڈ اور تصدیقی پن کوڈ ایک جیسے نہیں ہیں!"
                                                    return@Button
                                                }

                                                viewModel.registerAccount(
                                                    fullName = regFullName,
                                                    username = regUsername,
                                                    role = regRole,
                                                    pin = regPin,
                                                    phone = regPhone,
                                                    autoLogin = true,
                                                    onError = { regError = it }
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = EuroGoldPrimary),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(50.dp)
                                                .testTag("register_submit_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = PetrolTealDark,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "اکاؤنٹ رجسٹر کریں اور داخل ہوں (Register & Login)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = PetrolTealDark
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Apple-style touch keypad for fast numeric PIN entry.
 */
@Composable
private fun ApplePinKeypad(
    currentPin: String,
    onPinChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val rows = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("C", "0", "⌫")
    )

    Column(
        modifier = modifier.widthIn(max = 280.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        rows.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                row.forEach { key ->
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                when (key) {
                                    "C" -> onPinChange("")
                                    "⌫" -> if (currentPin.isNotEmpty()) onPinChange(currentPin.dropLast(1))
                                    else -> if (currentPin.length < 6) onPinChange(currentPin + key)
                                }
                            }
                            .testTag("keypad_key_$key"),
                        color = when (key) {
                            "C", "⌫" -> BackgroundLight
                            else -> SurfaceLight
                        },
                        tonalElevation = 1.dp,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.35f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = key,
                                fontWeight = FontWeight.Bold,
                                fontSize = if (key.length == 1 && key[0].isDigit()) 20.sp else 14.sp,
                                color = when (key) {
                                    "C" -> MaterialTheme.colorScheme.error
                                    "⌫" -> PetrolTealDark
                                    else -> TextPrimaryLight
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
