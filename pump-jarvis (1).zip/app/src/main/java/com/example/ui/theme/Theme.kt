package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EuroGoldPrimary,
    onPrimary = PetrolTealDark,
    primaryContainer = PetrolTealMedium,
    onPrimaryContainer = EuroGoldLight,
    secondary = PetrolTealLight,
    onSecondary = Color.White,
    secondaryContainer = SurfaceVariantDark,
    onSecondaryContainer = EuroGoldLight,
    background = BackgroundDark,
    onBackground = TextPrimaryDark,
    surface = SurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondaryDark,
    error = ShortageRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = PetrolTealPrimary,
    onPrimary = Color.White,
    primaryContainer = PetrolTealLight,
    onPrimaryContainer = Color.White,
    secondary = EuroGoldPrimary,
    onSecondary = PetrolTealDark,
    secondaryContainer = EuroGoldLight,
    onSecondaryContainer = PetrolTealDark,
    background = BackgroundLight,
    onBackground = TextPrimaryLight,
    surface = SurfaceLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = TextSecondaryLight,
    error = ShortageRed,
    onError = Color.White
)

@Composable
fun MyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
