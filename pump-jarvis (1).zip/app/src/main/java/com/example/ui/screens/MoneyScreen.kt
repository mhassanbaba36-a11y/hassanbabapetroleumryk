package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountEntity
import com.example.data.model.LubricantProductEntity
import com.example.ui.components.CupertinoSegmentedControl
import com.example.ui.theme.*
import com.example.ui.viewmodel.PumpUiState
import com.example.ui.viewmodel.PumpViewModel
import java.text.NumberFormat
import java.util.*

@Composable
fun MoneyScreen(
    state: PumpUiState,
    viewModel: PumpViewModel,
    modifier: Modifier = Modifier
) {
    val formatter = remember { NumberFormat.getNumberInstance(Locale.US) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Accounts & Banking, 1: Mobil Oil / Lubricants, 2: Recoveries
    var showAddTransactionDialog by remember { mutableStateOf(false) }

    // Computations
    val totalMoneyInAccounts = state.accounts.sumOf { it.balance }
    val totalIn = state.transactions.filter { it.direction == "IN" }.sumOf { it.amount }
    val totalOut = state.transactions.filter { it.direction == "OUT" }.sumOf { it.amount }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .testTag("money_screen"),
        contentPadding = PaddingValues(14.dp)
    ) {
        // 1. Overall Balance Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = PetrolTealPrimary),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "کل بینک و ڈیجیٹل بیلنس (Total Bank & JazzCash Balance)",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                    Text(
                        text = "PKR ${formatter.format(totalMoneyInAccounts.toLong())}",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = EuroGoldLight
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.2f), thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("کتنا پیسہ آیا (Total IN)", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                            Text("+PKR ${formatter.format(totalIn.toLong())}", color = ExcessGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("کتنا پیسہ گیا (Total OUT)", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                            Text("-PKR ${formatter.format(totalOut.toLong())}", color = ShortageRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // 2. Tab Navigation - Apple iOS Cupertino Segmented Control
        item {
            Spacer(modifier = Modifier.height(12.dp))
            CupertinoSegmentedControl(
                items = listOf("بینک و اکاؤنٹس", "موبل آئل اسٹاک", "ریکوری لسٹ"),
                selectedIndex = selectedTab,
                onItemSelected = { selectedTab = it }
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        // 3. Tab Contents
        when (selectedTab) {
            // TAB 0: BANK ACCOUNTS & JAZZCASH
            0 -> {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("بینک، جاز کیش اور ایزی پیسہ اکاؤنٹس:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Button(
                            onClick = { showAddTransactionDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                            modifier = Modifier.testTag("add_money_transaction_btn")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ٹرانزیکشن درج", fontSize = 12.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                items(items = state.accounts, key = { it.id }) { acc ->
                    AccountCard(account = acc, formatter = formatter)
                }

                item {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("حالیہ بینک و کیش ٹرانزیکشنز:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                }

                if (state.transactions.isEmpty()) {
                    item {
                        Text("کوئی ٹرانزیکشن موجود نہیں ہے۔ اوپر دیے گئے بٹن سے نیا اندراج کریں۔", fontSize = 12.sp, color = TextSecondaryLight)
                    }
                } else {
                    items(items = state.transactions, key = { it.id }) { txn ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = txn.purpose, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(text = "${txn.date} | ${txn.linkedParty} (${txn.voucherNo})", fontSize = 11.sp, color = TextSecondaryLight)
                                }
                                Text(
                                    text = "${if (txn.direction == "IN") "+" else "-"}PKR ${formatter.format(txn.amount.toLong())}",
                                    fontWeight = FontWeight.Bold,
                                    color = if (txn.direction == "IN") ExcessGreen else ShortageRed,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }

            // TAB 1: LUBRICANTS & MOBIL OIL
            1 -> {
                item {
                    Text("موبل آئل و لیوبریکنٹس کیٹلاگ و اسٹاک:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                }

                items(items = state.lubricants, key = { it.id }) { lub ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = "${lub.brand} ${lub.grade}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(text = "پیک سائز: ${lub.packSize}", fontSize = 11.sp, color = TextSecondaryLight)
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (lub.stockQuantity <= lub.minStockThreshold) ShortageRedBg else DieselGreenLight
                                ) {
                                    Text(
                                        text = "اسٹاک: ${lub.stockQuantity} کین",
                                        fontWeight = FontWeight.Bold,
                                        color = if (lub.stockQuantity <= lub.minStockThreshold) ShortageRed else DieselGreen,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("خرید قیمت: PKR ${formatter.format(lub.purchasePrice.toLong())}", fontSize = 11.sp, color = TextSecondaryLight)
                                Text("سیل ریٹ: PKR ${formatter.format(lub.salePrice.toLong())}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = EuroGoldDark)
                                Text("منافع فی کین: PKR ${(lub.salePrice - lub.purchasePrice).toInt()}", fontSize = 11.sp, color = ExcessGreen, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // TAB 2: RECOVERIES
            2 -> {
                item {
                    Text("پینڈنگ ریکوری فالو اپ (Pending Khata Recoveries):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                }

                val pendingCustomers = state.customers.take(6)
                items(pendingCustomers) { cust ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(cust.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("فون: ${cust.phone} | وعدہ تاریخ: پیر", fontSize = 11.sp, color = TextSecondaryLight)
                            }
                            Text("فالو اپ الرٹ 🔔", fontSize = 12.sp, color = EuroGoldDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Modal: Add Transaction
    if (showAddTransactionDialog) {
        var accountId by remember { mutableStateOf(state.accounts.firstOrNull()?.id ?: 1L) }
        var direction by remember { mutableStateOf("IN") }
        var amountText by remember { mutableStateOf("") }
        var purpose by remember { mutableStateOf("Forecourt Cash Deposit") }
        var linkedParty by remember { mutableStateOf("") }
        var voucherNo by remember { mutableStateOf("V-${(100..999).random()}") }

        AlertDialog(
            onDismissRequest = { showAddTransactionDialog = false },
            title = { Text("بینک / ڈیجیٹل ٹرانزیکشن درج کریں", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = direction == "IN", onClick = { direction = "IN" }, label = { Text("آمدن IN (جمع)") })
                        FilterChip(selected = direction == "OUT", onClick = { direction = "OUT" }, label = { Text("اخراج OUT (نکالیں)") })
                    }
                    OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("رقم Amount (PKR)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth().testTag("money_amount_input"))
                    OutlinedTextField(value = purpose, onValueChange = { purpose = it }, label = { Text("مقصد و تفصیل (Purpose)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = linkedParty, onValueChange = { linkedParty = it }, label = { Text("متعلقہ شخص / کھاتہ") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = voucherNo, onValueChange = { voucherNo = it }, label = { Text("واؤچر / چیک نمبر") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountText.toDoubleOrNull() ?: 0.0
                        if (amt > 0) {
                            viewModel.addTransaction(accountId, direction, amt, purpose, linkedParty, voucherNo)
                            showAddTransactionDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                    modifier = Modifier.testTag("submit_money_btn")
                ) {
                    Text("محفوظ کریں Save")
                }
            },
            dismissButton = { TextButton(onClick = { showAddTransactionDialog = false }) { Text("منسوخ") } }
        )
    }
}

@Composable
private fun AccountCard(
    account: AccountEntity,
    formatter: NumberFormat
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(account.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(account.accountNumber, fontSize = 11.sp, color = TextSecondaryLight)
            }
            Text(
                text = "PKR ${formatter.format(account.balance.toLong())}",
                fontWeight = FontWeight.Bold,
                color = PetrolTealPrimary,
                fontSize = 14.sp
            )
        }
    }
}
