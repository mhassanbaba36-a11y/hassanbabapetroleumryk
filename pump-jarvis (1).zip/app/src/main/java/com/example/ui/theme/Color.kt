package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Hassan Baba Petroleum (Euro Brand) Palette
val PetrolTealDark = Color(0xFF072725)
val PetrolTealPrimary = Color(0xFF0D3B3A)
val PetrolTealMedium = Color(0xFF14534F)
val PetrolTealLight = Color(0xFF1F706B)

val EuroGoldPrimary = Color(0xFFE5A91E)
val EuroGoldLight = Color(0xFFFBBF24)
val EuroGoldDark = Color(0xFFB45309)

// Fuel Type Distinct Colors
val DieselGreen = Color(0xFF15803D)
val DieselGreenLight = Color(0xFFDCFCE7)
val PetrolAmber = Color(0xFFC2410C)
val PetrolAmberLight = Color(0xFFFFEDD5)
val MobilOilIndigo = Color(0xFF4338CA)
val MobilOilLight = Color(0xFFE0E7FF)

// Status & Variances
val ShortageRed = Color(0xFFDC2626)
val ShortageRedBg = Color(0xFFFEE2E2)
val ExcessGreen = Color(0xFF16A34A)
val ExcessGreenBg = Color(0xFFDCFCE7)

// Neutral Grays & Surfaces
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val BorderLight = Color(0xFFE2E8F0)

val BackgroundDark = Color(0xFF0B131B)
val SurfaceDark = Color(0xFF131F2B)
val SurfaceVariantDark = Color(0xFF1B2A3A)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val BorderDark = Color(0xFF26394D)
