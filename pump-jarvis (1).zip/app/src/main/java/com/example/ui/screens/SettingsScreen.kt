package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.PumpUiState
import com.example.ui.viewmodel.PumpViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun SettingsScreen(
    state: PumpUiState,
    viewModel: PumpViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showEditStationDialog by remember { mutableStateOf(false) }
    var showFormulaEditorDialog by remember { mutableStateOf(false) }
    var showAuditLogDialog by remember { mutableStateOf(false) }
    var showAddUserDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .testTag("settings_screen"),
        contentPadding = PaddingValues(14.dp)
    ) {
        // Station Configuration Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = state.appConfig?.stationName ?: "Hassan Baba Petroleum",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = PetrolTealPrimary
                            )
                            Text(
                                text = "${state.appConfig?.brand ?: "Euro"} | ${state.appConfig?.location ?: "Pan Minara, RYK"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryLight
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = EuroGoldPrimary
                        ) {
                            Text(
                                text = state.appConfig?.version ?: "v1.0",
                                color = PetrolTealDark,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "مالک پن کوڈ: **** (صرف مالک کو شفٹ لاک کھولنے اور ڈیلیٹ کی اجازت ہے)",
                        fontSize = 11.sp,
                        color = TextSecondaryLight
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // App Builder & Schema Customizer
        item {
            Text("ایپ بلڈر و کسٹمائزیشن (Self-Editable App Builder):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceLight)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SettingActionRow(
                        title = "اکاؤنٹنگ فارمولا تبدیل کریں (Formula Engine)",
                        subtitle = "کیش مفاہمت اور اسٹاک کا حسابی فارمولا ایڈٹ کریں",
                        onClick = { showFormulaEditorDialog = true }
                    )
                    HorizontalDivider(color = BorderLight, thickness = 0.5.dp)
                    SettingActionRow(
                        title = "نوزلز و ٹینکس کنفیگریشن",
                        subtitle = "نوزل کے نام، پراڈکٹ اور ٹینک کیلیبریشن چارٹ تبدیل کریں",
                        onClick = { showEditStationDialog = true }
                    )
                    HorizontalDivider(color = BorderLight, thickness = 0.5.dp)
                    SettingActionRow(
                        title = "آڈٹ ٹریل لاگ (Immutable Forecourt Audit)",
                        subtitle = "${state.auditLogs.size} ایکشنز ریکارڈ شدہ ہیں",
                        onClick = { showAuditLogDialog = true }
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // User Accounts & Multi-Account Management
        item {
            Text(
                text = "اکاؤنٹس مینجمنٹ (User Accounts & Multi-Account):",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "موجودہ لاگ ان: ${state.currentUser?.fullName ?: "غیر تصدیق شدہ"}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = PetrolTealDark
                            )
                            Text(
                                text = "عہدہ: ${state.currentUser?.role ?: "User"} | کل رجسٹرڈ: ${state.allUsers.size}",
                                fontSize = 11.sp,
                                color = TextSecondaryLight
                            )
                        }
                        Button(
                            onClick = { viewModel.logout() },
                            colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("لاگ آؤٹ / سوئچ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = BorderLight, thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "رجسٹرڈ یوزر اکاؤنٹس (User Accounts List):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimaryLight
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    state.allUsers.forEach { user ->
                        val isCurrentUser = state.currentUser?.id == user.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(androidx.compose.foundation.shape.CircleShape)
                                        .background(if (isCurrentUser) EuroGoldPrimary else Color.LightGray.copy(alpha = 0.5f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = user.fullName.take(1).uppercase(),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (isCurrentUser) PetrolTealDark else Color.DarkGray
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = user.fullName,
                                            fontWeight = if (isCurrentUser) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 13.sp,
                                            color = TextPrimaryLight
                                        )
                                        if (isCurrentUser) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = DieselGreenLight
                                            ) {
                                                Text(
                                                    text = "فعال / Active",
                                                    color = DieselGreen,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = "@${user.username} (${user.role})" + if (user.phoneNumber.isNotBlank()) " - ${user.phoneNumber}" else "",
                                        fontSize = 11.sp,
                                        color = TextSecondaryLight
                                    )
                                }
                            }

                            if (!isCurrentUser && state.allUsers.size > 1) {
                                IconButton(
                                    onClick = { viewModel.deleteUserAccount(user) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Delete Account",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = { showAddUserDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_user_settings_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.PersonAdd, contentDescription = null, tint = PetrolTealPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "+ نیا اکاؤنٹ بنائیں (Add New Account)",
                            fontWeight = FontWeight.Bold,
                            color = PetrolTealPrimary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Future Company Integration Layer (Euro Oil API Adapter)
        item {
            Text("یورو آئل کمپنی سسٹم انٹیگریشن (Company API Adapter):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceLight)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Euro Oil Pakistan Auto-Sync", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("API انوائس، ڈلیوری اور ریٹ خودبخود اپڈیٹ ہوں گے", fontSize = 11.sp, color = TextSecondaryLight)
                        }
                        Surface(shape = RoundedCornerShape(4.dp), color = DieselGreenLight) {
                            Text("Adapter Ready", color = DieselGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("اینڈ پوائنٹ: https://api.eurooil.com.pk/v1/dealers/hb-petrol-ryk", fontSize = 11.sp, color = TextSecondaryLight)
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Backup, Export & Restore
        item {
            Text("ڈیٹا بیک اپ و ایکسپورٹ (Offline Backup & Restore):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        exportDatabaseBackup(context, state)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                    modifier = Modifier.weight(1f).testTag("export_backup_btn")
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = "Backup", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("بیک اپ ایکسپورٹ", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = {
                        // Restore feedback
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.Restore, contentDescription = "Restore", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ری اسٹور Restore", fontSize = 12.sp)
                }
            }
        }
    }

    // Modal: Formula Editor Dialog
    if (showFormulaEditorDialog) {
        AlertDialog(
            onDismissRequest = { showFormulaEditorDialog = false },
            title = { Text("فارمولا ایڈیٹر (Editable Accounting Engine)", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("کیش مفاہمت حسابی فارمولا:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Surface(shape = RoundedCornerShape(6.dp), color = SurfaceVariantLight, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Expected Cash = Sabiqa Cash + Kul Sale + Jama - Less - Akhrajat - Udhaar - Bank Deposits",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("ٹینک شارٹیج فارمولا:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Surface(shape = RoundedCornerShape(6.dp), color = SurfaceVariantLight, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Book Stock = Sabiqa Stock + Amda - Sale\nKam/Ziada = Physical Dip Litres - Book Stock",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showFormulaEditorDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary)
                ) {
                    Text("محفوظ رکھیں (Version 1.1)")
                }
            },
            dismissButton = { TextButton(onClick = { showFormulaEditorDialog = false }) { Text("بند کریں") } }
        )
    }

    // Modal: Audit Log Viewer Dialog
    if (showAuditLogDialog) {
        val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
        AlertDialog(
            onDismissRequest = { showAuditLogDialog = false },
            title = { Text("آڈٹ لاگ لاگز (Immutable Forecourt Audit)", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(modifier = Modifier.height(280.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(state.auditLogs) { log ->
                        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(log.action, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = PetrolTealDark)
                                Text(dateFormat.format(Date(log.timestamp)), fontSize = 10.sp, color = TextSecondaryLight)
                            }
                            Text(log.details, fontSize = 11.sp, color = TextPrimaryLight)
                            HorizontalDivider(color = BorderLight, thickness = 0.5.dp, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showAuditLogDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary)) {
                    Text("بند کریں")
                }
            }
        )
    }

    if (showEditStationDialog) {
        AlertDialog(
            onDismissRequest = { showEditStationDialog = false },
            title = { Text("نوزل اور اسٹیشن سیٹنگز", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("نوزلز: 6 فعال (ڈیزل 1 و 2، پٹرول 3، 4، 5، 6)", fontSize = 12.sp)
                    Text("ٹینک: 4 انڈرگراؤنڈ کیلیبریٹڈ ٹینک (25,000L فی ٹینک)", fontSize = 12.sp)
                    Text("پمپ مالک: حسن بابا | شہر: رحیم یار خان", fontSize = 12.sp)
                }
            },
            confirmButton = {
                Button(onClick = { showEditStationDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary)) {
                    Text("ٹھیک ہے")
                }
            }
        )
    }
}

@Composable
private fun SettingActionRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(subtitle, fontSize = 11.sp, color = TextSecondaryLight)
        }
        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Go", tint = TextSecondaryLight)
    }
}

private fun exportDatabaseBackup(context: Context, state: PumpUiState) {
    val backupSummary = """
        === حسن بابا پیٹرولیم (Hassan Baba Petroleum) ===
        بیک اپ تاریخ: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}
        مقام: جعفرآباد روڈ، پنج منارہ، رحیم یار خان
        برانڈ: یورو آئل (Euro Brand)
        
        کل کسٹمر کھاتے: ${state.customers.size}
        کل مارکیٹ ادھار: PKR ${state.allKhataEntries.filter { it.entryType == com.example.data.model.KhataEntryType.UDHAAR }.sumOf { it.amount }}
        کمپنی قابل ادائیگی: PKR ${state.companyDeliveries.sumOf { it.totalBillAmount } - state.companyPayments.sumOf { it.amount }}
        بینک و جاز کیش بیلنس: PKR ${state.accounts.sumOf { it.balance }}
        موبل آئل اسٹاک اقسام: ${state.lubricants.size}
        آڈٹ لاگز: ${state.auditLogs.size} ایکشنز
    """.trimIndent()

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, backupSummary)
    }
    context.startActivity(Intent.createChooser(intent, "Export Pump Jarvis Backup"))
}
