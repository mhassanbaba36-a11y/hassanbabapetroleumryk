package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.PumpDatabase
import com.example.data.model.*
import com.example.data.repository.PumpRepository
import com.example.data.seed.DemoDataSeeder
import com.example.domain.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppNavScreen {
    DUTY_REGISTER,
    KHATA,
    COMPANY,
    MONEY,
    ANALYTICS,
    JARVIS,
    SETTINGS
}

data class PumpUiState(
    val currentScreen: AppNavScreen = AppNavScreen.DUTY_REGISTER,
    val currentLanguage: AppLanguage = AppLanguage.URDU,

    // Authentication & Multi-Account
    val currentUser: UserAccountEntity? = null,
    val allUsers: List<UserAccountEntity> = emptyList(),
    val isUserLoggedIn: Boolean = false,

    val activeShift: DutyShiftEntity? = null,
    val allShifts: List<DutyShiftEntity> = emptyList(),
    val nozzles: List<NozzleReadingEntity> = emptyList(),
    val jamaList: List<JamaEntryEntity> = emptyList(),
    val akhrajatList: List<AkhrajatEntryEntity> = emptyList(),
    val stockDips: List<StockDipEntryEntity> = emptyList(),
    val lessProducts: List<LessProductEntryEntity> = emptyList(),
    val reconciliation: ShiftReconciliationSummary? = null,
    
    // Khata
    val customers: List<CustomerEntity> = emptyList(),
    val allKhataEntries: List<KhataEntryEntity> = emptyList(),
    val selectedCustomer: CustomerEntity? = null,
    val customerQuery: String = "",
    
    // Company
    val companyDeliveries: List<CompanyDeliveryEntity> = emptyList(),
    val companyPayments: List<CompanyPaymentEntity> = emptyList(),
    
    // Money
    val accounts: List<AccountEntity> = emptyList(),
    val transactions: List<MoneyTransactionEntity> = emptyList(),
    val lubricants: List<LubricantProductEntity> = emptyList(),
    val recoveries: List<RecoveryItemEntity> = emptyList(),
    
    // Jarvis
    val jarvisMessages: List<JarvisMessage> = emptyList(),
    val proactiveAlerts: List<String> = emptyList(),
    val pendingAction: JarvisAction.RequireConfirmation? = null,
    
    // System
    val auditLogs: List<AuditLogEntity> = emptyList(),
    val appConfig: AppConfigEntity? = null,
    val isPinModalOpen: Boolean = false,
    val pinModalCallback: ((Boolean) -> Unit)? = null,
    val userMessageToast: String? = null
)

class PumpViewModel(application: Application) : AndroidViewModel(application) {

    private val db = PumpDatabase.getInstance(application)
    private val repository = PumpRepository(db.pumpDao())

    private val _uiState = MutableStateFlow(PumpUiState())
    val uiState: StateFlow<PumpUiState> = _uiState.asStateFlow()

    init {
        observeData()
        viewModelScope.launch {
            DemoDataSeeder.seedIfNeeded(db.pumpDao())
            initJarvisWelcome()
        }
    }

    private fun observeData() {
        viewModelScope.launch {
            repository.activeShift.collect { shift ->
                _uiState.update { it.copy(activeShift = shift) }
                if (shift != null) {
                    observeShiftDetails(shift.id)
                }
            }
        }
        viewModelScope.launch {
            repository.allShifts.collect { shifts ->
                _uiState.update { it.copy(allShifts = shifts) }
            }
        }
        viewModelScope.launch {
            repository.allCustomers.collect { list ->
                _uiState.update { it.copy(customers = list) }
                refreshAlerts()
            }
        }
        viewModelScope.launch {
            repository.allKhataEntries.collect { list ->
                _uiState.update { it.copy(allKhataEntries = list) }
                recomputeReconciliation()
                refreshAlerts()
            }
        }
        viewModelScope.launch {
            repository.companyDeliveries.collect { list ->
                _uiState.update { it.copy(companyDeliveries = list) }
                refreshAlerts()
            }
        }
        viewModelScope.launch {
            repository.companyPayments.collect { list ->
                _uiState.update { it.copy(companyPayments = list) }
            }
        }
        viewModelScope.launch {
            repository.accounts.collect { list ->
                _uiState.update { it.copy(accounts = list) }
            }
        }
        viewModelScope.launch {
            repository.transactions.collect { list ->
                _uiState.update { it.copy(transactions = list) }
            }
        }
        viewModelScope.launch {
            repository.lubricants.collect { list ->
                _uiState.update { it.copy(lubricants = list) }
                refreshAlerts()
            }
        }
        viewModelScope.launch {
            repository.auditLogs.collect { list ->
                _uiState.update { it.copy(auditLogs = list) }
            }
        }
        viewModelScope.launch {
            repository.appConfig.collect { config ->
                _uiState.update { it.copy(appConfig = config) }
            }
        }
        viewModelScope.launch {
            repository.allUsers.collect { users ->
                _uiState.update { current ->
                    // Keep currentUser in sync if updated/deleted
                    val matchedUser = current.currentUser?.let { cur ->
                        users.find { it.id == cur.id }
                    }
                    current.copy(
                        allUsers = users,
                        currentUser = matchedUser,
                        isUserLoggedIn = matchedUser != null
                    )
                }
            }
        }
    }

    private var shiftDetailsJob: Job? = null

    private fun observeShiftDetails(shiftId: Long) {
        shiftDetailsJob?.cancel()
        shiftDetailsJob = viewModelScope.launch {
            launch {
                repository.getNozzlesForShift(shiftId).collect { list ->
                    _uiState.update { it.copy(nozzles = list) }
                    recomputeReconciliation()
                }
            }
            launch {
                repository.getJamaForShift(shiftId).collect { list ->
                    _uiState.update { it.copy(jamaList = list) }
                    recomputeReconciliation()
                }
            }
            launch {
                repository.getAkhrajatForShift(shiftId).collect { list ->
                    _uiState.update { it.copy(akhrajatList = list) }
                    recomputeReconciliation()
                }
            }
            launch {
                repository.getDipsForShift(shiftId).collect { list ->
                    _uiState.update { it.copy(stockDips = list) }
                }
            }
            launch {
                repository.getLessProductsForShift(shiftId).collect { list ->
                    _uiState.update { it.copy(lessProducts = list) }
                    recomputeReconciliation()
                }
            }
        }
    }

    private fun recomputeReconciliation() {
        val state = _uiState.value
        val shift = state.activeShift ?: return
        val nozzles = state.nozzles
        val jama = state.jamaList
        val akhrajat = state.akhrajatList
        val less = state.lessProducts
        
        // Compute total udhaar given in this shift
        val shiftUdhaar = state.allKhataEntries
            .filter { it.date == shift.shiftDate && it.entryType == KhataEntryType.UDHAAR }
            .sumOf { it.amount }

        val summary = FormulaEngine.calculateShift(
            shift = shift,
            nozzles = nozzles,
            jamaList = jama,
            akhrajatList = akhrajat,
            lessList = less,
            khataUdhaarGiven = shiftUdhaar,
            bankDepositsFromForecourt = 0.0,
            mobilOilSale = 0.0,
            deegarSale = 0.0
        )
        _uiState.update { it.copy(reconciliation = summary) }
    }

    private fun refreshAlerts() {
        val state = _uiState.value
        val alerts = JarvisEngine.getProactiveAlerts(
            customers = state.customers,
            khataEntries = state.allKhataEntries,
            lubricants = state.lubricants,
            deliveries = state.companyDeliveries
        )
        _uiState.update { it.copy(proactiveAlerts = alerts) }
    }

    private fun initJarvisWelcome() {
        val welcome = JarvisMessage(
            isUser = false,
            text = "السلام علیکم حسن بابا صاحب! میں پمپ جاروس ہوں۔ میں آپ کے پمپ کی تمام سیلز، کیش کا حساب، ادھار کھاتے، اور یورو کمپنی کی شارٹیج سنبھالنے کے لیے حاضر ہوں۔ بولیں یا لکھیں، میں فوراً کام کروں گا۔"
        )
        _uiState.update { it.copy(jarvisMessages = listOf(welcome)) }
    }

    // --- Navigation & Language Actions ---
    fun setScreen(screen: AppNavScreen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun setLanguage(lang: AppLanguage) {
        _uiState.update { it.copy(currentLanguage = lang) }
    }

    fun clearToast() {
        _uiState.update { it.copy(userMessageToast = null) }
    }

    // --- Duty Register Actions ---
    fun updateDailyRates(petrol: Double, diesel: Double) {
        viewModelScope.launch {
            val shift = _uiState.value.activeShift ?: return@launch
            val updatedShift = shift.copy(petrolRate = petrol, dieselRate = diesel)
            repository.updateShift(updatedShift)

            // Update nozzle rates
            _uiState.value.nozzles.forEach { nozzle ->
                val newRate = if (nozzle.fuelType == FuelType.DIESEL) diesel else petrol
                repository.updateNozzleReading(nozzle.copy(rate = newRate))
            }
            _uiState.update { it.copy(userMessageToast = "ریٹ تبدیل ہو گئے: پٹرول Rs $petrol, ڈیزل Rs $diesel") }
        }
    }

    fun updateCountedCash(cash: Double) {
        viewModelScope.launch {
            val shift = _uiState.value.activeShift ?: return@launch
            repository.updateShift(shift.copy(countedCash = cash))
        }
    }

    fun updateNozzleReading(nozzle: NozzleReadingEntity, maujooda: Double, wapsi: Double, isReset: Boolean = false, reason: String = "") {
        viewModelScope.launch {
            if (maujooda < nozzle.sabiqaReading && !isReset) {
                _uiState.update { it.copy(userMessageToast = "وارننگ: موجودہ ریڈنگ سابقہ سے کم ہے! ری سیٹ فلیگ منتخب کریں۔") }
                return@launch
            }
            val updated = nozzle.copy(
                maujoodaReading = maujooda,
                wapsiTankLitres = wapsi,
                isResetFlag = isReset,
                resetReason = reason
            )
            repository.updateNozzleReading(updated)
        }
    }

    fun addJamaEntry(amount: Double, fromParty: String, khataNo: String, tafseel: String) {
        viewModelScope.launch {
            val shiftId = _uiState.value.activeShift?.id ?: return@launch
            val entry = JamaEntryEntity(
                shiftId = shiftId,
                amount = amount,
                fromParty = fromParty,
                khataNumber = khataNo,
                tafseel = tafseel
            )
            repository.insertJama(entry)
            
            // If linked to a Khata customer, also add payment in Khata!
            if (khataNo.isNotEmpty()) {
                val customer = _uiState.value.customers.find { it.khataNumber == khataNo }
                if (customer != null) {
                    val khataEntry = KhataEntryEntity(
                        customerId = customer.id,
                        entryType = KhataEntryType.JAMA,
                        amount = amount,
                        date = _uiState.value.activeShift?.shiftDate ?: "",
                        note = tafseel
                    )
                    repository.insertKhataEntry(khataEntry)
                }
            }
            _uiState.update { it.copy(userMessageToast = "جمع رقم PKR $amount درج ہو گئی") }
        }
    }

    fun deleteJamaEntry(entry: JamaEntryEntity) {
        viewModelScope.launch {
            repository.deleteJama(entry)
        }
    }

    fun addAkhrajatEntry(amount: Double, tafseel: String, category: String, voucherNo: String) {
        viewModelScope.launch {
            val shiftId = _uiState.value.activeShift?.id ?: return@launch
            val entry = AkhrajatEntryEntity(
                shiftId = shiftId,
                amount = amount,
                tafseel = tafseel,
                category = category,
                voucherNo = voucherNo
            )
            repository.insertAkhrajat(entry)
            _uiState.update { it.copy(userMessageToast = "خرچہ PKR $amount درج ہو گیا") }
        }
    }

    fun deleteAkhrajatEntry(entry: AkhrajatEntryEntity) {
        viewModelScope.launch {
            repository.deleteAkhrajat(entry)
        }
    }

    fun updateTankDip(dip: StockDipEntryEntity, dipCm: Double) {
        viewModelScope.launch {
            val convertedLitres = DipChartConverter.cmToLitres(dipCm)
            val updated = dip.copy(
                dipCm = dipCm,
                physicalDipLitres = convertedLitres
            )
            repository.updateDip(updated)
        }
    }

    fun closeDutyShift(pin: String) {
        val config = _uiState.value.appConfig
        val expectedPin = config?.ownerPin ?: "1234"
        if (pin != expectedPin) {
            _uiState.update { it.copy(userMessageToast = "غلط پن کوڈ! صرف پمپ مالک شفٹ بند کر سکتا ہے۔") }
            return
        }
        viewModelScope.launch {
            val shift = _uiState.value.activeShift ?: return@launch
            val counted = _uiState.value.reconciliation?.countedCash ?: shift.countedCash
            repository.closeShift(shift.id, "Owner (Hassan Baba)", counted)
            _uiState.update { it.copy(userMessageToast = "ڈیوٹی کامیابی سے مقفل ہو گئی۔ تمام حسابات لاک ہو گئے۔") }
        }
    }

    // --- Khata Actions ---
    fun selectCustomer(customer: CustomerEntity?) {
        _uiState.update { it.copy(selectedCustomer = customer) }
    }

    fun addCustomer(name: String, phone: String, type: String, creditLimit: Double, vehicles: String, notes: String) {
        viewModelScope.launch {
            val nextNum = "K-${100 + _uiState.value.customers.size + 1}"
            val customer = CustomerEntity(
                khataNumber = nextNum,
                name = name,
                phone = phone,
                type = type,
                creditLimit = creditLimit,
                vehicleNumbers = vehicles,
                notes = notes
            )
            repository.insertCustomer(customer)
            _uiState.update { it.copy(userMessageToast = "نیا کھاتہ $name درج ہو گیا ($nextNum)") }
        }
    }

    fun addUdhaarEntry(customerId: Long, product: String, litres: Double, rate: Double, amount: Double, slipNo: String, note: String) {
        viewModelScope.launch {
            val shiftDate = _uiState.value.activeShift?.shiftDate ?: "2026-10-10"
            val entry = KhataEntryEntity(
                customerId = customerId,
                entryType = KhataEntryType.UDHAAR,
                product = product,
                litres = litres,
                rate = rate,
                amount = amount,
                date = shiftDate,
                slipNo = slipNo,
                note = note
            )
            repository.insertKhataEntry(entry)
            _uiState.update { it.copy(userMessageToast = "ادھار پرچی $slipNo درج ہو گئی (PKR $amount)") }
        }
    }

    fun addKhataPayment(customerId: Long, amount: Double, mode: String, note: String) {
        viewModelScope.launch {
            val shiftDate = _uiState.value.activeShift?.shiftDate ?: "2026-10-10"
            val entry = KhataEntryEntity(
                customerId = customerId,
                entryType = KhataEntryType.JAMA,
                amount = amount,
                date = shiftDate,
                paymentMode = mode,
                note = note
            )
            repository.insertKhataEntry(entry)
            _uiState.update { it.copy(userMessageToast = "وصولی رقم PKR $amount درج ہو گئی") }
        }
    }

    // --- Company Actions ---
    fun addCompanyDelivery(invoiceNo: String, product: FuelType, orderedLitres: Double, receivedDipLitres: Double, rate: Double, driver: String) {
        viewModelScope.launch {
            val delivery = CompanyDeliveryEntity(
                invoiceNo = invoiceNo,
                challanDate = _uiState.value.activeShift?.shiftDate ?: "2026-10-10",
                product = product,
                orderedLitres = orderedLitres,
                receivedDipLitres = receivedDipLitres,
                purchaseRate = rate,
                tankerDriver = driver
            )
            repository.insertCompanyDelivery(delivery)
            _uiState.update { it.copy(userMessageToast = "آمدہ ٹینکر درج ہو گیا۔ شارٹیج: ${delivery.shortageLitres} Litres") }
        }
    }

    fun addCompanyPayment(amount: Double, mode: String, reference: String, note: String) {
        viewModelScope.launch {
            val payment = CompanyPaymentEntity(
                date = _uiState.value.activeShift?.shiftDate ?: "2026-10-10",
                amount = amount,
                paymentMode = mode,
                reference = reference,
                note = note
            )
            repository.insertCompanyPayment(payment)
            _uiState.update { it.copy(userMessageToast = "یورو کمپنی کو ادائیگی PKR $amount درج ہو گئی") }
        }
    }

    // --- Money & Transaction Actions ---
    fun addTransaction(accountId: Long, direction: String, amount: Double, purpose: String, linkedParty: String, voucherNo: String) {
        viewModelScope.launch {
            val txn = MoneyTransactionEntity(
                accountId = accountId,
                direction = direction,
                amount = amount,
                date = _uiState.value.activeShift?.shiftDate ?: "2026-10-10",
                purpose = purpose,
                linkedParty = linkedParty,
                voucherNo = voucherNo
            )
            repository.insertTransaction(txn)
            _uiState.update { it.copy(userMessageToast = "ٹرانزیکشن درج ہو گئی ($direction PKR $amount)") }
        }
    }

    // --- Jarvis AI Actions ---
    fun sendJarvisMessage(text: String) {
        if (text.isBlank()) return
        val userMsg = JarvisMessage(isUser = true, text = text)
        _uiState.update { it.copy(jarvisMessages = it.jarvisMessages + userMsg) }

        val action = JarvisEngine.processQuery(
            query = text,
            activeShift = _uiState.value.activeShift,
            nozzles = _uiState.value.nozzles,
            summary = _uiState.value.reconciliation,
            customers = _uiState.value.customers,
            khataEntries = _uiState.value.allKhataEntries,
            deliveries = _uiState.value.companyDeliveries,
            accounts = _uiState.value.accounts
        )

        when (action) {
            is JarvisAction.Answer -> {
                val respText = if (_uiState.value.currentLanguage == AppLanguage.ENGLISH) action.textEnglish else action.textUrdu
                val botMsg = JarvisMessage(isUser = false, text = respText)
                _uiState.update { it.copy(jarvisMessages = it.jarvisMessages + botMsg) }
            }
            is JarvisAction.RequireConfirmation -> {
                val desc = if (_uiState.value.currentLanguage == AppLanguage.ENGLISH) action.descriptionEnglish else action.descriptionUrdu
                val botMsg = JarvisMessage(
                    isUser = false,
                    text = desc,
                    actionProposal = action
                )
                _uiState.update { it.copy(jarvisMessages = it.jarvisMessages + botMsg, pendingAction = action) }
            }
        }
    }

    fun executePendingJarvisAction(action: JarvisAction.RequireConfirmation, pin: String? = null) {
        if (action.requiresPin) {
            val expectedPin = _uiState.value.appConfig?.ownerPin ?: "1234"
            if (pin != expectedPin) {
                _uiState.update { it.copy(userMessageToast = "غلط پن کوڈ! تصدیق مسترد ہو گئی۔") }
                return
            }
        }

        viewModelScope.launch {
            when (action.actionType) {
                "CLOSE_SHIFT" -> {
                    val shiftId = action.payload["shiftId"]?.toLongOrNull() ?: _uiState.value.activeShift?.id ?: 0L
                    val counted = action.payload["countedCash"]?.toDoubleOrNull() ?: 0.0
                    repository.closeShift(shiftId, "Jarvis AI (Owner Verified)", counted)
                    val confirmMsg = JarvisMessage(isUser = false, text = "ڈیوٹی کامیابی سے مقفل ہو گئی۔ تمام سیلز اور کیش محفوظ ہو گئے۔")
                    _uiState.update { it.copy(jarvisMessages = it.jarvisMessages + confirmMsg, pendingAction = null) }
                }
                "COMPANY_PAYMENT" -> {
                    val amount = action.payload["amount"]?.toDoubleOrNull() ?: 500000.0
                    val mode = action.payload["mode"] ?: "Bank Transfer"
                    addCompanyPayment(amount, mode, "Jarvis Quick Payment", "Approved by Hassan Baba")
                    val confirmMsg = JarvisMessage(isUser = false, text = "یورو کمپنی کو PKR $amount کی ادائیگی درج ہو گئی۔")
                    _uiState.update { it.copy(jarvisMessages = it.jarvisMessages + confirmMsg, pendingAction = null) }
                }
            }
        }
    }

    fun cancelPendingAction() {
        _uiState.update { it.copy(pendingAction = null) }
    }

    // ==========================================
    // Multi-Account Authentication & Management
    // ==========================================

    fun registerAccount(
        fullName: String,
        username: String,
        role: String,
        pin: String,
        phone: String = "",
        autoLogin: Boolean = true,
        onSuccess: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        val trimmedFullName = fullName.trim()
        val trimmedUsername = username.trim().lowercase()
        val trimmedPin = pin.trim()

        if (trimmedFullName.isEmpty()) {
            val err = "برائے مہربانی اپنا مکمل نام درج کریں"
            _uiState.update { it.copy(userMessageToast = err) }
            onError?.invoke(err)
            return
        }

        if (trimmedUsername.isEmpty()) {
            val err = "برائے مہربانی یوزر نیم یا فون نمبر درج کریں"
            _uiState.update { it.copy(userMessageToast = err) }
            onError?.invoke(err)
            return
        }

        if (trimmedPin.length < 4) {
            val err = "پن کوڈ کم از کم 4 ہندسوں پر مشتمل ہونا چاہیے"
            _uiState.update { it.copy(userMessageToast = err) }
            onError?.invoke(err)
            return
        }

        viewModelScope.launch {
            val existing = repository.getUserByUsername(trimmedUsername)
            if (existing != null) {
                val err = "یہ یوزر نیم پہلے سے موجود ہے! برائے مہربانی دوسرا نام یا نمبر منتخب کریں۔"
                _uiState.update { it.copy(userMessageToast = err) }
                onError?.invoke(err)
                return@launch
            }

            val isFirstAccount = _uiState.value.allUsers.isEmpty()
            val newUser = UserAccountEntity(
                username = trimmedUsername,
                fullName = trimmedFullName,
                role = role,
                pin = trimmedPin,
                phoneNumber = phone.trim(),
                createdAt = System.currentTimeMillis(),
                lastLoginAt = System.currentTimeMillis(),
                isDefault = isFirstAccount
            )

            val newId = repository.registerUser(newUser)
            val registeredUser = newUser.copy(id = newId)

            if (autoLogin) {
                _uiState.update {
                    it.copy(
                        currentUser = registeredUser,
                        isUserLoggedIn = true,
                        userMessageToast = "خوش آمدید! ${registeredUser.fullName} کا اکاؤنٹ کامیابی سے بن گیا اور لاگ ان ہو گیا۔"
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        userMessageToast = "${registeredUser.fullName} کا نیا اکاؤنٹ کامیابی سے بن گیا۔ اب لاگ ان کریں۔"
                    )
                }
            }
            onSuccess?.invoke()
        }
    }

    fun loginAccount(
        user: UserAccountEntity,
        enteredPin: String,
        onSuccess: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ): Boolean {
        if (user.pin == enteredPin.trim()) {
            viewModelScope.launch {
                val updated = user.copy(lastLoginAt = System.currentTimeMillis())
                repository.updateUser(updated)
            }
            _uiState.update {
                it.copy(
                    currentUser = user,
                    isUserLoggedIn = true,
                    userMessageToast = "خوش آمدید ${user.fullName} (${user.role})!"
                )
            }
            onSuccess?.invoke()
            return true
        } else {
            val err = "غلط پن کوڈ! برائے مہربانی درست پن درج کریں۔"
            _uiState.update { it.copy(userMessageToast = err) }
            onError?.invoke(err)
            return false
        }
    }

    fun logout() {
        _uiState.update {
            it.copy(
                currentUser = null,
                isUserLoggedIn = false,
                userMessageToast = "لاگ آؤٹ ہو گیا۔"
            )
        }
    }

    fun deleteUserAccount(user: UserAccountEntity) {
        viewModelScope.launch {
            repository.deleteUser(user)
            if (_uiState.value.currentUser?.id == user.id) {
                _uiState.update {
                    it.copy(
                        currentUser = null,
                        isUserLoggedIn = false
                    )
                }
            }
            _uiState.update {
                it.copy(userMessageToast = "${user.fullName} کا اکاؤنٹ حذف کر دیا گیا۔")
            }
        }
    }
}
