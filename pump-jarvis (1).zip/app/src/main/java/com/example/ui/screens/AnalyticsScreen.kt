package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CupertinoSegmentedControl
import com.example.ui.theme.*
import com.example.ui.viewmodel.PumpUiState
import java.text.NumberFormat
import java.util.*

@Composable
fun AnalyticsScreen(
    state: PumpUiState,
    modifier: Modifier = Modifier
) {
    val formatter = remember { NumberFormat.getNumberInstance(Locale.US) }
    var selectedPeriod by remember { mutableStateOf("THIS_MONTH") } // TODAY, THIS_MONTH, YEAR

    // Analytical metrics
    val tankerLossL = state.companyDeliveries.sumOf { it.shortageLitres }
    val tankerLossRupees = state.companyDeliveries.sumOf { it.shortageRupees }

    val tankEvaporationLossL = state.stockDips.sumOf { -it.kamZiadaLitres.coerceAtMost(0.0) }
    val tankEvaporationLossRupees = state.stockDips.sumOf { -it.kamZiadaAmount.coerceAtMost(0.0) }

    val totalShortageAllSources = tankerLossRupees + tankEvaporationLossRupees

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .testTag("analytics_screen"),
        contentPadding = PaddingValues(14.dp)
    ) {
        // 1. Period Selector - Apple iOS style
        item {
            val periodOptions = listOf("آج (Today)", "اس ماہ (Month)", "سالانہ (Annual)")
            val periodKeys = listOf("TODAY", "THIS_MONTH", "YEAR")
            CupertinoSegmentedControl(
                items = periodOptions,
                selectedIndex = periodKeys.indexOf(selectedPeriod).coerceAtLeast(0),
                onItemSelected = { selectedPeriod = periodKeys[it] }
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        // 2. Shortage Separation Card (Crucial requirement: Tanker vs Operational Evaporation)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "شارٹیج تفریق و تجزیہ (Shortage Source Breakdown)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = PetrolTealDark
                    )
                    Text(
                        text = "آمدہ ٹینکر کا نقصان بمقابلہ پمپ کے انڈرگراؤنڈ ٹینک کا بخاراتی نقصان:",
                        fontSize = 11.sp,
                        color = TextSecondaryLight
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Row 1: Tanker Delivery Transit Shortage
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("1. آمدہ ٹینکر ٹرانزٹ شارٹیج", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("کمپنی ڈپو سے پمپ آمد تک ڈرائیور کمی", fontSize = 11.sp, color = TextSecondaryLight)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${tankerLossL.toInt()} Litres", fontWeight = FontWeight.Bold, color = ShortageRed, fontSize = 14.sp)
                            Text("PKR ${formatter.format(tankerLossRupees.toLong())}", fontSize = 11.sp, color = ShortageRed)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = BorderLight, thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Row 2: Tank Evaporation & Meter Operational Loss
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("2. انڈرگراؤنڈ ٹینک بخارات و میٹر شارٹیج", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("بک اسٹاک بمقابلہ فزیکل ڈپ راڈ ریڈنگ", fontSize = 11.sp, color = TextSecondaryLight)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${tankEvaporationLossL.toInt()} Litres", fontWeight = FontWeight.Bold, color = EuroGoldDark, fontSize = 14.sp)
                            Text("PKR ${formatter.format(tankEvaporationLossRupees.toLong())}", fontSize = 11.sp, color = EuroGoldDark)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = ShortageRedBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("مجموعی نقصان (All Sources):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ShortageRed)
                            Text("PKR ${formatter.format(totalShortageAllSources.toLong())}", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = ShortageRed)
                        }
                    }
                }
            }
        }

        // 3. 12-Month Sales & Volume Comparison
        item {
            Spacer(modifier = Modifier.height(14.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("سالانہ فروخت و حجم (Annual Fuel Sales Trend)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PetrolTealDark)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Simulated 6-month forecourt trend bars
                    val monthlyData = listOf(
                        "مئی" to 145000,
                        "جون" to 168000,
                        "جولائی" to 192000,
                        "اگست" to 184000,
                        "ستمبر" to 176000,
                        "اکتوبر" to 205000
                    )

                    monthlyData.forEach { (month, litres) ->
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(month, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                Text("${formatter.format(litres.toLong())} L", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(3.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(SurfaceVariantLight)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(fraction = (litres / 220000f).coerceIn(0.1f, 1f))
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(5.dp))
                                        .background(PetrolTealPrimary)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. Nozzle Efficiency Comparison
        item {
            Spacer(modifier = Modifier.height(14.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("تمام 6 نوزلز فروخت موازنہ (Nozzle Share):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    state.nozzles.forEach { nozzle ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(nozzle.nozzleName, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Text("${formatter.format(nozzle.meezanLitres.toLong())} L (PKR ${formatter.format(nozzle.meezanAmount.toLong())})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PetrolTealMedium)
                        }
                    }
                }
            }
        }
    }
}
