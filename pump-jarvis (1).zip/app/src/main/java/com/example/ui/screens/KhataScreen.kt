package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.domain.LanguageEngine
import com.example.ui.theme.*
import com.example.ui.viewmodel.PumpUiState
import com.example.ui.viewmodel.PumpViewModel
import java.text.NumberFormat
import java.util.*

@Composable
fun KhataScreen(
    state: PumpUiState,
    viewModel: PumpViewModel,
    modifier: Modifier = Modifier
) {
    val lang = state.currentLanguage
    val formatter = remember { NumberFormat.getNumberInstance(Locale.US) }
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, HIGH_BALANCE, OVER_LIMIT
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var showGiveUdhaarDialog by remember { mutableStateOf(false) }
    var showReceivePaymentDialog by remember { mutableStateOf(false) }

    val selectedCustomer = state.selectedCustomer

    // Compute customer balances
    val customerBalances = remember(state.customers, state.allKhataEntries) {
        state.customers.associate { c ->
            val entries = state.allKhataEntries.filter { it.customerId == c.id }
            val udhaar = entries.filter { it.entryType == KhataEntryType.UDHAAR }.sumOf { it.amount }
            val jama = entries.filter { it.entryType == KhataEntryType.JAMA }.sumOf { it.amount }
            c.id to (udhaar - jama)
        }
    }

    val totalMarketUdhaar = customerBalances.values.sum()

    val filteredCustomers = remember(state.customers, searchQuery, selectedFilter, customerBalances) {
        state.customers.filter { c ->
            val matchQuery = c.name.contains(searchQuery, ignoreCase = true) ||
                    c.khataNumber.contains(searchQuery, ignoreCase = true) ||
                    c.phone.contains(searchQuery)
            val bal = customerBalances[c.id] ?: 0.0
            val matchFilter = when (selectedFilter) {
                "HIGH_BALANCE" -> bal > 100000.0
                "OVER_LIMIT" -> bal > c.creditLimit
                else -> true
            }
            matchQuery && matchFilter
        }.sortedByDescending { customerBalances[it.id] ?: 0.0 }
    }

    if (selectedCustomer != null) {
        // Customer Ledger Detail View
        CustomerDetailView(
            customer = selectedCustomer,
            balance = customerBalances[selectedCustomer.id] ?: 0.0,
            entries = state.allKhataEntries.filter { it.customerId == selectedCustomer.id },
            formatter = formatter,
            onBack = { viewModel.selectCustomer(null) },
            onGiveUdhaar = { showGiveUdhaarDialog = true },
            onReceivePayment = { showReceivePaymentDialog = true },
            onSendWhatsApp = {
                sendWhatsAppReminder(context, selectedCustomer, customerBalances[selectedCustomer.id] ?: 0.0)
            }
        )
    } else {
        // Customer List View
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(BackgroundLight)
                .testTag("khata_screen"),
            contentPadding = PaddingValues(14.dp)
        ) {
            // Header: Total Market Udhaar
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PetrolTealPrimary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "کل مارکیٹ واجب الادا ادھار (Total Khata Udhaar)",
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = "PKR ${formatter.format(totalMarketUdhaar.toLong())}",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EuroGoldLight
                                )
                            }
                            Button(
                                onClick = { showAddCustomerDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = EuroGoldPrimary),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("add_customer_btn")
                            ) {
                                Icon(imageVector = Icons.Default.PersonAdd, contentDescription = "Add", tint = PetrolTealDark, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("نیا کھاتہ", color = PetrolTealDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "کس کس کا کھاتہ ہے: ${state.customers.size} رجسٹرڈ صارفین (رحیم یار خان)",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            // Search Bar & Filter Chips
            item {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("نام، فون یا کھاتہ نمبر سے تلاش کریں...") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search") },
                    modifier = Modifier.fillMaxWidth().testTag("customer_search_input"),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = selectedFilter == "ALL",
                        onClick = { selectedFilter = "ALL" },
                        label = { Text("تمام All (${state.customers.size})", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedFilter == "HIGH_BALANCE",
                        onClick = { selectedFilter = "HIGH_BALANCE" },
                        label = { Text("زیادہ ادھار (>1 Lakh)", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedFilter == "OVER_LIMIT",
                        onClick = { selectedFilter = "OVER_LIMIT" },
                        label = { Text("لمٹ کراس (Over Limit)", fontSize = 11.sp) }
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Customer Directory List
            items(items = filteredCustomers, key = { it.id }) { customer ->
                val balance = customerBalances[customer.id] ?: 0.0
                val isOverLimit = balance > customer.creditLimit

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { viewModel.selectCustomer(customer) }
                        .testTag("customer_card_${customer.khataNumber}"),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = SurfaceVariantLight
                                    ) {
                                        Text(
                                            text = customer.khataNumber,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = PetrolTealDark,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = customer.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = TextPrimaryLight
                                    )
                                }
                                Text(
                                    text = "فون: ${customer.phone} | گاڑی: ${customer.vehicleNumbers.ifEmpty { "درج نہیں" }}",
                                    fontSize = 11.sp,
                                    color = TextSecondaryLight
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "PKR ${formatter.format(balance.toLong())}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = if (balance > 0) ShortageRed else ExcessGreen
                                )
                                if (isOverLimit) {
                                    Surface(shape = RoundedCornerShape(4.dp), color = ShortageRedBg) {
                                        Text("Over Limit!", color = ShortageRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                    }
                                } else {
                                    Text("لمٹ: ${formatter.format(customer.creditLimit.toLong())}", fontSize = 10.sp, color = TextSecondaryLight)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal: Add Customer
    if (showAddCustomerDialog) {
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var type by remember { mutableStateOf("Diesel") }
        var limitText by remember { mutableStateOf("200000") }
        var vehicles by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddCustomerDialog = false },
            title = { Text("نیا کسٹمر کھاتہ درج کریں (New Khata)", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("کسٹمر کا نام (Customer Name)") }, modifier = Modifier.fillMaxWidth().testTag("new_customer_name_input"))
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("موبائل نمبر (WhatsApp Phone)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = limitText, onValueChange = { limitText = it }, label = { Text("کریڈٹ لمٹ (Credit Limit PKR)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = vehicles, onValueChange = { vehicles = it }, label = { Text("گاڑی / ٹریکٹر نمبر (Vehicles)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("نوٹ / پتہ (Notes / Address)") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val limit = limitText.toDoubleOrNull() ?: 100000.0
                        if (name.isNotBlank()) {
                            viewModel.addCustomer(name, phone, type, limit, vehicles, notes)
                            showAddCustomerDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                    modifier = Modifier.testTag("save_customer_btn")
                ) {
                    Text("کھاتہ کھولیں Save")
                }
            },
            dismissButton = { TextButton(onClick = { showAddCustomerDialog = false }) { Text("منسوخ") } }
        )
    }

    // Modal: Give Udhaar
    if (showGiveUdhaarDialog && selectedCustomer != null) {
        var product by remember { mutableStateOf("Diesel") }
        var litresText by remember { mutableStateOf("") }
        var rateText by remember { mutableStateOf(if (product == "Diesel") "285" else "280") }
        var slipNo by remember { mutableStateOf("SL-${(1000..9999).random()}") }
        var note by remember { mutableStateOf("") }

        val litres = litresText.toDoubleOrNull() ?: 0.0
        val rate = rateText.toDoubleOrNull() ?: 285.0
        val computedAmount = litres * rate

        AlertDialog(
            onDismissRequest = { showGiveUdhaarDialog = false },
            title = { Text("${selectedCustomer.name} کو ادھار فیول دیں", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = product == "Diesel", onClick = { product = "Diesel"; rateText = "285" }, label = { Text("ڈیزل (Rs 285)") })
                        FilterChip(selected = product == "Petrol", onClick = { product = "Petrol"; rateText = "280" }, label = { Text("پٹرول (Rs 280)") })
                    }
                    OutlinedTextField(value = litresText, onValueChange = { litresText = it }, label = { Text("لٹر Litres") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth().testTag("udhaar_litres_input"))
                    OutlinedTextField(value = rateText, onValueChange = { rateText = it }, label = { Text("ریٹ فی لٹر (Rate)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = slipNo, onValueChange = { slipNo = it }, label = { Text("پرچی نمبر (Slip No)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("گاڑی نمبر / ڈرائیور تفصیل") }, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("کل ادھار رقم: PKR ${formatter.format(computedAmount.toLong())}", fontWeight = FontWeight.Bold, color = ShortageRed, fontSize = 14.sp)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (litres > 0) {
                            viewModel.addUdhaarEntry(selectedCustomer.id, product, litres, rate, computedAmount, slipNo, note)
                            showGiveUdhaarDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                    modifier = Modifier.testTag("submit_udhaar_btn")
                ) {
                    Text("ادھار درج کریں Save")
                }
            },
            dismissButton = { TextButton(onClick = { showGiveUdhaarDialog = false }) { Text("منسوخ") } }
        )
    }

    // Modal: Receive Payment
    if (showReceivePaymentDialog && selectedCustomer != null) {
        var amountText by remember { mutableStateOf("") }
        var mode by remember { mutableStateOf("Cash") }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showReceivePaymentDialog = false },
            title = { Text("${selectedCustomer.name} سے وصولی درج کریں", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("وصول شدہ رقم (PKR)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth().testTag("payment_amount_input"))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = mode == "Cash", onClick = { mode = "Cash" }, label = { Text("کیش Cash") })
                        FilterChip(selected = mode == "JazzCash", onClick = { mode = "JazzCash" }, label = { Text("جاز کیش") })
                        FilterChip(selected = mode == "Bank", onClick = { mode = "Bank" }, label = { Text("بینک Bank") })
                    }
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("تفصیل و حوالہ (Note / Reference)") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountText.toDoubleOrNull() ?: 0.0
                        if (amt > 0) {
                            viewModel.addKhataPayment(selectedCustomer.id, amt, mode, note)
                            showReceivePaymentDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                    modifier = Modifier.testTag("submit_payment_btn")
                ) {
                    Text("وصولی جمع کریں Save")
                }
            },
            dismissButton = { TextButton(onClick = { showReceivePaymentDialog = false }) { Text("منسوخ") } }
        )
    }
}

@Composable
private fun CustomerDetailView(
    customer: CustomerEntity,
    balance: Double,
    entries: List<KhataEntryEntity>,
    formatter: NumberFormat,
    onBack: () -> Unit,
    onGiveUdhaar: () -> Unit,
    onReceivePayment: () -> Unit,
    onSendWhatsApp: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .testTag("customer_detail_view"),
        contentPadding = PaddingValues(14.dp)
    ) {
        // Back Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(text = customer.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimaryLight)
                    Text(text = "${customer.khataNumber} | فون: ${customer.phone}", fontSize = 12.sp, color = TextSecondaryLight)
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Balance & Actions Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("موجودہ واجب الادا بقایا (Balance Due)", fontSize = 11.sp, color = TextSecondaryLight)
                            Text(
                                text = "PKR ${formatter.format(balance.toLong())}",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (balance > 0) ShortageRed else ExcessGreen
                            )
                        }
                        Button(
                            onClick = onSendWhatsApp,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("whatsapp_reminder_btn")
                        ) {
                            Text("WhatsApp", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onGiveUdhaar,
                            colors = ButtonDefaults.buttonColors(containerColor = PetrolAmber),
                            modifier = Modifier.weight(1f).testTag("give_udhaar_btn")
                        ) {
                            Text("+ ادھار دیں", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onReceivePayment,
                            colors = ButtonDefaults.buttonColors(containerColor = DieselGreen),
                            modifier = Modifier.weight(1f).testTag("receive_payment_btn")
                        ) {
                            Text("+ وصولی جمع", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text("کھاتہ تاریخچہ و اندراجات (Transaction Ledger):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
        }

        // Khata Transaction Entries
        if (entries.isEmpty()) {
            item {
                Text("کوئی ٹرانزیکشن موجود نہیں ہے۔", fontSize = 12.sp, color = TextSecondaryLight, modifier = Modifier.padding(vertical = 12.dp))
            }
        } else {
            items(items = entries, key = { it.id }) { entry ->
                val isUdhaar = entry.entryType == KhataEntryType.UDHAAR
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (isUdhaar) PetrolAmberLight else DieselGreenLight
                                ) {
                                    Text(
                                        text = if (isUdhaar) "ادھار Udhaar" else "وصولی Jama",
                                        color = if (isUdhaar) PetrolAmber else DieselGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(entry.date, fontSize = 11.sp, color = TextSecondaryLight)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            val desc = if (isUdhaar) "${entry.product} ${entry.litres.toInt()}L @ ${entry.rate.toInt()} (${entry.slipNo})" else "${entry.paymentMode} ${entry.note}"
                            Text(desc, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        }

                        Text(
                            text = "${if (isUdhaar) "+" else "-"}PKR ${formatter.format(entry.amount.toLong())}",
                            fontWeight = FontWeight.Bold,
                            color = if (isUdhaar) ShortageRed else ExcessGreen,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

private fun sendWhatsAppReminder(context: Context, customer: CustomerEntity, balance: Double) {
    val message = "محترم ${customer.name} صاحب،\nحسن بابا پیٹرولیم (جعفرآباد روڈ، پنج منارہ، رحیم یار خان) کی طرف آپ کا کل واجب الادا بقایا PKR ${balance.toLong()} ہے۔\nبرائے مہربانی اپنا ادھار کھاتہ جلد از جلد کلیئر فرمائیں۔ شکریہ۔\n- حسن بابا پیٹرولیم"
    val encoded = Uri.encode(message)
    val phone = customer.phone.replace("-", "").replace(" ", "").removePrefix("0")
    val url = "https://wa.me/92$phone?text=$encoded"
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        context.startActivity(intent)
    } catch (e: Exception) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share WhatsApp Reminder"))
    }
}
