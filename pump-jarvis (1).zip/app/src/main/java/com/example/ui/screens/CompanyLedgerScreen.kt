package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CompanyDeliveryEntity
import com.example.data.model.FuelType
import com.example.ui.components.CupertinoSegmentedControl
import com.example.ui.theme.*
import com.example.ui.viewmodel.PumpUiState
import com.example.ui.viewmodel.PumpViewModel
import java.text.NumberFormat
import java.util.*

@Composable
fun CompanyLedgerScreen(
    state: PumpUiState,
    viewModel: PumpViewModel,
    modifier: Modifier = Modifier
) {
    val formatter = remember { NumberFormat.getNumberInstance(Locale.US) }
    val context = LocalContext.current

    var selectedTab by remember { mutableStateOf(0) } // 0: Deliveries (Amda), 1: Payments to Euro, 2: Shortage Claims
    var showAddDeliveryDialog by remember { mutableStateOf(false) }
    var showAddPaymentDialog by remember { mutableStateOf(false) }
    var selectedDeliveryForClaim by remember { mutableStateOf<CompanyDeliveryEntity?>(null) }

    // Computations
    val totalPurchased = state.companyDeliveries.sumOf { it.totalBillAmount }
    val totalPaid = state.companyPayments.sumOf { it.amount }
    val companyPayableBalance = (totalPurchased - totalPaid).coerceAtLeast(0.0)
    val totalShortageLitres = state.companyDeliveries.sumOf { it.shortageLitres }
    val totalShortageRupees = state.companyDeliveries.sumOf { it.shortageRupees }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight)
            .testTag("company_ledger_screen"),
        contentPadding = PaddingValues(14.dp)
    ) {
        // 1. Euro Company Summary Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = PetrolTealPrimary),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "یورو آئل کمپنی کو واجب الادا (Euro Oil Payable)",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Text(
                                text = "PKR ${formatter.format(companyPayableBalance.toLong())}",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = EuroGoldLight
                            )
                        }
                        Button(
                            onClick = { showAddPaymentDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = EuroGoldPrimary),
                            modifier = Modifier.testTag("pay_euro_btn")
                        ) {
                            Text("ادائیگی درج", color = PetrolTealDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.2f), thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("کل خریداریاں (Total Billing)", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                            Text("PKR ${formatter.format(totalPurchased.toLong())}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                        Column {
                            Text("کل ادا شدہ رقم (Paid)", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                            Text("PKR ${formatter.format(totalPaid.toLong())}", color = ExcessGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ٹرانزٹ شارٹیج نقصان", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                            Text("PKR ${formatter.format(totalShortageRupees.toLong())}", color = ShortageRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // 2. Tab Navigation - Apple iOS Cupertino Segmented Control
        item {
            Spacer(modifier = Modifier.height(12.dp))
            CupertinoSegmentedControl(
                items = listOf(
                    "آمدہ ٹینکرز (${state.companyDeliveries.size})",
                    "ادائیگیاں (${state.companyPayments.size})",
                    "شارٹیج کلیمز"
                ),
                selectedIndex = selectedTab,
                onItemSelected = { selectedTab = it }
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        // 3. Tab Contents
        when (selectedTab) {
            // Deliveries (Amda)
            0 -> {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("آمدہ ٹینکرز ڈلیوری ریکارڈ:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Button(
                            onClick = { showAddDeliveryDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                            modifier = Modifier.testTag("add_tanker_delivery_btn")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("نیا ٹینکر درج", fontSize = 12.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                items(items = state.companyDeliveries, key = { it.id }) { delivery ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (delivery.product == FuelType.DIESEL) DieselGreen else PetrolAmber
                                    ) {
                                        Text(
                                            text = delivery.product.name,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = "چالان #${delivery.invoiceNo}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                                Text(text = delivery.challanDate, fontSize = 11.sp, color = TextSecondaryLight)
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text("آرڈر لٹر (Ordered)", fontSize = 11.sp, color = TextSecondaryLight)
                                    Text("${formatter.format(delivery.orderedLitres.toLong())} L", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                }
                                Column {
                                    Text("موصول ڈپ لٹر", fontSize = 11.sp, color = TextSecondaryLight)
                                    Text("${formatter.format(delivery.receivedDipLitres.toLong())} L", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("شارٹیج (Shortage)", fontSize = 11.sp, color = TextSecondaryLight)
                                    Text(
                                        text = "${delivery.shortageLitres.toInt()} L (${String.format("%.1f", delivery.shortagePercentage)}%)",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.sp,
                                        color = if (delivery.shortageLitres > 0) ShortageRed else ExcessGreen
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("خرید ریٹ: Rs ${delivery.purchaseRate}/L | بل: PKR ${formatter.format(delivery.totalBillAmount.toLong())}", fontSize = 11.sp, color = TextSecondaryLight)
                                if (delivery.shortageLitres > 0) {
                                    TextButton(
                                        onClick = { selectedDeliveryForClaim = delivery },
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Text("کلیم سمری 📄", fontSize = 11.sp, color = PetrolTealPrimary, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Payments to Euro Company
            1 -> {
                item {
                    Text("کمپنی کو ادا کی گئی رقوم (Payment Ledger):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                }

                items(items = state.companyPayments, key = { it.id }) { payment ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = payment.paymentMode, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(text = "${payment.date} | ${payment.reference}", fontSize = 12.sp, color = TextSecondaryLight)
                                if (payment.voucherNo.isNotEmpty()) {
                                    Text(text = "Voucher: ${payment.voucherNo}", fontSize = 11.sp, color = TextSecondaryLight)
                                }
                            }
                            Text(
                                text = "PKR ${formatter.format(payment.amount.toLong())}",
                                fontWeight = FontWeight.Bold,
                                color = ExcessGreen,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }

            // Shortage Claims & Analysis
            2 -> {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceLight)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("یورو آئل ٹرانزٹ شارٹیج تجزیہ (Shortage Claim Helper)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PetrolTealDark)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("ڈپو سے رحیم یار خانForecourt تک ٹینکر ڈرائیور کی شارٹیج کا کلیم تیار کریں:", fontSize = 12.sp, color = TextSecondaryLight)
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("کل ٹرانزٹ لٹر نقصان:", fontWeight = FontWeight.SemiBold)
                                Text("${formatter.format(totalShortageLitres.toLong())} Litres", fontWeight = FontWeight.Bold, color = ShortageRed)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("کل روپوں میں کلیم رقم:", fontWeight = FontWeight.SemiBold)
                                Text("PKR ${formatter.format(totalShortageRupees.toLong())}", fontWeight = FontWeight.ExtraBold, color = ShortageRed)
                            }

                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = {
                                    shareShortageClaim(context, state.companyDeliveries)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                                modifier = Modifier.fillMaxWidth().testTag("export_shortage_claim_btn")
                            ) {
                                Text("آفیشل شارٹیج کلیم سمری شیئر کریں (WhatsApp / Share)")
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal: Add Tanker Delivery
    if (showAddDeliveryDialog) {
        var invoiceNo by remember { mutableStateOf("EUR-${(1000..9999).random()}") }
        var product by remember { mutableStateOf(FuelType.DIESEL) }
        var orderedText by remember { mutableStateOf("20000") }
        var receivedText by remember { mutableStateOf("19850") }
        var rateText by remember { mutableStateOf("276.50") }
        var driver by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddDeliveryDialog = false },
            title = { Text("آمدہ ٹینکر درج کریں (Amda Tanker)", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = invoiceNo, onValueChange = { invoiceNo = it }, label = { Text("چالان / انوائس نمبر") }, modifier = Modifier.fillMaxWidth().testTag("delivery_invoice_input"))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = product == FuelType.DIESEL, onClick = { product = FuelType.DIESEL }, label = { Text("ڈیزل Diesel") })
                        FilterChip(selected = product == FuelType.PETROL, onClick = { product = FuelType.PETROL }, label = { Text("پٹرول Petrol") })
                    }
                    OutlinedTextField(value = orderedText, onValueChange = { orderedText = it }, label = { Text("آرڈر لٹر (Ordered Litres)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth().testTag("delivery_ordered_input"))
                    OutlinedTextField(value = receivedText, onValueChange = { receivedText = it }, label = { Text("وصول ڈپ لٹر (Received Dip Litres)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth().testTag("delivery_received_input"))
                    OutlinedTextField(value = rateText, onValueChange = { rateText = it }, label = { Text("خرید ریٹ فی لٹر (Purchase Rate)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = driver, onValueChange = { driver = it }, label = { Text("ڈرائیور نام و ٹینکر نمبر") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val ord = orderedText.toDoubleOrNull() ?: 0.0
                        val rec = receivedText.toDoubleOrNull() ?: 0.0
                        val rate = rateText.toDoubleOrNull() ?: 276.50
                        if (ord > 0 && rec > 0) {
                            viewModel.addCompanyDelivery(invoiceNo, product, ord, rec, rate, driver)
                            showAddDeliveryDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                    modifier = Modifier.testTag("submit_delivery_btn")
                ) {
                    Text("ٹینکر درج کریں Save")
                }
            },
            dismissButton = { TextButton(onClick = { showAddDeliveryDialog = false }) { Text("منسوخ") } }
        )
    }

    // Modal: Add Company Payment
    if (showAddPaymentDialog) {
        var amountText by remember { mutableStateOf("") }
        var mode by remember { mutableStateOf("Bank Transfer") }
        var reference by remember { mutableStateOf("Euro Oil Pakistan Ltd") }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddPaymentDialog = false },
            title = { Text("یورو کمپنی کو ادائیگی درج کریں", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("ادائیگی رقم (PKR)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth().testTag("company_payment_amount_input"))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = mode == "Bank Transfer", onClick = { mode = "Bank Transfer" }, label = { Text("بینک ٹرانسفر") })
                        FilterChip(selected = mode == "JazzCash", onClick = { mode = "JazzCash" }, label = { Text("جاز کیش") })
                        FilterChip(selected = mode == "Cheque", onClick = { mode = "Cheque" }, label = { Text("چیک Cheque") })
                    }
                    OutlinedTextField(value = reference, onValueChange = { reference = it }, label = { Text("حوالہ / اکاؤنٹ تفصیل") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("تفصیل و نوٹ") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountText.toDoubleOrNull() ?: 0.0
                        if (amt > 0) {
                            viewModel.addCompanyPayment(amt, mode, reference, note)
                            showAddPaymentDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary),
                    modifier = Modifier.testTag("submit_company_payment_btn")
                ) {
                    Text("ادائیگی محفوظ کریں Save")
                }
            },
            dismissButton = { TextButton(onClick = { showAddPaymentDialog = false }) { Text("منسوخ") } }
        )
    }

    // Single Delivery Claim Detail Dialog
    if (selectedDeliveryForClaim != null) {
        val d = selectedDeliveryForClaim!!
        AlertDialog(
            onDismissRequest = { selectedDeliveryForClaim = null },
            title = { Text("چالان #${d.invoiceNo} شارٹیج کلیم", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ڈپو: ${d.depotName}", fontSize = 12.sp)
                    Text("پراڈکٹ: ${d.product.name} | ڈرائیور: ${d.tankerDriver}", fontSize = 12.sp)
                    Text("انوائس لٹر: ${d.orderedLitres.toInt()} L", fontSize = 12.sp)
                    Text("فزیکل موصول لٹر: ${d.receivedDipLitres.toInt()} L", fontSize = 12.sp)
                    Text("شارٹیج: ${d.shortageLitres.toInt()} Litres (${String.format("%.2f", d.shortagePercentage)}%)", fontWeight = FontWeight.Bold, color = ShortageRed)
                    Text("کلیم رقم: PKR ${formatter.format(d.shortageRupees.toLong())}", fontWeight = FontWeight.ExtraBold, color = ShortageRed)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        shareSingleDeliveryClaim(context, d)
                        selectedDeliveryForClaim = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PetrolTealPrimary)
                ) {
                    Text("کلیم شیئر کریں Share")
                }
            },
            dismissButton = { TextButton(onClick = { selectedDeliveryForClaim = null }) { Text("بند کریں") } }
        )
    }
}

private fun shareShortageClaim(context: Context, deliveries: List<CompanyDeliveryEntity>) {
    val totalL = deliveries.sumOf { it.shortageLitres }
    val totalAmt = deliveries.sumOf { it.shortageRupees }
    val text = "آفیشل شارٹیج کلیم برائے یورو آئل پاکستان\nپمپ: حسن بابا پیٹرولیم، جعفرآباد روڈ، پنج منارہ، رحیم یار خان\nکل شارٹیج لٹر: ${totalL.toInt()} Litres\nکل کلیم مالیت: PKR ${totalAmt.toLong()}\nبراہ کرم لیجر ایڈجسٹمنٹ فرمائیں۔ شکریہ۔"
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, "Share Shortage Claim"))
}

private fun shareSingleDeliveryClaim(context: Context, d: CompanyDeliveryEntity) {
    val text = "شارٹیج کلیم چالان #${d.invoiceNo}\nحسن بابا پیٹرولیم رحیم یار خان\nپراڈکٹ: ${d.product.name}\nانوائس: ${d.orderedLitres.toInt()}L | وصولی: ${d.receivedDipLitres.toInt()}L\nشارٹیج: ${d.shortageLitres.toInt()}L | رقم: PKR ${d.shortageRupees.toLong()}\nڈرائیور: ${d.tankerDriver}"
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, "Share Delivery Claim"))
}
