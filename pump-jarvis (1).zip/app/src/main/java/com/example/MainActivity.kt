package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domain.LanguageEngine
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppNavScreen
import com.example.ui.viewmodel.PumpViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyTheme {
                val viewModel: PumpViewModel = viewModel()
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val snackbarHostState = remember { SnackbarHostState() }

                // Display Toast messages via Snackbar
                LaunchedEffect(uiState.userMessageToast) {
                    uiState.userMessageToast?.let { msg ->
                        snackbarHostState.showSnackbar(msg)
                        viewModel.clearToast()
                    }
                }

                // Handle system back navigation to return to Duty Register
                if (uiState.isUserLoggedIn && uiState.currentScreen != AppNavScreen.DUTY_REGISTER) {
                    BackHandler {
                        viewModel.setScreen(AppNavScreen.DUTY_REGISTER)
                    }
                }

                if (!uiState.isUserLoggedIn) {
                    // Start of the app: Login / Registration section
                    Box(modifier = Modifier.fillMaxSize()) {
                        AuthScreen(
                            state = uiState,
                            viewModel = viewModel
                        )
                        SnackbarHost(
                            hostState = snackbarHostState,
                            modifier = Modifier
                                .align(androidx.compose.ui.Alignment.BottomCenter)
                                .navigationBarsPadding()
                        )
                    }
                } else {
                    // Logged In: Full Forecourt App
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        contentWindowInsets = WindowInsets.safeDrawing,
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        bottomBar = {
                            ForecourtBottomBar(
                                currentScreen = uiState.currentScreen,
                                onSelectScreen = { viewModel.setScreen(it) },
                                language = uiState.currentLanguage
                            )
                        }
                    ) { innerPadding ->
                        Box(modifier = Modifier.padding(innerPadding)) {
                            when (uiState.currentScreen) {
                                AppNavScreen.DUTY_REGISTER -> DutyRegisterScreen(
                                    state = uiState,
                                    viewModel = viewModel
                                )
                                AppNavScreen.KHATA -> KhataScreen(
                                    state = uiState,
                                    viewModel = viewModel
                                )
                                AppNavScreen.COMPANY -> CompanyLedgerScreen(
                                    state = uiState,
                                    viewModel = viewModel
                                )
                                AppNavScreen.MONEY -> MoneyScreen(
                                    state = uiState,
                                    viewModel = viewModel
                                )
                                AppNavScreen.ANALYTICS -> AnalyticsScreen(
                                    state = uiState
                                )
                                AppNavScreen.JARVIS -> JarvisScreen(
                                    state = uiState,
                                    viewModel = viewModel
                                )
                                AppNavScreen.SETTINGS -> SettingsScreen(
                                    state = uiState,
                                    viewModel = viewModel
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ForecourtBottomBar(
    currentScreen: AppNavScreen,
    onSelectScreen: (AppNavScreen) -> Unit,
    language: com.example.domain.AppLanguage
) {
    NavigationBar(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("forecourt_bottom_bar"),
        containerColor = PetrolTealDark,
        contentColor = Color.White,
        tonalElevation = 8.dp
    ) {
        val navItems = listOf(
            Triple(AppNavScreen.DUTY_REGISTER, Icons.Default.LocalGasStation, "ڈیوٹی"),
            Triple(AppNavScreen.KHATA, Icons.AutoMirrored.Filled.MenuBook, "کھاتہ"),
            Triple(AppNavScreen.COMPANY, Icons.Default.Business, "کمپنی"),
            Triple(AppNavScreen.MONEY, Icons.Default.AccountBalance, "بینک"),
            Triple(AppNavScreen.ANALYTICS, Icons.Default.BarChart, "شارٹیج"),
            Triple(AppNavScreen.JARVIS, Icons.Default.SmartToy, "جاروس"),
            Triple(AppNavScreen.SETTINGS, Icons.Default.Settings, "سیٹنگز")
        )

        navItems.forEach { (screen, icon, urduLabel) ->
            val isSelected = currentScreen == screen
            val label = when (language) {
                com.example.domain.AppLanguage.URDU -> urduLabel
                com.example.domain.AppLanguage.ROMAN_URDU -> when(screen) {
                    AppNavScreen.DUTY_REGISTER -> "Duty"
                    AppNavScreen.KHATA -> "Khata"
                    AppNavScreen.COMPANY -> "Company"
                    AppNavScreen.MONEY -> "Paisa"
                    AppNavScreen.ANALYTICS -> "Shortage"
                    AppNavScreen.JARVIS -> "Jarvis"
                    AppNavScreen.SETTINGS -> "Settings"
                }
                com.example.domain.AppLanguage.ENGLISH -> when(screen) {
                    AppNavScreen.DUTY_REGISTER -> "Duty"
                    AppNavScreen.KHATA -> "Khata"
                    AppNavScreen.COMPANY -> "Euro"
                    AppNavScreen.MONEY -> "Money"
                    AppNavScreen.ANALYTICS -> "Reports"
                    AppNavScreen.JARVIS -> "Jarvis"
                    AppNavScreen.SETTINGS -> "Settings"
                }
            }

            NavigationBarItem(
                selected = isSelected,
                onClick = { onSelectScreen(screen) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        modifier = Modifier.size(20.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PetrolTealDark,
                    selectedTextColor = EuroGoldLight,
                    indicatorColor = EuroGoldPrimary,
                    unselectedIconColor = Color.White.copy(alpha = 0.7f),
                    unselectedTextColor = Color.White.copy(alpha = 0.7f)
                ),
                modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
            )
        }
    }
}
