package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.*

@Database(
    entities = [
        DutyShiftEntity::class,
        NozzleReadingEntity::class,
        JamaEntryEntity::class,
        AkhrajatEntryEntity::class,
        StockDipEntryEntity::class,
        CustomerEntity::class,
        KhataEntryEntity::class,
        CompanyDeliveryEntity::class,
        CompanyPaymentEntity::class,
        AccountEntity::class,
        MoneyTransactionEntity::class,
        LubricantProductEntity::class,
        LessProductEntryEntity::class,
        RecoveryItemEntity::class,
        AuditLogEntity::class,
        AppConfigEntity::class,
        UserAccountEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class PumpDatabase : RoomDatabase() {
    abstract fun pumpDao(): PumpDao

    companion object {
        @Volatile
        private var INSTANCE: PumpDatabase? = null

        fun getInstance(context: Context): PumpDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PumpDatabase::class.java,
                    "hassan_baba_petroleum.db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
