package com.example.data.seed

import com.example.data.db.PumpDao
import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.*

object DemoDataSeeder {

    suspend fun seedIfNeeded(dao: PumpDao) {
        val existingConfig = dao.getConfig()
        if (existingConfig != null) return

        // 1. Initial Config
        val config = AppConfigEntity(
            configKey = "station_config",
            stationName = "Hassan Baba Petroleum",
            brand = "Euro",
            location = "Jaffarabad Road, Pan Minara, Rahim Yar Khan",
            version = "v1.0",
            ownerPin = "1234",
            formulaJson = """{"version":"1.0","description":"Hassan Baba Petroleum Standard Forecourt Reconciliation"}""",
            toleranceShortagePct = 0.5,
            jarvisMemoryJson = """{"favoritePrompt":"Kal ka cash aur diesel shortage dikhao","attendantName":"Muhammad Asif"}"""
        )
        dao.saveConfig(config)

        // 2. Bank & Digital Accounts
        val accounts = listOf(
            AccountEntity(name = "HBL Main Branch Rahim Yar Khan", accountType = AccountType.BANK, accountNumber = "0142-7901452203", balance = 1845000.0),
            AccountEntity(name = "Meezan Bank Shariah Account", accountType = AccountType.BANK, accountNumber = "0209-0103445981", balance = 920000.0),
            AccountEntity(name = "JazzCash Hassan Baba Merchant", accountType = AccountType.JAZZCASH, accountNumber = "0300-8673412", balance = 245000.0),
            AccountEntity(name = "Easypaisa Forecourt Attendant", accountType = AccountType.EASYPAISA, accountNumber = "0345-7890123", balance = 115000.0),
            AccountEntity(name = "Forecourt Cash Drawer (Safe)", accountType = AccountType.CASH_DRAWER, accountNumber = "CASH-1", balance = 500000.0)
        )
        accounts.forEach { dao.insertAccount(it) }

        // 3. Lubricant Catalog
        val lubricants = listOf(
            LubricantProductEntity(brand = "Euro Lubricants", grade = "Super Diesel 50", packSize = "4 Litre", purchasePrice = 3200.0, salePrice = 3700.0, stockQuantity = 24),
            LubricantProductEntity(brand = "Shell Helix", grade = "HX5 15W-40", packSize = "4 Litre", purchasePrice = 4100.0, salePrice = 4800.0, stockQuantity = 18),
            LubricantProductEntity(brand = "Total Quartz", grade = "5000 20W-50", packSize = "4 Litre", purchasePrice = 3800.0, salePrice = 4400.0, stockQuantity = 14),
            LubricantProductEntity(brand = "ZIC", grade = "M9 4T 20W-50 (Motorcycle)", packSize = "1 Litre", purchasePrice = 1150.0, salePrice = 1400.0, stockQuantity = 45)
        )
        lubricants.forEach { dao.insertLubricant(it) }

        // 4. 25 Realistic Rahim Yar Khan Customers (Zamindars, Ginners, Transporters, Locals)
        val sampleCustomers = listOf(
            CustomerEntity(khataNumber = "K-101", name = "Chaudhry Tariq Gujjar (Tractors)", phone = "0300-7712345", type = "Diesel", creditLimit = 500000.0, vehicleNumbers = "MNR-1450, RYK-892"),
            CustomerEntity(khataNumber = "K-102", name = "Malik Aslam Goods Transport", phone = "0301-8654321", type = "Diesel", creditLimit = 1000000.0, vehicleNumbers = "TLG-551, TLA-992, RYK-4410"),
            CustomerEntity(khataNumber = "K-103", name = "Haji Rasheed Cotton Ginners", phone = "0300-9671122", type = "Diesel", creditLimit = 800000.0, vehicleNumbers = "Factory GenSet, RYK-786"),
            CustomerEntity(khataNumber = "K-104", name = "Rao Imran Jaffarabad (Zamindar)", phone = "0302-7128833", type = "Diesel", creditLimit = 350000.0, vehicleNumbers = "FIAT-640, New Holland"),
            CustomerEntity(khataNumber = "K-105", name = "Doctor Farooq Clinic & Lab", phone = "0303-6655441", type = "Petrol", creditLimit = 150000.0, vehicleNumbers = "LEE-19-4502 (Grande)"),
            CustomerEntity(khataNumber = "K-106", name = "Mian Shahid Sugar Cane Transport", phone = "0300-8451290", type = "Diesel", creditLimit = 600000.0, vehicleNumbers = "Tractor Trollies 1 to 4"),
            CustomerEntity(khataNumber = "K-107", name = "Sardar Bahawal Khan Zamindar", phone = "0304-9876543", type = "Mixed", creditLimit = 400000.0, vehicleNumbers = "Land Cruiser RYK-1, Massey"),
            CustomerEntity(khataNumber = "K-108", name = "Rana Waqas Harvester Works", phone = "0301-7543210", type = "Diesel", creditLimit = 450000.0, vehicleNumbers = "Harvester Claas-76"),
            CustomerEntity(khataNumber = "K-109", name = "Jam Abdul Sattar Brick Kiln (Bhatta)", phone = "0300-6712399", type = "Diesel", creditLimit = 300000.0, vehicleNumbers = "Dumper RYK-202"),
            CustomerEntity(khataNumber = "K-110", name = "Pan Minara Express Bus Fleet", phone = "0300-7890123", type = "Diesel", creditLimit = 750000.0, vehicleNumbers = "Buses 12, 14, 18"),
            CustomerEntity(khataNumber = "K-111", name = "Ch. Zahid Hussain Tube Well", phone = "0302-8901234", type = "Diesel", creditLimit = 200000.0, vehicleNumbers = "Tube Well Diesel Engine"),
            CustomerEntity(khataNumber = "K-112", name = "Al-Makkah Oil Mills RYK", phone = "0301-9012345", type = "Mixed", creditLimit = 500000.0, vehicleNumbers = "Trucks 4x2"),
            CustomerEntity(khataNumber = "K-113", name = "Haji Ghulam Nabi Flour Mills", phone = "0300-9123456", type = "Diesel", creditLimit = 400000.0, vehicleNumbers = "Isuzu NPR"),
            CustomerEntity(khataNumber = "K-114", name = "Babar Ali Shehzad Transport", phone = "0303-9234567", type = "Diesel", creditLimit = 350000.0, vehicleNumbers = "Mazda Titan"),
            CustomerEntity(khataNumber = "K-115", name = "Zafar Iqbal Dumper Fleet", phone = "0304-9345678", type = "Diesel", creditLimit = 500000.0, vehicleNumbers = "Dumpers 3x"),
            CustomerEntity(khataNumber = "K-116", name = "Sheikh Noman Cold Storage", phone = "0300-9456789", type = "Diesel", creditLimit = 300000.0, vehicleNumbers = "Generator 150kVA"),
            CustomerEntity(khataNumber = "K-117", name = "Tariq Mehmood Tractor Service", phone = "0301-9567890", type = "Diesel", creditLimit = 250000.0, vehicleNumbers = "MF-240, Belarus"),
            CustomerEntity(khataNumber = "K-118", name = "Mehr Ghulam Abbas Jaffarabad", phone = "0302-9678901", type = "Mixed", creditLimit = 180000.0, vehicleNumbers = "Cultus, MF-385"),
            CustomerEntity(khataNumber = "K-119", name = "Khan Muhammad Baloch Cotton", phone = "0303-9789012", type = "Diesel", creditLimit = 220000.0, vehicleNumbers = "Tractor Trolly"),
            CustomerEntity(khataNumber = "K-120", name = "Saeed Ahmed Agro Chemicals", phone = "0304-9890123", type = "Petrol", creditLimit = 100000.0, vehicleNumbers = "Bolan Delivery"),
            CustomerEntity(khataNumber = "K-121", name = "Tanveer Hussain Loader Rikshaw", phone = "0300-9901234", type = "Petrol", creditLimit = 50000.0, vehicleNumbers = "Loaders 4x"),
            CustomerEntity(khataNumber = "K-122", name = "Bilal Goods Carrier Sadiqabad Rd", phone = "0301-9012341", type = "Diesel", creditLimit = 400000.0, vehicleNumbers = "Bedford Trucks"),
            CustomerEntity(khataNumber = "K-123", name = "Haji Riaz Ice Factory", phone = "0302-9123452", type = "Diesel", creditLimit = 300000.0, vehicleNumbers = "Deutz Engine"),
            CustomerEntity(khataNumber = "K-124", name = "Master Asif School Vans", phone = "0303-9234563", type = "Petrol", creditLimit = 80000.0, vehicleNumbers = "Hiace, Bolan"),
            CustomerEntity(khataNumber = "K-125", name = "Hafiz Zubair Cattle Farm", phone = "0304-9345674", type = "Mixed", creditLimit = 150000.0, vehicleNumbers = "Shehzore, Hilux")
        )

        val customerIds = mutableListOf<Long>()
        for (c in sampleCustomers) {
            val id = dao.insertCustomer(c)
            customerIds.add(id)
        }

        // Seed initial Udhaar and Jama transactions for Customers
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val todayStr = dateFormat.format(Date())

        if (customerIds.isNotEmpty()) {
            dao.insertKhataEntry(KhataEntryEntity(customerId = customerIds[0], entryType = KhataEntryType.UDHAAR, product = "Diesel", litres = 250.0, rate = 285.0, amount = 71250.0, date = todayStr, slipNo = "SL-9901", note = "Tractor 385 ploughing shift"))
            dao.insertKhataEntry(KhataEntryEntity(customerId = customerIds[1], entryType = KhataEntryType.UDHAAR, product = "Diesel", litres = 600.0, rate = 285.0, amount = 171000.0, date = todayStr, slipNo = "SL-9902", note = "Truck TLG-551 Karachi trip"))
            dao.insertKhataEntry(KhataEntryEntity(customerId = customerIds[2], entryType = KhataEntryType.UDHAAR, product = "Diesel", litres = 400.0, rate = 285.0, amount = 114000.0, date = todayStr, slipNo = "SL-9903", note = "Generator fuel for night shift"))
            dao.insertKhataEntry(KhataEntryEntity(customerId = customerIds[3], entryType = KhataEntryType.UDHAAR, product = "Diesel", litres = 120.0, rate = 285.0, amount = 34200.0, date = todayStr, slipNo = "SL-9904", note = "FIAT-640 fuel"))
            dao.insertKhataEntry(KhataEntryEntity(customerId = customerIds[4], entryType = KhataEntryType.UDHAAR, product = "Petrol", litres = 45.0, rate = 280.0, amount = 12600.0, date = todayStr, slipNo = "SL-9905", note = "Grande full tank"))
            dao.insertKhataEntry(KhataEntryEntity(customerId = customerIds[0], entryType = KhataEntryType.JAMA, amount = 50000.0, date = todayStr, note = "JazzCash payment from Tariq Gujjar", paymentMode = "JazzCash"))
        }

        // 5. Initial 24-Hour Duty Shift (Open)
        val shift = DutyShiftEntity(
            shiftDate = todayStr,
            dayOfWeek = SimpleDateFormat("EEEE", Locale.getDefault()).format(Date()),
            oilManName = "Muhammad Asif (Incharge)",
            shiftType = "24 Hours (Daily)",
            petrolRate = 280.0,
            dieselRate = 285.0,
            sabiqaCash = 125000.0,
            countedCash = 2450000.0, // Initial physical cash in forecourt safe
            status = ShiftStatus.OPEN,
            notes = "Daily continuous duty sheet - Hassan Baba Petroleum"
        )
        val shiftId = dao.insertShift(shift)

        // 6. 6 Nozzle Meter Readings
        val nozzles = listOf(
            NozzleReadingEntity(shiftId = shiftId, nozzleNumber = 1, nozzleName = "Diesel 1 (Forecourt East)", fuelType = FuelType.DIESEL, sabiqaReading = 452100.0, maujoodaReading = 454330.0, wapsiTankLitres = 20.0, rate = 285.0),
            NozzleReadingEntity(shiftId = shiftId, nozzleNumber = 2, nozzleName = "Diesel 2 (Forecourt West)", fuelType = FuelType.DIESEL, sabiqaReading = 310450.0, maujoodaReading = 312090.0, wapsiTankLitres = 10.0, rate = 285.0),
            NozzleReadingEntity(shiftId = shiftId, nozzleNumber = 3, nozzleName = "Petrol 3 (Pump Island 1)", fuelType = FuelType.PETROL, sabiqaReading = 198200.0, maujoodaReading = 200135.0, wapsiTankLitres = 15.0, rate = 280.0),
            NozzleReadingEntity(shiftId = shiftId, nozzleNumber = 4, nozzleName = "Petrol 4 (Pump Island 1)", fuelType = FuelType.PETROL, sabiqaReading = 541000.0, maujoodaReading = 543375.0, wapsiTankLitres = 25.0, rate = 280.0),
            NozzleReadingEntity(shiftId = shiftId, nozzleNumber = 5, nozzleName = "Petrol 5 (Motorcycle Bay)", fuelType = FuelType.PETROL, sabiqaReading = 124500.0, maujoodaReading = 126090.0, wapsiTankLitres = 10.0, rate = 280.0),
            NozzleReadingEntity(shiftId = shiftId, nozzleNumber = 6, nozzleName = "Petrol 6 (Motorcycle Bay)", fuelType = FuelType.PETROL, sabiqaReading = 89000.0, maujoodaReading = 90195.0, wapsiTankLitres = 5.0, rate = 280.0)
        )
        dao.insertNozzleReadings(nozzles)

        // 7. Jama Receipts for Shift
        val jamaList = listOf(
            JamaEntryEntity(shiftId = shiftId, amount = 50000.0, fromParty = "Chaudhry Tariq Gujjar", khataNumber = "K-101", rateOrProduct = "Recovery", tafseel = "Pichla udhaar received via JazzCash"),
            JamaEntryEntity(shiftId = shiftId, amount = 100000.0, fromParty = "Malik Aslam Goods Transport", khataNumber = "K-102", rateOrProduct = "Recovery", tafseel = "Truck advance cash jama"),
            JamaEntryEntity(shiftId = shiftId, amount = 18500.0, fromParty = "Forecourt Tyre Shop Rent", khataNumber = "", rateOrProduct = "Rent", tafseel = "Mahana kiraya jama")
        )
        jamaList.forEach { dao.insertJama(it) }

        // 8. Akhrajat (Expenses) for Shift
        val akhrajatList = listOf(
            AkhrajatEntryEntity(shiftId = shiftId, amount = 4500.0, tafseel = "Forecourt Generator Diesel & Filter Service", voucherNo = "V-401", category = "Generator"),
            AkhrajatEntryEntity(shiftId = shiftId, amount = 1200.0, tafseel = "Staff Tea, Water Bottles & Biscuits", voucherNo = "V-402", category = "Tea/Kharcha"),
            AkhrajatEntryEntity(shiftId = shiftId, amount = 2500.0, tafseel = "Forecourt Tube Light replacement & electrician", voucherNo = "V-403", category = "Repair"),
            AkhrajatEntryEntity(shiftId = shiftId, amount = 8000.0, tafseel = "Daily staff food & helper wage advance", voucherNo = "V-404", category = "Salary")
        )
        akhrajatList.forEach { dao.insertAkhrajat(it) }

        // 9. Calibrated Tank Dip Stock Entries
        val dips = listOf(
            StockDipEntryEntity(shiftId = shiftId, tankId = 1, tankName = "Tank 1 (Diesel 25,000L)", fuelType = FuelType.DIESEL, dipCm = 142.5, physicalDipLitres = 18520.0, sabiqaStock = 20750.0, amdaStock = 0.0, saleStock = 2210.0, rate = 285.0),
            StockDipEntryEntity(shiftId = shiftId, tankId = 2, tankName = "Tank 2 (Diesel 25,000L)", fuelType = FuelType.DIESEL, dipCm = 128.0, physicalDipLitres = 16410.0, sabiqaStock = 18050.0, amdaStock = 0.0, saleStock = 1630.0, rate = 285.0),
            StockDipEntryEntity(shiftId = shiftId, tankId = 3, tankName = "Tank 3 (Petrol 25,000L)", fuelType = FuelType.PETROL, dipCm = 150.0, physicalDipLitres = 19550.0, sabiqaStock = 23820.0, amdaStock = 0.0, saleStock = 4270.0, rate = 280.0),
            StockDipEntryEntity(shiftId = shiftId, tankId = 4, tankName = "Tank 4 (Petrol 25,000L)", fuelType = FuelType.PETROL, dipCm = 110.0, physicalDipLitres = 13620.0, sabiqaStock = 16400.0, amdaStock = 0.0, saleStock = 2780.0, rate = 280.0)
        )
        dao.insertDips(dips)

        // 10. Euro Company Delivery (Amda) with realistic Shortage
        val delivery = CompanyDeliveryEntity(
            invoiceNo = "EUR-RYK-8812",
            challanDate = todayStr,
            product = FuelType.DIESEL,
            orderedLitres = 20000.0,
            receivedDipLitres = 19820.0, // 180 Litres transit shortage
            purchaseRate = 276.50,
            tankerDriver = "Muhammad Rafiq (Tanker TLG-902)",
            depotName = "Euro Oil Machike Terminal",
            densityTemp = "Density 0.825 @ 28°C",
            claimStatus = "Pending"
        )
        dao.insertCompanyDelivery(delivery)

        // Euro Company Payment
        dao.insertCompanyPayment(
            CompanyPaymentEntity(
                date = todayStr,
                amount = 3500000.0,
                paymentMode = "Bank Transfer",
                voucherNo = "HBL-OL-7789",
                reference = "Paid to Euro Oil Pakistan Ltd",
                note = "Advance for 40,000L quota"
            )
        )

        // 11. Initial Audit Log
        dao.insertAuditLog(
            AuditLogEntity(
                action = "SYSTEM_INITIALIZE",
                actorRole = "Owner",
                details = "Pump Jarvis initialized for Hassan Baba Petroleum with 6 nozzles and 4 calibrated tanks."
            )
        )
    }
}
