package com.example.data.db

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PumpDao {

    // --- Duty Shifts ---
    @Query("SELECT * FROM duty_shifts ORDER BY id DESC")
    fun getAllShiftsFlow(): Flow<List<DutyShiftEntity>>

    @Query("SELECT * FROM duty_shifts WHERE status = 'OPEN' ORDER BY id DESC LIMIT 1")
    fun getActiveShiftFlow(): Flow<DutyShiftEntity?>

    @Query("SELECT * FROM duty_shifts WHERE status = 'OPEN' ORDER BY id DESC LIMIT 1")
    suspend fun getActiveShift(): DutyShiftEntity?

    @Query("SELECT * FROM duty_shifts WHERE id = :id")
    suspend fun getShiftById(id: Long): DutyShiftEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShift(shift: DutyShiftEntity): Long

    @Update
    suspend fun updateShift(shift: DutyShiftEntity)

    // --- Nozzles ---
    @Query("SELECT * FROM nozzle_readings WHERE shiftId = :shiftId ORDER BY nozzleNumber ASC")
    fun getNozzlesForShiftFlow(shiftId: Long): Flow<List<NozzleReadingEntity>>

    @Query("SELECT * FROM nozzle_readings WHERE shiftId = :shiftId ORDER BY nozzleNumber ASC")
    suspend fun getNozzlesForShift(shiftId: Long): List<NozzleReadingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNozzleReadings(readings: List<NozzleReadingEntity>)

    @Update
    suspend fun updateNozzleReading(reading: NozzleReadingEntity)

    // --- Jama (Receipts) ---
    @Query("SELECT * FROM jama_entries WHERE shiftId = :shiftId ORDER BY id DESC")
    fun getJamaForShiftFlow(shiftId: Long): Flow<List<JamaEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJama(entry: JamaEntryEntity): Long

    @Delete
    suspend fun deleteJama(entry: JamaEntryEntity)

    // --- Akhrajat (Expenses) ---
    @Query("SELECT * FROM akhrajat_entries WHERE shiftId = :shiftId ORDER BY id DESC")
    fun getAkhrajatForShiftFlow(shiftId: Long): Flow<List<AkhrajatEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAkhrajat(entry: AkhrajatEntryEntity): Long

    @Delete
    suspend fun deleteAkhrajat(entry: AkhrajatEntryEntity)

    // --- Stock Dips ---
    @Query("SELECT * FROM stock_dip_entries WHERE shiftId = :shiftId ORDER BY tankId ASC")
    fun getDipsForShiftFlow(shiftId: Long): Flow<List<StockDipEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDips(dips: List<StockDipEntryEntity>)

    @Update
    suspend fun updateDip(dip: StockDipEntryEntity)

    // --- Customers ---
    @Query("SELECT * FROM customers ORDER BY name ASC")
    fun getAllCustomersFlow(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getCustomerById(id: Long): CustomerEntity?

    @Query("SELECT * FROM customers WHERE name LIKE '%' || :query || '%' OR khataNumber LIKE '%' || :query || '%'")
    suspend fun searchCustomers(query: String): List<CustomerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity): Long

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)

    // --- Khata Entries ---
    @Query("SELECT * FROM khata_entries WHERE customerId = :customerId ORDER BY id DESC")
    fun getKhataEntriesForCustomerFlow(customerId: Long): Flow<List<KhataEntryEntity>>

    @Query("SELECT * FROM khata_entries ORDER BY id DESC")
    fun getAllKhataEntriesFlow(): Flow<List<KhataEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKhataEntry(entry: KhataEntryEntity): Long

    // --- Company Deliveries ---
    @Query("SELECT * FROM company_deliveries ORDER BY id DESC")
    fun getCompanyDeliveriesFlow(): Flow<List<CompanyDeliveryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompanyDelivery(delivery: CompanyDeliveryEntity): Long

    @Update
    suspend fun updateCompanyDelivery(delivery: CompanyDeliveryEntity)

    // --- Company Payments ---
    @Query("SELECT * FROM company_payments ORDER BY id DESC")
    fun getCompanyPaymentsFlow(): Flow<List<CompanyPaymentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompanyPayment(payment: CompanyPaymentEntity): Long

    // --- Accounts & Money ---
    @Query("SELECT * FROM accounts ORDER BY id ASC")
    fun getAllAccountsFlow(): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts WHERE id = :id")
    suspend fun getAccountById(id: Long): AccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccount(account: AccountEntity): Long

    @Update
    suspend fun updateAccount(account: AccountEntity)

    @Query("SELECT * FROM money_transactions ORDER BY id DESC")
    fun getAllTransactionsFlow(): Flow<List<MoneyTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: MoneyTransactionEntity): Long

    // --- Lubricants ---
    @Query("SELECT * FROM lubricants ORDER BY brand ASC")
    fun getAllLubricantsFlow(): Flow<List<LubricantProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLubricant(lubricant: LubricantProductEntity): Long

    @Update
    suspend fun updateLubricant(lubricant: LubricantProductEntity)

    // --- Less Product ---
    @Query("SELECT * FROM less_product_entries WHERE shiftId = :shiftId ORDER BY id DESC")
    fun getLessProductsForShiftFlow(shiftId: Long): Flow<List<LessProductEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLessProduct(entry: LessProductEntryEntity): Long

    // --- Recovery Items ---
    @Query("SELECT * FROM recovery_items ORDER BY promisedDate ASC")
    fun getAllRecoveriesFlow(): Flow<List<RecoveryItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecovery(recovery: RecoveryItemEntity): Long

    @Update
    suspend fun updateRecovery(recovery: RecoveryItemEntity)

    // --- Audit Logs ---
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAllAuditLogsFlow(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity): Long

    // --- App Config ---
    @Query("SELECT * FROM app_config WHERE configKey = 'station_config' LIMIT 1")
    fun getConfigFlow(): Flow<AppConfigEntity?>

    @Query("SELECT * FROM app_config WHERE configKey = 'station_config' LIMIT 1")
    suspend fun getConfig(): AppConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveConfig(config: AppConfigEntity)

    // --- User Accounts (Multi-Account Authentication) ---
    @Query("SELECT * FROM user_accounts ORDER BY id ASC")
    fun getAllUserAccountsFlow(): Flow<List<UserAccountEntity>>

    @Query("SELECT * FROM user_accounts ORDER BY id ASC")
    suspend fun getAllUserAccounts(): List<UserAccountEntity>

    @Query("SELECT * FROM user_accounts WHERE id = :id LIMIT 1")
    suspend fun getUserAccountById(id: Long): UserAccountEntity?

    @Query("SELECT * FROM user_accounts WHERE username = :username LIMIT 1")
    suspend fun getUserAccountByUsername(username: String): UserAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserAccount(user: UserAccountEntity): Long

    @Update
    suspend fun updateUserAccount(user: UserAccountEntity)

    @Delete
    suspend fun deleteUserAccount(user: UserAccountEntity)
}
