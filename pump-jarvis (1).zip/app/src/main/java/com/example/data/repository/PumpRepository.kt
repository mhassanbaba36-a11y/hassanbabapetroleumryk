package com.example.data.repository

import com.example.data.db.PumpDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

class PumpRepository(private val dao: PumpDao) {

    val allShifts: Flow<List<DutyShiftEntity>> = dao.getAllShiftsFlow()
    val activeShift: Flow<DutyShiftEntity?> = dao.getActiveShiftFlow()
    val allCustomers: Flow<List<CustomerEntity>> = dao.getAllCustomersFlow()
    val allKhataEntries: Flow<List<KhataEntryEntity>> = dao.getAllKhataEntriesFlow()
    val companyDeliveries: Flow<List<CompanyDeliveryEntity>> = dao.getCompanyDeliveriesFlow()
    val companyPayments: Flow<List<CompanyPaymentEntity>> = dao.getCompanyPaymentsFlow()
    val accounts: Flow<List<AccountEntity>> = dao.getAllAccountsFlow()
    val transactions: Flow<List<MoneyTransactionEntity>> = dao.getAllTransactionsFlow()
    val lubricants: Flow<List<LubricantProductEntity>> = dao.getAllLubricantsFlow()
    val recoveries: Flow<List<RecoveryItemEntity>> = dao.getAllRecoveriesFlow()
    val auditLogs: Flow<List<AuditLogEntity>> = dao.getAllAuditLogsFlow()
    val appConfig: Flow<AppConfigEntity?> = dao.getConfigFlow()
    val allUsers: Flow<List<UserAccountEntity>> = dao.getAllUserAccountsFlow()

    fun getNozzlesForShift(shiftId: Long): Flow<List<NozzleReadingEntity>> =
        dao.getNozzlesForShiftFlow(shiftId)

    fun getJamaForShift(shiftId: Long): Flow<List<JamaEntryEntity>> =
        dao.getJamaForShiftFlow(shiftId)

    fun getAkhrajatForShift(shiftId: Long): Flow<List<AkhrajatEntryEntity>> =
        dao.getAkhrajatForShiftFlow(shiftId)

    fun getDipsForShift(shiftId: Long): Flow<List<StockDipEntryEntity>> =
        dao.getDipsForShiftFlow(shiftId)

    fun getLessProductsForShift(shiftId: Long): Flow<List<LessProductEntryEntity>> =
        dao.getLessProductsForShiftFlow(shiftId)

    fun getKhataForCustomer(customerId: Long): Flow<List<KhataEntryEntity>> =
        dao.getKhataEntriesForCustomerFlow(customerId)

    suspend fun getActiveShiftDirect(): DutyShiftEntity? = dao.getActiveShift()

    suspend fun updateShift(shift: DutyShiftEntity) = dao.updateShift(shift)

    suspend fun updateNozzleReading(reading: NozzleReadingEntity) =
        dao.updateNozzleReading(reading)

    suspend fun insertJama(entry: JamaEntryEntity): Long {
        val id = dao.insertJama(entry)
        dao.insertAuditLog(
            AuditLogEntity(
                action = "ADD_JAMA",
                actorRole = "Forecourt",
                details = "Jama PKR ${entry.amount} from ${entry.fromParty} (${entry.tafseel})"
            )
        )
        return id
    }

    suspend fun deleteJama(entry: JamaEntryEntity) {
        dao.deleteJama(entry)
        dao.insertAuditLog(
            AuditLogEntity(
                action = "DELETE_JAMA",
                actorRole = "Owner",
                details = "Deleted Jama PKR ${entry.amount} from ${entry.fromParty}"
            )
        )
    }

    suspend fun insertAkhrajat(entry: AkhrajatEntryEntity): Long {
        val id = dao.insertAkhrajat(entry)
        dao.insertAuditLog(
            AuditLogEntity(
                action = "ADD_EXPENSE",
                actorRole = "Forecourt",
                details = "Akhrajat PKR ${entry.amount} for ${entry.tafseel} [${entry.category}]"
            )
        )
        return id
    }

    suspend fun deleteAkhrajat(entry: AkhrajatEntryEntity) {
        dao.deleteAkhrajat(entry)
        dao.insertAuditLog(
            AuditLogEntity(
                action = "DELETE_EXPENSE",
                actorRole = "Owner",
                details = "Deleted Expense PKR ${entry.amount} (${entry.tafseel})"
            )
        )
    }

    suspend fun updateDip(dip: StockDipEntryEntity) = dao.updateDip(dip)

    suspend fun insertCustomer(customer: CustomerEntity): Long {
        val id = dao.insertCustomer(customer)
        dao.insertAuditLog(
            AuditLogEntity(
                action = "NEW_CUSTOMER",
                actorRole = "Owner",
                details = "Added Khata customer ${customer.name} (${customer.khataNumber})"
            )
        )
        return id
    }

    suspend fun insertKhataEntry(entry: KhataEntryEntity): Long {
        val id = dao.insertKhataEntry(entry)
        dao.insertAuditLog(
            AuditLogEntity(
                action = if (entry.entryType == KhataEntryType.UDHAAR) "ADD_UDHAAR" else "ADD_RECOVERY",
                actorRole = "Forecourt",
                details = "Khata ${entry.entryType.name} PKR ${entry.amount} (${entry.product} ${entry.litres}L, Slip ${entry.slipNo})"
            )
        )
        return id
    }

    suspend fun insertCompanyDelivery(delivery: CompanyDeliveryEntity): Long {
        val id = dao.insertCompanyDelivery(delivery)
        dao.insertAuditLog(
            AuditLogEntity(
                action = "COMPANY_DELIVERY",
                actorRole = "Manager",
                details = "Amda Tanker ${delivery.invoiceNo}: ${delivery.product.name} Ordered ${delivery.orderedLitres}L, Received ${delivery.receivedDipLitres}L, Shortage ${delivery.shortageLitres}L (PKR ${delivery.shortageRupees})"
            )
        )
        return id
    }

    suspend fun insertCompanyPayment(payment: CompanyPaymentEntity): Long {
        val id = dao.insertCompanyPayment(payment)
        dao.insertAuditLog(
            AuditLogEntity(
                action = "COMPANY_PAYMENT",
                actorRole = "Owner",
                details = "Paid to Euro Company PKR ${payment.amount} via ${payment.paymentMode} (${payment.reference})"
            )
        )
        return id
    }

    suspend fun insertTransaction(transaction: MoneyTransactionEntity): Long {
        val id = dao.insertTransaction(transaction)
        val account = dao.getAccountById(transaction.accountId)
        if (account != null) {
            val updatedBalance = if (transaction.direction == "IN") {
                account.balance + transaction.amount
            } else {
                account.balance - transaction.amount
            }
            dao.updateAccount(account.copy(balance = updatedBalance))
        }
        dao.insertAuditLog(
            AuditLogEntity(
                action = "MONEY_TRANSACTION",
                actorRole = "Accountant",
                details = "${transaction.direction} PKR ${transaction.amount} on Account ${transaction.accountId} for ${transaction.purpose}"
            )
        )
        return id
    }

    suspend fun saveConfig(config: AppConfigEntity) {
        dao.saveConfig(config)
        dao.insertAuditLog(
            AuditLogEntity(
                action = "CONFIG_UPDATED",
                actorRole = "Owner",
                details = "Station configuration updated (Version ${config.version})"
            )
        )
    }

    suspend fun closeShift(shiftId: Long, closedBy: String, countedCash: Double) {
        val shift = dao.getShiftById(shiftId) ?: return
        val updatedShift = shift.copy(
            status = ShiftStatus.LOCKED,
            closedAt = System.currentTimeMillis(),
            closedBy = closedBy,
            countedCash = countedCash
        )
        dao.updateShift(updatedShift)
        dao.insertAuditLog(
            AuditLogEntity(
                action = "SHIFT_CLOSED_LOCKED",
                actorRole = closedBy,
                details = "Shift #${shift.id} for ${shift.shiftDate} closed and locked. Counted Cash: PKR $countedCash."
            )
        )
    }

    // --- User Accounts ---
    suspend fun getAllUsersDirect(): List<UserAccountEntity> = dao.getAllUserAccounts()

    suspend fun getUserById(id: Long): UserAccountEntity? = dao.getUserAccountById(id)

    suspend fun getUserByUsername(username: String): UserAccountEntity? = dao.getUserAccountByUsername(username)

    suspend fun registerUser(user: UserAccountEntity): Long {
        val id = dao.insertUserAccount(user)
        dao.insertAuditLog(
            AuditLogEntity(
                action = "USER_REGISTERED",
                actorRole = user.role,
                details = "New account registered: ${user.fullName} (${user.username}, Role: ${user.role})"
            )
        )
        return id
    }

    suspend fun updateUser(user: UserAccountEntity) {
        dao.updateUserAccount(user)
    }

    suspend fun deleteUser(user: UserAccountEntity) {
        dao.deleteUserAccount(user)
        dao.insertAuditLog(
            AuditLogEntity(
                action = "USER_DELETED",
                actorRole = "Admin",
                details = "User account removed: ${user.fullName} (${user.username})"
            )
        )
    }
}
