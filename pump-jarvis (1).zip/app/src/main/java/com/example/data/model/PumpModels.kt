package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class FuelType(val displayName: String, val urduName: String) {
    DIESEL("High Speed Diesel", "ڈیزل"),
    PETROL("Super Petrol", "پٹرول"),
    MOBIL_OIL("Mobil Oil", "موبل آئل")
}

enum class ShiftStatus {
    OPEN, LOCKED
}

enum class KhataEntryType {
    UDHAAR, // Credit given
    JAMA    // Payment received
}

enum class AccountType(val displayName: String, val urduName: String) {
    BANK("Bank Account", "بینک اکاؤنٹ"),
    JAZZCASH("JazzCash", "جاز کیش"),
    EASYPAISA("Easypaisa", "ایزی پیسہ"),
    CASH_DRAWER("Cash in Forecourt", "کیش دراز")
}

// ---------------- Room Entities ----------------

@Entity(tableName = "duty_shifts")
data class DutyShiftEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shiftDate: String, // YYYY-MM-DD
    val dayOfWeek: String, // Roz (e.g. "Saturday / ہفتہ")
    val oilManName: String, // Attendant
    val shiftType: String = "24 Hours (Daily)",
    val petrolRate: Double = 280.0,
    val dieselRate: Double = 285.0,
    val sabiqaCash: Double = 0.0, // Previous shift cash balance
    val countedCash: Double = 0.0, // Physical cash in hand counted by oil man/owner
    val status: ShiftStatus = ShiftStatus.OPEN,
    val closedAt: Long? = null,
    val closedBy: String? = null,
    val notes: String = ""
)

@Entity(tableName = "nozzle_readings", indices = [Index(value = ["shiftId"])])
data class NozzleReadingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shiftId: Long,
    val nozzleNumber: Int,
    val nozzleName: String, // e.g. "Diesel 1", "Petrol 3"
    val fuelType: FuelType,
    val sabiqaReading: Double,
    val maujoodaReading: Double,
    val wapsiTankLitres: Double = 0.0,
    val rate: Double,
    val isResetFlag: Boolean = false,
    val resetReason: String = ""
) {
    val meezanLitres: Double
        get() = (maujoodaReading - sabiqaReading - wapsiTankLitres).coerceAtLeast(0.0)

    val meezanAmount: Double
        get() = meezanLitres * rate
}

@Entity(tableName = "jama_entries", indices = [Index(value = ["shiftId"])])
data class JamaEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shiftId: Long,
    val amount: Double,
    val fromParty: String,
    val khataNumber: String = "",
    val rateOrProduct: String = "",
    val tafseel: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "akhrajat_entries", indices = [Index(value = ["shiftId"])])
data class AkhrajatEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shiftId: Long,
    val amount: Double,
    val tafseel: String,
    val voucherNo: String = "",
    val category: String = "Misc", // Salary, Electricity, Generator, Repair, Tea/Kharcha
    val receiptPhotoUri: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "stock_dip_entries", indices = [Index(value = ["shiftId"])])
data class StockDipEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shiftId: Long,
    val tankId: Int,
    val tankName: String, // e.g. "Tank 1 (Diesel 25,000L)"
    val fuelType: FuelType,
    val dipCm: Double,
    val physicalDipLitres: Double,
    val sabiqaStock: Double,
    val amdaStock: Double = 0.0,
    val saleStock: Double,
    val rate: Double
) {
    val bookStock: Double
        get() = sabiqaStock + amdaStock - saleStock

    val kamZiadaLitres: Double
        get() = physicalDipLitres - bookStock

    val kamZiadaAmount: Double
        get() = kamZiadaLitres * rate
}

@Entity(tableName = "customers", indices = [Index(value = ["khataNumber"])])
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val khataNumber: String,
    val name: String,
    val phone: String,
    val type: String = "Mixed", // Petrol, Diesel, Lubricant, Mixed
    val creditLimit: Double = 100000.0,
    val vehicleNumbers: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "khata_entries", indices = [Index(value = ["customerId"])])
data class KhataEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val entryType: KhataEntryType,
    val product: String = "Fuel",
    val litres: Double = 0.0,
    val rate: Double = 0.0,
    val amount: Double,
    val date: String, // YYYY-MM-DD
    val slipNo: String = "",
    val slipPhotoUri: String? = null,
    val note: String = "",
    val paymentMode: String = "Cash",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "company_deliveries")
data class CompanyDeliveryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNo: String,
    val challanDate: String,
    val product: FuelType,
    val orderedLitres: Double,
    val receivedDipLitres: Double,
    val purchaseRate: Double,
    val tankerDriver: String = "",
    val depotName: String = "Euro Oil Machike / Sahiwal",
    val densityTemp: String = "",
    val claimStatus: String = "Pending", // None, Pending, Claimed, Reimbursed
    val createdAt: Long = System.currentTimeMillis()
) {
    val totalBillAmount: Double
        get() = orderedLitres * purchaseRate

    val shortageLitres: Double
        get() = (orderedLitres - receivedDipLitres).coerceAtLeast(0.0)

    val shortageRupees: Double
        get() = shortageLitres * purchaseRate

    val shortagePercentage: Double
        get() = if (orderedLitres > 0) (shortageLitres / orderedLitres) * 100.0 else 0.0
}

@Entity(tableName = "company_payments")
data class CompanyPaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val amount: Double,
    val paymentMode: String = "Bank Transfer", // Bank Transfer, JazzCash, Cheque, Cash
    val voucherNo: String = "",
    val reference: String = "",
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val accountType: AccountType,
    val accountNumber: String,
    val balance: Double = 0.0
)

@Entity(tableName = "money_transactions", indices = [Index(value = ["accountId"])])
data class MoneyTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val accountId: Long,
    val direction: String, // "IN" or "OUT"
    val amount: Double,
    val date: String,
    val voucherNo: String = "",
    val purpose: String, // Customer Payment, Company Payment, Forecourt Deposit, Expense, Withdrawal
    val linkedParty: String = "",
    val note: String = "",
    val isMatchedWithStatement: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "lubricants")
data class LubricantProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val brand: String,
    val grade: String,
    val packSize: String, // 1L, 4L, 20L
    val purchasePrice: Double,
    val salePrice: Double,
    val stockQuantity: Int,
    val minStockThreshold: Int = 5
)

@Entity(tableName = "less_product_entries", indices = [Index(value = ["shiftId"])])
data class LessProductEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shiftId: Long,
    val product: FuelType,
    val litres: Double,
    val rate: Double,
    val reason: String, // Spillage, Staff Testing, Machine Calibration, Customer Discount
    val approver: String = "Hassan Baba",
    val createdAt: Long = System.currentTimeMillis()
) {
    val rupeeValue: Double
        get() = litres * rate
}

@Entity(tableName = "recovery_items")
data class RecoveryItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val customerName: String,
    val promisedDate: String,
    val expectedAmount: Double,
    val recoveryAgent: String = "Self",
    val isCollected: Boolean = false,
    val collectedAmount: Double = 0.0,
    val notes: String = ""
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val action: String,
    val actorRole: String = "Owner",
    val details: String,
    val canUndo: Boolean = false,
    val statePayload: String = ""
)

@Entity(tableName = "app_config")
data class AppConfigEntity(
    @PrimaryKey val configKey: String = "station_config",
    val stationName: String = "Hassan Baba Petroleum",
    val brand: String = "Euro",
    val location: String = "Jaffarabad Road, Pan Minara, Rahim Yar Khan",
    val version: String = "v1.0",
    val ownerPin: String = "1234",
    val formulaJson: String = "{}",
    val toleranceShortagePct: Double = 0.5,
    val jarvisMemoryJson: String = "{}"
)

@Entity(
    tableName = "user_accounts",
    indices = [Index(value = ["username"], unique = true)]
)
data class UserAccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String, // Unique username or mobile number (e.g. "hassanbaba" or "03001234567")
    val fullName: String, // e.g. "ملک حسن بابا"
    val role: String = "Owner", // "Owner", "Manager", "Cashier", "Oil Man"
    val pin: String = "1234", // 4-digit PIN for quick login
    val phoneNumber: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastLoginAt: Long = 0L,
    val isDefault: Boolean = false
)
