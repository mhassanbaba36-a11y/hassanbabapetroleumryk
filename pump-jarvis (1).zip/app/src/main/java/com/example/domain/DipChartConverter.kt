package com.example.domain

/**
 * Calibrated Dip Chart Conversion Engine (CM to Litres).
 * Standard underground cylindrical tank calibration for Hassan Baba Petroleum.
 * Converts physical dip rod centimeters to exact calibrated fuel volume in litres.
 */
object DipChartConverter {

    // Calibration points: Pair(CM, Litres) for a 25,000 Litre horizontal cylindrical tank
    private val standardCalibrationChart = listOf(
        0.0 to 0.0,
        10.0 to 380.0,
        20.0 to 1100.0,
        30.0 to 2050.0,
        40.0 to 3180.0,
        50.0 to 4450.0,
        60.0 to 5820.0,
        70.0 to 7280.0,
        80.0 to 8800.0,
        90.0 to 10380.0,
        100.0 to 12000.0,
        110.0 to 13620.0,
        120.0 to 15200.0,
        130.0 to 16720.0,
        140.0 to 18180.0,
        150.0 to 19550.0,
        160.0 to 20820.0,
        170.0 to 21950.0,
        180.0 to 22900.0,
        190.0 to 23650.0,
        200.0 to 24200.0,
        210.0 to 24700.0,
        220.0 to 25000.0
    )

    fun cmToLitres(cm: Double): Double {
        if (cm <= 0.0) return 0.0
        if (cm >= 220.0) return 25000.0

        // Find surrounding points for linear interpolation
        for (i in 0 until standardCalibrationChart.size - 1) {
            val (cm1, l1) = standardCalibrationChart[i]
            val (cm2, l2) = standardCalibrationChart[i + 1]
            if (cm in cm1..cm2) {
                val ratio = (cm - cm1) / (cm2 - cm1)
                return l1 + ratio * (l2 - l1)
            }
        }
        return (cm * 113.6).coerceAtMost(25000.0)
    }
}
