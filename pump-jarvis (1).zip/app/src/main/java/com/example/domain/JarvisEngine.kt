package com.example.domain

import com.example.data.model.*

sealed class JarvisAction {
    data class Answer(val textUrdu: String, val textEnglish: String, val metricsBadge: String? = null) : JarvisAction()
    data class RequireConfirmation(
        val titleUrdu: String,
        val titleEnglish: String,
        val descriptionUrdu: String,
        val descriptionEnglish: String,
        val actionType: String,
        val payload: Map<String, String>,
        val requiresPin: Boolean = false
    ) : JarvisAction()
}

data class JarvisMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionProposal: JarvisAction.RequireConfirmation? = null
)

object JarvisEngine {

    fun processQuery(
        query: String,
        activeShift: DutyShiftEntity?,
        nozzles: List<NozzleReadingEntity>,
        summary: ShiftReconciliationSummary?,
        customers: List<CustomerEntity>,
        khataEntries: List<KhataEntryEntity>,
        deliveries: List<CompanyDeliveryEntity>,
        accounts: List<AccountEntity>
    ): JarvisAction {
        val q = query.trim().lowercase()

        // 1. Shift Closing / ڈیوٹی بند کرو
        if (q.contains("band") || q.contains("close") || q.contains("بند") || q.contains("لاک")) {
            return JarvisAction.RequireConfirmation(
                titleUrdu = "ڈیوٹی بند اور مقفل کریں",
                titleEnglish = "Close and Lock Current Shift",
                descriptionUrdu = "کیا آپ واقعی آج کی 24 گھنٹے کی ڈیوٹی مقفل کرنا چاہتے ہیں؟ موجودہ کیش PKR ${summary?.countedCash?.toLong() ?: 0} درج ہوگا۔",
                descriptionEnglish = "Are you sure you want to close and lock the shift? Recorded Hand Cash: PKR ${summary?.countedCash?.toLong() ?: 0}.",
                actionType = "CLOSE_SHIFT",
                payload = mapOf(
                    "shiftId" to (activeShift?.id?.toString() ?: "0"),
                    "countedCash" to (summary?.countedCash?.toString() ?: "0.0")
                ),
                requiresPin = true
            )
        }

        // 2. Customer Khata Inquiry / کھاتہ دکھاؤ
        val customerMatch = customers.find { customer ->
            val nameTokens = customer.name.lowercase().split(" ", "(", ")", "-")
            nameTokens.any { token -> token.length > 2 && q.contains(token) }
        }

        if (customerMatch != null || q.contains("khata") || q.contains("کھاتہ") || q.contains("udhaar") || q.contains("ادھار")) {
            val target = customerMatch ?: customers.firstOrNull()
            if (target != null) {
                val entries = khataEntries.filter { it.customerId == target.id }
                val totalUdhaar = entries.filter { it.entryType == KhataEntryType.UDHAAR }.sumOf { it.amount }
                val totalJama = entries.filter { it.entryType == KhataEntryType.JAMA }.sumOf { it.amount }
                val balance = totalUdhaar - totalJama

                return JarvisAction.Answer(
                    textUrdu = "${target.name} کا کھاتہ (${target.khataNumber}):\nکل بقایا ادھار: PKR ${balance.toLong()} ہے۔\nکریڈٹ لمٹ: PKR ${target.creditLimit.toLong()}\nگاڑی نمبر: ${target.vehicleNumbers.ifEmpty { "درج نہیں" }}",
                    textEnglish = "Customer Khata for ${target.name} (${target.khataNumber}):\nOutstanding Balance: PKR ${balance.toLong()}.\nCredit Limit: PKR ${target.creditLimit.toLong()}\nVehicles: ${target.vehicleNumbers.ifEmpty { "None" }}",
                    metricsBadge = "PKR ${balance.toLong()}"
                )
            }
        }

        // 3. Cash Variance / کیش شارٹ یا حساب
        if (q.contains("cash") || q.contains("کیش") || q.contains("hisaab") || q.contains("حساب") || q.contains("kam") || q.contains("short")) {
            if (summary != null) {
                val statusTextUrdu = when {
                    summary.isShort -> "کیش میں PKR ${(-summary.variance).toLong()} کی کمی (Shortage) ہے۔ ممکنہ وجوہات: ادھار بغیر پرچی دیا گیا یا ریکوری وصولی کم ہوئی۔"
                    summary.isExcess -> "کیش میں PKR ${summary.variance.toLong()} کی بیشی (Excess) ہے۔"
                    else -> "ماشاءاللہ! کیش کا حساب بالکل برابر ہے۔"
                }
                val statusTextEnglish = when {
                    summary.isShort -> "Cash variance is SHORT by PKR ${(-summary.variance).toLong()}. Probable reasons: unlogged credit slips or pending recovery deposit."
                    summary.isExcess -> "Cash variance is EXCESS by PKR ${summary.variance.toLong()}."
                    else -> "Cash is perfectly balanced against metered sale."
                }
                return JarvisAction.Answer(
                    textUrdu = "کیش مفاہمت (Reconciliation):\nمتوقع کیش: PKR ${summary.expectedCash.toLong()}\nموجود کیش ان ہینڈ: PKR ${summary.countedCash.toLong()}\nنتیجہ: $statusTextUrdu",
                    textEnglish = "Cash Reconciliation Summary:\nExpected Cash: PKR ${summary.expectedCash.toLong()}\nHand Cash Counted: PKR ${summary.countedCash.toLong()}\nResult: $statusTextEnglish",
                    metricsBadge = if (summary.isShort) "Short: -${(-summary.variance).toLong()}" else "Diff: ${summary.variance.toLong()}"
                )
            }
        }

        // 4. Diesel Shortage / شارٹیج
        if (q.contains("shortage") || q.contains("شارٹیج") || q.contains("nuqsan") || q.contains("نقصان")) {
            val totalShortageL = deliveries.sumOf { it.shortageLitres }
            val totalShortageRupees = deliveries.sumOf { it.shortageRupees }
            return JarvisAction.Answer(
                textUrdu = "یورو کمپنی آمدہ ٹینکر شارٹیج:\nکل شارٹیج لٹر: ${totalShortageL.toLong()} Litres\nمالیت: PKR ${totalShortageRupees.toLong()}\nکمپنی سے کلیم کا حق محفوظ ہے۔ کلیم سمری کمپنی ٹیب میں دستیاب ہے۔",
                textEnglish = "Euro Company Delivery Transit Shortage:\nTotal Transit Loss: ${totalShortageL.toLong()} Litres\nRupee Value: PKR ${totalShortageRupees.toLong()}\nShortage claim documentation is ready in the Company tab.",
                metricsBadge = "${totalShortageL.toLong()} L Short"
            )
        }

        // 5. Payment to Euro Company Proposal
        if (q.contains("company") || q.contains("کمپنی") || q.contains("bheje") || q.contains("paid")) {
            return JarvisAction.RequireConfirmation(
                titleUrdu = "کمپنی کو ادائیگی درج کریں",
                titleEnglish = "Record Company Payment",
                descriptionUrdu = "یورو آئل کمپنی کو PKR 500,000 کی ادائیگی درج کریں بذریعہ بینک ٹرانسفر / جاز کیش؟",
                descriptionEnglish = "Record PKR 500,000 payment to Euro Oil Pakistan via Bank/JazzCash?",
                actionType = "COMPANY_PAYMENT",
                payload = mapOf("amount" to "500000", "mode" to "Bank Transfer"),
                requiresPin = true
            )
        }

        // Default Intelligent Overview
        val totalSale = summary?.kulSaleAmdan ?: 0.0
        val dieselL = summary?.dieselLitres ?: 0.0
        val petrolL = summary?.petrolLitres ?: 0.0

        return JarvisAction.Answer(
            textUrdu = "حسن بابا پیٹرولیم خلاصہ:\nآج کی کل سیل: PKR ${totalSale.toLong()}\nڈیزل سیل: ${dieselL.toLong()} L (ریٹ PKR ${activeShift?.dieselRate ?: 285}/L)\nپٹرول سیل: ${petrolL.toLong()} L (ریٹ PKR ${activeShift?.petrolRate ?: 280}/L)\nآپ مجھ سے کھاتہ، کیش یا شارٹیج کے بارے میں پوچھ سکتے ہیں۔",
            textEnglish = "Hassan Baba Petroleum Operational Briefing:\nToday's Total Sale: PKR ${totalSale.toLong()}\nDiesel Sold: ${dieselL.toLong()} L (@ PKR ${activeShift?.dieselRate ?: 285}/L)\nPetrol Sold: ${petrolL.toLong()} L (@ PKR ${activeShift?.petrolRate ?: 280}/L)\nYou can ask me to check Khata, reconcile cash, or calculate company transit shortage.",
            metricsBadge = "Sale: PKR ${totalSale.toLong()}"
        )
    }

    fun getProactiveAlerts(
        customers: List<CustomerEntity>,
        khataEntries: List<KhataEntryEntity>,
        lubricants: List<LubricantProductEntity>,
        deliveries: List<CompanyDeliveryEntity>
    ): List<String> {
        val alerts = mutableListOf<String>()

        // 1. Over limit customer alert
        customers.forEach { c ->
            val entries = khataEntries.filter { it.customerId == c.id }
            val balance = entries.filter { it.entryType == KhataEntryType.UDHAAR }.sumOf { it.amount } -
                    entries.filter { it.entryType == KhataEntryType.JAMA }.sumOf { it.amount }
            if (balance > c.creditLimit) {
                alerts.add("توجہ: ${c.name} کا ادھار (PKR ${balance.toLong()}) منظور شدہ حد (PKR ${c.creditLimit.toLong()}) سے تجاوز کر گیا ہے!")
            }
        }

        // 2. Low Lubricant Stock Alert
        lubricants.filter { it.stockQuantity <= it.minStockThreshold }.forEach { lub ->
            alerts.add("کم اسٹاک وارننگ: ${lub.brand} ${lub.grade} کے صرف ${lub.stockQuantity} کین باقی ہیں۔ فوری آرڈر کریں!")
        }

        // 3. Tanker Shortage Alert
        val recentShort = deliveries.firstOrNull { it.shortageLitres > 100.0 }
        if (recentShort != null) {
            alerts.add("کمپنی شارٹیج الرٹ: چالان ${recentShort.invoiceNo} میں ${recentShort.shortageLitres.toLong()} لٹر شارٹیج ہے (نقصان: PKR ${recentShort.shortageRupees.toLong()})!")
        }

        return alerts
    }
}
