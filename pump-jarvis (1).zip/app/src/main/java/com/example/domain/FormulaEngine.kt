package com.example.domain

import com.example.data.model.*

data class ShiftReconciliationSummary(
    val dieselLitres: Double,
    val dieselAmount: Double,
    val petrolLitres: Double,
    val petrolAmount: Double,
    val totalFuelAmount: Double,
    val totalFuelLitres: Double,
    val mobilOilSale: Double,
    val deegarSale: Double,
    val kulSaleAmdan: Double,
    val sabiqaCash: Double,
    val totalJama: Double,
    val totalAkhrajat: Double,
    val totalLessProductRupees: Double,
    val totalUdhaarGiven: Double,
    val totalBankDeposits: Double,
    val expectedCash: Double,
    val countedCash: Double,
    val variance: Double // Counted - Expected (> 0 is Excess, < 0 is Short)
) {
    val isShort: Boolean get() = variance < -10.0
    val isExcess: Boolean get() = variance > 10.0
    val isBalanced: Boolean get() = !isShort && !isExcess
}

object FormulaEngine {

    fun calculateShift(
        shift: DutyShiftEntity,
        nozzles: List<NozzleReadingEntity>,
        jamaList: List<JamaEntryEntity>,
        akhrajatList: List<AkhrajatEntryEntity>,
        lessList: List<LessProductEntryEntity>,
        khataUdhaarGiven: Double = 0.0,
        bankDepositsFromForecourt: Double = 0.0,
        mobilOilSale: Double = 0.0,
        deegarSale: Double = 0.0
    ): ShiftReconciliationSummary {

        var dieselLitres = 0.0
        var dieselAmount = 0.0
        var petrolLitres = 0.0
        var petrolAmount = 0.0

        nozzles.forEach { nozzle ->
            val ltr = nozzle.meezanLitres
            val amt = nozzle.meezanAmount
            when (nozzle.fuelType) {
                FuelType.DIESEL -> {
                    dieselLitres += ltr
                    dieselAmount += amt
                }
                FuelType.PETROL -> {
                    petrolLitres += ltr
                    petrolAmount += amt
                }
                FuelType.MOBIL_OIL -> {}
            }
        }

        val totalFuelAmount = dieselAmount + petrolAmount
        val totalFuelLitres = dieselLitres + petrolLitres
        val kulSaleAmdan = totalFuelAmount + mobilOilSale + deegarSale

        val totalJama = jamaList.sumOf { it.amount }
        val totalAkhrajat = akhrajatList.sumOf { it.amount }
        val totalLessProductRupees = lessList.sumOf { it.rupeeValue }

        // Expected Cash Formula:
        // Expected Cash = Sabiqa Cash + Kul Sale + Jama - Less - Akhrajat - Udhaar - Bank Deposits
        val expectedCash = (shift.sabiqaCash + kulSaleAmdan + totalJama) -
                (totalLessProductRupees + totalAkhrajat + khataUdhaarGiven + bankDepositsFromForecourt)

        val variance = shift.countedCash - expectedCash

        return ShiftReconciliationSummary(
            dieselLitres = dieselLitres,
            dieselAmount = dieselAmount,
            petrolLitres = petrolLitres,
            petrolAmount = petrolAmount,
            totalFuelAmount = totalFuelAmount,
            totalFuelLitres = totalFuelLitres,
            mobilOilSale = mobilOilSale,
            deegarSale = deegarSale,
            kulSaleAmdan = kulSaleAmdan,
            sabiqaCash = shift.sabiqaCash,
            totalJama = totalJama,
            totalAkhrajat = totalAkhrajat,
            totalLessProductRupees = totalLessProductRupees,
            totalUdhaarGiven = khataUdhaarGiven,
            totalBankDeposits = bankDepositsFromForecourt,
            expectedCash = expectedCash,
            countedCash = shift.countedCash,
            variance = variance
        )
    }
}
