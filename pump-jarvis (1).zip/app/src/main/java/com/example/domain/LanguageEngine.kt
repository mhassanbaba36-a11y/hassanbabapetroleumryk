package com.example.domain

enum class AppLanguage(val code: String, val title: String) {
    URDU("ur", "اردو"),
    ROMAN_URDU("ru", "Roman"),
    ENGLISH("en", "English")
}

object LanguageEngine {

    fun t(key: String, lang: AppLanguage): String {
        val strings = when (lang) {
            AppLanguage.URDU -> urduStrings
            AppLanguage.ROMAN_URDU -> romanUrduStrings
            AppLanguage.ENGLISH -> englishStrings
        }
        return strings[key] ?: englishStrings[key] ?: key
    }

    private val englishStrings = mapOf(
        "app_title" to "Pump Jarvis",
        "station_name" to "Hassan Baba Petroleum",
        "brand_tag" to "Euro Brand - Rahim Yar Khan",
        "duty_register" to "Duty Register",
        "khata" to "Khata (Ledger)",
        "company" to "Euro Company",
        "money" to "Bank & Accounts",
        "analytics" to "Shortage & Analytics",
        "jarvis" to "Jarvis AI",
        "settings" to "Settings",
        
        // Duty Register
        "tareekh" to "Date",
        "roz" to "Day",
        "oil_man" to "Oil Man (Attendant)",
        "shift" to "Shift",
        "petrol_rate" to "Petrol Rate",
        "diesel_rate" to "Diesel Rate",
        "daily_rates" to "Daily Rates (PKR/L)",
        "sabiqa_reading" to "Sabiqa (Prev)",
        "maujooda_reading" to "Maujooda (Curr)",
        "wapsi_tank" to "Wapsi Tank (L)",
        "meezan_litres" to "Meezan (Sale L)",
        "meezan_amount" to "Sale (PKR)",
        "meter_reset" to "Meter Reset Flag",
        "close_duty" to "Close Shift & Lock",
        "shift_locked" to "Locked Shift (Owner Only)",
        
        // Reconciliation
        "expected_cash" to "Expected Cash",
        "counted_cash" to "Cash in Hand (Counted)",
        "excess_cash" to "Excess / بیشی (Surplus)",
        "short_cash" to "Short / کمی (Shortage)",
        "balanced_cash" to "Perfect Balance (کیش برابر)",
        "sabiqa_cash" to "Sabiqa Cash",
        "kul_sale" to "Total Fuel Sale",
        "jama_recoveries" to "Jama Receipts",
        "akhrajat_kharcha" to "Akhrajat (Expenses)",
        "udhaar_credit" to "Udhaar (Credit Given)",
        "less_discount" to "Less Product",
        
        // Tables
        "tab_nozzles" to "Nozzles",
        "tab_jama" to "Jama Table",
        "tab_akhrajat" to "Expenses",
        "tab_stock" to "Stock & Dip",
        "add_jama" to "+ Add Jama",
        "add_kharcha" to "+ Add Expense",
        "save" to "Save",
        "cancel" to "Cancel",
        
        // Khata
        "all_customers" to "All Customers",
        "total_udhaar" to "Total Market Udhaar",
        "add_customer" to "New Customer",
        "give_udhaar" to "Give Udhaar (Fuel)",
        "receive_payment" to "Receive Payment",
        "whatsapp_reminder" to "WhatsApp Reminder",
        "credit_limit" to "Credit Limit",
        
        // Company
        "euro_payable" to "Euro Oil Payable",
        "tanker_delivery" to "Tanker Delivery (Amda)",
        "pay_company" to "Pay Euro Company",
        "shortage_claim" to "Draft Shortage Claim",
        "short_litres" to "Tanker Shortage (L)",
        
        // AI Jarvis
        "jarvis_listening" to "Jarvis is ready. Ask anything about cash, sale, khata...",
        "jarvis_suggest" to "Suggested Commands",
        "confirm_action" to "Jarvis Action Confirmation",
        "undo" to "Undo Last Action"
    )

    private val urduStrings = mapOf(
        "app_title" to "پمپ جاروس",
        "station_name" to "حسن بابا پیٹرولیم",
        "brand_tag" to "یورو برانڈ - رحیم یار خان",
        "duty_register" to "ڈیوٹی رجسٹر (روزنامچہ)",
        "khata" to "ادھار کھاتہ",
        "company" to "کمپنی کھاتہ (یورو)",
        "money" to "بینک و اکاؤنٹس",
        "analytics" to "شارٹیج و تجزیہ",
        "jarvis" to "جاروس اے آئی",
        "settings" to "سیٹنگز",
        
        // Duty Register
        "tareekh" to "تاریخ",
        "roz" to "روز",
        "oil_man" to "آئل مین (انچارج)",
        "shift" to "شفٹ",
        "petrol_rate" to "ریٹ پٹرول",
        "diesel_rate" to "ریٹ ڈیزل",
        "daily_rates" to "روزانہ ریٹ (روپے/لٹر)",
        "sabiqa_reading" to "سابقہ ریڈنگ",
        "maujooda_reading" to "موجودہ ریڈنگ",
        "wapsi_tank" to "واپسی ٹینک",
        "meezan_litres" to "میزان لٹر",
        "meezan_amount" to "میزان رقم (سیل)",
        "meter_reset" to "میٹر ری سیٹ تصدیق",
        "close_duty" to "ڈیوٹی بند کریں (لاک)",
        "shift_locked" to "ڈیوٹی مقفل ہے (صرف مالک)",
        
        // Reconciliation
        "expected_cash" to "متوقع کیش (حساب کے مطابق)",
        "counted_cash" to "بقایا کیش ان ہینڈ (موجودہ)",
        "excess_cash" to "بیشی (اضافی کیش)",
        "short_cash" to "کمی (کیش شارٹ)",
        "balanced_cash" to "کیش بالکل برابر ہے",
        "sabiqa_cash" to "سابقہ بقایا کیش",
        "kul_sale" to "کل سیل و آمدن",
        "jama_recoveries" to "بقایاجات جمع",
        "akhrajat_kharcha" to "اخراجات و خرچہ",
        "udhaar_credit" to "ادھار کھاتہ (سیل)",
        "less_discount" to "لیس پراڈکٹ (رعایت/ضایع)",
        
        // Tables
        "tab_nozzles" to "نوزل میٹر",
        "tab_jama" to "جمع جدول",
        "tab_akhrajat" to "اخراجات",
        "tab_stock" to "اسٹاک رجسٹر و ڈپ",
        "add_jama" to "+ رقم جمع کریں",
        "add_kharcha" to "+ خرچہ درج کریں",
        "save" to "محفوظ کریں",
        "cancel" to "منسوخ",
        
        // Khata
        "all_customers" to "تمام کھاتے دار",
        "total_udhaar" to "کل واجب الادا ادھار",
        "add_customer" to "نیا کھاتہ",
        "give_udhaar" to "ادھار پیٹرول/ڈیزل دیں",
        "receive_payment" to "وصولی جمع کریں",
        "whatsapp_reminder" to "واٹس ایپ یاد دہانی",
        "credit_limit" to "ادھار حد (لمٹ)",
        
        // Company
        "euro_payable" to "یورو کمپنی کو رقم واجب الادا",
        "tanker_delivery" to "آمدہ ٹینکر (ڈلیوری)",
        "pay_company" to "کمپنی کو ادائیگی کریں",
        "shortage_claim" to "شارٹیج کلیم تیار کریں",
        "short_litres" to "آمدہ ٹینکر شارٹیج (لٹر)",
        
        // AI Jarvis
        "jarvis_listening" to "جاروس تیار ہے۔ کیش، سیل، کھاتہ یا ڈیوٹی کے بارے میں پوچھیئے...",
        "jarvis_suggest" to "فوری احکامات",
        "confirm_action" to "جاروس ایکشن تصدیق",
        "undo" to "واپس لیں (Undo)"
    )

    private val romanUrduStrings = mapOf(
        "app_title" to "Pump Jarvis",
        "station_name" to "Hassan Baba Petroleum",
        "brand_tag" to "Euro Brand - Rahim Yar Khan",
        "duty_register" to "Duty Register (Roznamcha)",
        "khata" to "Khata (Udhaar)",
        "company" to "Company Khata (Euro)",
        "money" to "Bank o Accounts",
        "analytics" to "Shortage o Analytics",
        "jarvis" to "Jarvis AI",
        "settings" to "Settings",
        
        // Duty Register
        "tareekh" to "Tareekh",
        "roz" to "Roz",
        "oil_man" to "Oil Man (Incharge)",
        "shift" to "Shift",
        "petrol_rate" to "Rate Petrol",
        "diesel_rate" to "Rate Diesel",
        "daily_rates" to "Rozana Rate (Rs/Litre)",
        "sabiqa_reading" to "Sabiqa Reading",
        "maujooda_reading" to "Maujooda Reading",
        "wapsi_tank" to "Wapsi Tank (L)",
        "meezan_litres" to "Meezan Litres",
        "meezan_amount" to "Meezan Raqam",
        "meter_reset" to "Meter Reset Flag",
        "close_duty" to "Duty Band Karen (Lock)",
        "shift_locked" to "Duty Locked Hai (Owner Only)",
        
        // Reconciliation
        "expected_cash" to "Expected Cash (Hisaab)",
        "counted_cash" to "Cash in Hand (Gin kar)",
        "excess_cash" to "Excess / Ziada Cash",
        "short_cash" to "Short / Kam Cash",
        "balanced_cash" to "Cash Barabar Hai",
        "sabiqa_cash" to "Sabiqa Cash",
        "kul_sale" to "Kul Fuel Sale",
        "jama_recoveries" to "Jama Recoveries",
        "akhrajat_kharcha" to "Akhrajat o Kharcha",
        "udhaar_credit" to "Udhaar Diya",
        "less_discount" to "Less Product",
        
        // Tables
        "tab_nozzles" to "Nozzles",
        "tab_jama" to "Jama Table",
        "tab_akhrajat" to "Akhrajat",
        "tab_stock" to "Stock o Dip",
        "add_jama" to "+ Jama Entry",
        "add_kharcha" to "+ Kharcha Entry",
        "save" to "Save Karen",
        "cancel" to "Cancel",
        
        // Khata
        "all_customers" to "Sab Khatey",
        "total_udhaar" to "Kul Market Udhaar",
        "add_customer" to "Naya Customer",
        "give_udhaar" to "Udhaar Fuel Dein",
        "receive_payment" to "Wasooli Jama Karen",
        "whatsapp_reminder" to "WhatsApp Reminder",
        "credit_limit" to "Credit Limit",
        
        // Company
        "euro_payable" to "Company Ka Baqaya Dena",
        "tanker_delivery" to "Amda Tanker",
        "pay_company" to "Company Ko Payment",
        "shortage_claim" to "Shortage Claim Tayyar Karen",
        "short_litres" to "Amda Shortage (Litres)",
        
        // AI Jarvis
        "jarvis_listening" to "Jarvis tayyar hai. Cash, sale, khata ya duty ka poochen...",
        "jarvis_suggest" to "Jaldi Command",
        "confirm_action" to "Jarvis Action Confirm",
        "undo" to "Wapas Lein (Undo)"
    )
}
