package com.example

import com.example.data.model.*
import com.example.domain.DipChartConverter
import com.example.domain.FormulaEngine
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testNozzleSalesCalculation() {
        val nozzle = NozzleReadingEntity(
            shiftId = 1,
            nozzleNumber = 1,
            nozzleName = "Diesel 1",
            fuelType = FuelType.DIESEL,
            sabiqaReading = 10000.0,
            maujoodaReading = 12500.0,
            wapsiTankLitres = 20.0,
            rate = 285.0
        )

        assertEquals(2480.0, nozzle.meezanLitres, 0.001)
        assertEquals(706800.0, nozzle.meezanAmount, 0.001)
    }

    @Test
    fun testCashReconciliationExpectedCashAndVariance() {
        val shift = DutyShiftEntity(
            shiftDate = "2026-10-10",
            dayOfWeek = "Saturday",
            oilManName = "Muhammad Asif",
            sabiqaCash = 50000.0,
            countedCash = 850000.0
        )

        val nozzles = listOf(
            NozzleReadingEntity(shiftId = 1, nozzleNumber = 1, nozzleName = "Diesel 1", fuelType = FuelType.DIESEL, sabiqaReading = 0.0, maujoodaReading = 2000.0, wapsiTankLitres = 0.0, rate = 285.0),
            NozzleReadingEntity(shiftId = 1, nozzleNumber = 3, nozzleName = "Petrol 3", fuelType = FuelType.PETROL, sabiqaReading = 0.0, maujoodaReading = 1000.0, wapsiTankLitres = 0.0, rate = 280.0)
        )
        // Fuel sale = (2000 * 285) + (1000 * 280) = 570000 + 280000 = 850000

        val jama = listOf(JamaEntryEntity(shiftId = 1, amount = 25000.0, fromParty = "Recovery"))
        val akhrajat = listOf(AkhrajatEntryEntity(shiftId = 1, amount = 5000.0, tafseel = "Tea", category = "Tea/Kharcha"))
        val less = emptyList<LessProductEntryEntity>()
        val udhaar = 40000.0

        val summary = FormulaEngine.calculateShift(
            shift = shift,
            nozzles = nozzles,
            jamaList = jama,
            akhrajatList = akhrajat,
            lessList = less,
            khataUdhaarGiven = udhaar,
            bankDepositsFromForecourt = 0.0
        )

        // Expected Cash = 50000 + 850000 + 25000 - 5000 - 40000 = 880,000
        assertEquals(880000.0, summary.expectedCash, 0.001)

        // Counted Cash is 850000 -> Variance is 850000 - 880000 = -30,000 (Short)
        assertEquals(-30000.0, summary.variance, 0.001)
        assertTrue(summary.isShort)
        assertFalse(summary.isExcess)
    }

    @Test
    fun testDipChartConversion() {
        val litres0 = DipChartConverter.cmToLitres(0.0)
        assertEquals(0.0, litres0, 0.001)

        val litres100 = DipChartConverter.cmToLitres(100.0)
        assertEquals(12000.0, litres100, 0.001)

        val litres220 = DipChartConverter.cmToLitres(220.0)
        assertEquals(25000.0, litres220, 0.001)
    }

    @Test
    fun testTankerDeliveryShortage() {
        val delivery = CompanyDeliveryEntity(
            invoiceNo = "EUR-8812",
            challanDate = "2026-10-10",
            product = FuelType.DIESEL,
            orderedLitres = 20000.0,
            receivedDipLitres = 19800.0,
            purchaseRate = 276.50
        )

        assertEquals(200.0, delivery.shortageLitres, 0.001)
        assertEquals(55300.0, delivery.shortageRupees, 0.001)
        assertEquals(1.0, delivery.shortagePercentage, 0.001)
    }
}
